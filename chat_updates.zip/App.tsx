
import React, { useState, useCallback, useRef, useMemo, useEffect } from 'react';
import { ViewState, BusinessData, AgentConfig, ChatMode, ChatLayoutMode, SdkTheme, CrmContact, Task, CallLog, BotConfig, MenuItem, CartItem } from './types';
import { enrichBusinessData, createChatSession } from './services/geminiService';
import { LiveVoiceClient } from './services/liveService';
import HeroSection from './components/HeroSection';
import InfoGrid from './components/InfoGrid';
import BlogSection from './components/BlogSection';
import MenuSection from './components/MenuSection';
import StandardizedChatInterface from './components/StandardizedChatInterface';
import VoiceIndicator from './components/VoiceIndicator';
import PlaceSearch from './components/PlaceSearch';
import { Chat } from '@google/genai';

const MOCK_CRM: CrmContact[] = [
  { id: '1', name: 'Alice Johnson', email: 'alice@example.com', status: 'Customer', lastContact: '2h ago' },
  { id: '2', name: 'Bob Smith', email: 'bob@tech.co', status: 'Lead', lastContact: '1d ago' },
  { id: '3', name: 'Carol White', email: 'c.white@design.net', status: 'VIP', lastContact: '3d ago' },
];

const MOCK_TASKS: Task[] = [
  { id: '1', title: 'Follow up with Alice', due: 'Today', priority: 'High' },
  { id: '2', title: 'Prepare Invoice #1042', due: 'Tomorrow', priority: 'Medium' },
  { id: '3', title: 'Update Holiday Hours', due: 'Fri', priority: 'Low' },
];

const MOCK_CALLS: CallLog[] = [
  { id: '1', caller: 'Alice Johnson', duration: '4m 32s', timestamp: '10:42 AM', status: 'Completed', sentiment: 'Positive' },
  { id: '2', caller: 'Unknown', duration: '0s', timestamp: '9:15 AM', status: 'Missed', sentiment: 'Neutral' },
  { id: '3', caller: 'Bob Smith', duration: '1m 15s', timestamp: 'Yesterday', status: 'Voicemail', sentiment: 'Negative' },
];

const App: React.FC = () => {
  const [viewState, setViewState] = useState<ViewState>(ViewState.LANDING);
  const [businessData, setBusinessData] = useState<BusinessData | null>(null);
  const [chatSession, setChatSession] = useState<Chat | null>(null);
  
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMode, setChatMode] = useState<ChatMode>('customer');
  const [chatLayout, setChatLayout] = useState<ChatLayoutMode>('floating');
  const [sdkTheme, setSdkTheme] = useState<SdkTheme>({
    primaryColor: '#2563eb',
    fontFamily: 'Inter, sans-serif',
    borderRadius: '1.5rem',
  });

  const [cart, setCart] = useState<CartItem[]>([]);

  const [showShareToast, setShowShareToast] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [voiceVolume, setVoiceVolume] = useState(0);
  
  const [ignoredFields, setIgnoredFields] = useState<Set<string>>(new Set());
  const [hiddenReviews, setHiddenReviews] = useState<Set<number>>(new Set());
  const [minRating, setMinRating] = useState<number>(3); 
  
  const [botConfig, setBotConfig] = useState<BotConfig>({
    botId: "bot_12345",
    botConfigId: "cfg_98765",
    agentProfile: {
      name: "Ava",
      role: "Concierge",
      discProfile: "Steadiness (Supportive, Patient)",
      basePrompt: "You are a friendly and knowledgeable AI concierge. You can recommend items from the menu and add them to the order."
    }
  });

  const voiceClient = useRef(new LiveVoiceClient());

  const handleAddToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.name === item.name);
      if (existing) {
        return prev.map(i => i.name === item.name ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    setIsChatOpen(true);
  };

  const handleRemoveFromCart = (name: string) => {
    setCart(prev => prev.filter(i => i.name !== name));
  };

  const handlePlaceSelect = async (place: any) => {
    setViewState(ViewState.LOADING);
    try {
      const data = await enrichBusinessData(place);
      setBusinessData(data);
      const session = createChatSession(data, botConfig.agentProfile);
      setChatSession(session);
      setViewState(ViewState.GENERATED);
    } catch (error) {
      console.error(error);
      setViewState(ViewState.ERROR);
    }
  };

  useEffect(() => {
    if (businessData) {
      const session = createChatSession(businessData, botConfig.agentProfile);
      setChatSession(session);
    }
  }, [botConfig.agentProfile, businessData]);

  const toggleVoice = useCallback(async () => {
    if (isVoiceActive) {
      voiceClient.current.disconnect();
      setIsVoiceActive(false);
    } else if (businessData) {
      voiceClient.current.onVolumeChange = setVoiceVolume;
      try {
        await voiceClient.current.connect(businessData, botConfig.agentProfile);
        setIsVoiceActive(true);
      } catch (e) {
        console.error("Failed to connect voice", e);
        alert("Microphone access is needed for voice concierge.");
      }
    }
  }, [isVoiceActive, businessData, botConfig.agentProfile]);

  const handleShare = async () => {
    const shareData = {
      title: businessData?.name || 'My Business Website',
      text: businessData?.tagline || 'Check out this amazing AI-generated business site!',
      url: window.location.href,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        setShowShareToast(true);
        setTimeout(() => setShowShareToast(false), 3000);
      }
    } catch (err) { console.error('Error sharing:', err); }
  };

  const handleReset = () => {
    setViewState(ViewState.LANDING);
    setBusinessData(null);
    setChatSession(null);
    setIsChatOpen(false);
    setIsVoiceActive(false);
    setCart([]);
    voiceClient.current.disconnect();
  };

  const filteredReviews = useMemo(() => {
    if (!businessData) return [];
    return businessData.reviews.filter((review, index) => {
      if (hiddenReviews.has(index)) return false;
      if (review.rating < minRating) return false;
      return true;
    });
  }, [businessData, hiddenReviews, minRating]);

  if (viewState === ViewState.LANDING || viewState === ViewState.LOADING || viewState === ViewState.ERROR) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 relative overflow-hidden font-sans">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
        <div className="z-10 w-full max-w-2xl px-6">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4 tracking-tight">AI Business SDK</h1>
            <p className="text-lg text-slate-600">Generate a business site and test the <span className="font-semibold text-blue-600">Standardized Chat Interface</span>.</p>
          </div>
          <PlaceSearch onPlaceSelect={handlePlaceSelect} isLoading={viewState === ViewState.LOADING} />
          {viewState === ViewState.ERROR && (
             <div className="mt-6 p-4 bg-red-50 text-red-600 rounded-xl">Generation Failed. Try again.</div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 animate-in fade-in duration-500 pb-24">
      <nav className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-100 px-6 py-4 flex justify-between items-center shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={handleReset} className="text-slate-400 hover:text-slate-600 transition-colors p-2 rounded-full hover:bg-slate-100">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" /></svg>
          </button>
          <div className="font-bold text-xl tracking-tight text-slate-900">{businessData?.name}</div>
        </div>
        <div className="flex gap-2 items-center">
           <button onClick={handleShare} className="p-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-all border border-slate-200">
             <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" /></svg>
           </button>
           <button onClick={toggleVoice} className={`px-4 py-2 text-sm font-medium rounded-full transition-colors flex items-center gap-2 shadow-lg ${isVoiceActive ? 'bg-red-500 text-white hover:bg-red-600' : 'bg-slate-900 text-white hover:bg-slate-800 shadow-slate-900/20'}`}>
             <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">{isVoiceActive ? <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /> : <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z" />}</svg>
             {isVoiceActive ? 'End Call' : 'Concierge'}
           </button>
        </div>
      </nav>

      {showShareToast && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-4 py-2 rounded-xl shadow-2xl animate-in slide-in-from-top-4 fade-in duration-300 flex items-center gap-2 text-sm font-medium">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-4 h-4 text-emerald-400"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" /></svg>
          Link copied to clipboard!
        </div>
      )}

      <main>
        {businessData && (
          <>
            <HeroSection data={businessData} onVoiceToggle={toggleVoice} onChatClick={() => setIsChatOpen(true)} isVoiceActive={isVoiceActive} voiceVolume={voiceVolume} />
            <InfoGrid data={businessData} ignoredFields={ignoredFields} filteredReviews={filteredReviews} />
            {businessData.menu ? (
              <MenuSection menu={businessData.menu} onAddToCart={handleAddToCart} categoryType={businessData.categoryType} />
            ) : (
              <BlogSection restaurants={businessData.nearbyRestaurants} activities={businessData.nearbyActivities} />
            )}
            <div className="max-w-7xl mx-auto px-6 py-12 mb-20 text-center border-t border-slate-200">
              <p className="text-slate-400 text-sm">Generated with Gemini 3 • Data provided by Google Maps • <a href={businessData.mapLink} target="_blank" rel="noreferrer" className="underline hover:text-slate-600">View on Maps</a></p>
            </div>
          </>
        )}
      </main>

      {businessData && (
        <StandardizedChatInterface 
          mode={chatMode} layoutMode={chatLayout} chatSession={chatSession} botConfig={botConfig} isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)} onModeChange={setChatMode} onLayoutChange={setChatLayout} theme={sdkTheme}
          onUpdateTheme={(t) => setSdkTheme(prev => ({...prev, ...t}))}
          onUpdateBotConfig={(cfg) => setBotConfig(prev => ({...prev, agentProfile: {...prev.agentProfile, ...cfg}}))}
          crmData={MOCK_CRM} tasks={MOCK_TASKS} calls={MOCK_CALLS} businessData={businessData} onUpdateBusinessData={setBusinessData}
          cart={cart} onAddToCart={handleAddToCart} onRemoveFromCart={handleRemoveFromCart}
        />
      )}
      
      {!isChatOpen && !isVoiceActive && (
        <button onClick={() => setIsChatOpen(true)} className="fixed bottom-6 right-6 w-14 h-14 text-white rounded-full shadow-xl transition-transform hover:scale-105 flex items-center justify-center z-40" style={{ backgroundColor: sdkTheme.primaryColor }}>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-7 h-7">
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" />
          </svg>
          {cart.length > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full ring-2 ring-white animate-bounce">{cart.length}</span>}
        </button>
      )}

      <VoiceIndicator isActive={isVoiceActive} volume={voiceVolume} onStop={toggleVoice} />
    </div>
  );
};

export default App;
