import React, { useState, useEffect, useRef } from 'react';
import { Chat } from "@google/genai";
import { ChatMessage, ChatMode, ChatLayoutMode, SdkTheme, CrmContact, Task, CallLog, BotConfig, AdminAuthStatus, WorkspaceStep, SwotAnalysis, ConsultingTask, BusinessData, AgentConfig, MenuItem, CartItem } from '../types';
import { generateBusinessSWOT, generateMarketingImage } from '../services/geminiService';

interface Props {
  mode: ChatMode;
  layoutMode: ChatLayoutMode;
  chatSession: Chat | null;
  botConfig: BotConfig;
  isOpen: boolean;
  onClose: () => void;
  onModeChange: (mode: ChatMode) => void;
  onLayoutChange: (mode: ChatLayoutMode) => void;
  theme?: SdkTheme;
  onUpdateTheme?: (theme: Partial<SdkTheme>) => void;
  onUpdateBotConfig?: (config: Partial<AgentConfig>) => void;
  crmData?: CrmContact[];
  tasks?: Task[];
  calls?: CallLog[];
  businessData?: BusinessData;
  onUpdateBusinessData?: (data: BusinessData) => void;
  cart: CartItem[];
  onAddToCart: (item: MenuItem) => void;
  onRemoveFromCart: (name: string) => void;
}

const defaultTheme: SdkTheme = {
  primaryColor: '#2563eb',
  fontFamily: 'Inter, sans-serif',
  borderRadius: '1.5rem',
};

const StandardizedChatInterface: React.FC<Props> = ({ 
  mode, 
  layoutMode,
  chatSession, 
  botConfig,
  isOpen, 
  onClose,
  onModeChange,
  onLayoutChange,
  theme = defaultTheme,
  onUpdateTheme,
  onUpdateBotConfig,
  crmData = [],
  tasks = [],
  calls = [],
  businessData,
  onUpdateBusinessData,
  cart,
  onAddToCart,
  onRemoveFromCart
}) => {
  const [activeView, setActiveView] = useState<'chat' | 'cart' | 'cashier' | 'dashboard' | 'website' | 'crm' | 'tasks' | 'calls' | 'settings' | 'customizer'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const [authStatus, setAuthStatus] = useState<AdminAuthStatus>('idle');
  const [isProcessing, setIsProcessing] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'form' | 'success'>('form');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Coupon State
  const [couponInput, setCouponInput] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(0); // decimal percentage e.g. 0.1 for 10%
  const [couponError, setCouponError] = useState('');

  // Form State for Checkout
  const [paymentInfo, setPaymentInfo] = useState({
    name: '',
    cardNumber: '',
    expiry: '',
    cvc: '',
    method: 'card'
  });

  const [editForm, setEditForm] = useState({ name: businessData?.name || '', tagline: businessData?.tagline || '', description: businessData?.description || '' });

  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{ 
        role: 'model', 
        text: `Hi! I'm ${botConfig.agentProfile.name}, your personal concierge for ${businessData?.name}. How can I help you today?` 
      }]);
    }
  }, [botConfig, businessData]);

  useEffect(() => {
    if (businessData) {
        setEditForm({ name: businessData.name, tagline: businessData.tagline, description: businessData.description });
    }
  }, [businessData]);

  useEffect(() => {
    if (mode === 'customer' && !['cart', 'cashier'].includes(activeView)) {
      setActiveView('chat');
    } else if (mode === 'owner') {
      setActiveView('dashboard');
    }
  }, [mode]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, activeView, isOpen, layoutMode]);

  const handleAdminRequest = () => {
    setIsMenuOpen(false);
    if (authStatus === 'authenticated') {
        setActiveView('dashboard');
        onModeChange('owner');
        return;
    }
    setAuthStatus('awaiting_otp');
    setActiveView('chat');
    setMessages(prev => [...prev, { 
      role: 'model', 
      text: "🔒 **Admin Access Requested**\n\nEnter the **6-digit code** to access agent settings." 
    }]);
  };

  const handleMenuNavigation = (view: typeof activeView) => {
    setActiveView(view);
    setIsMenuOpen(false);
  };

  const handleApplyCoupon = () => {
    setCouponError('');
    if (couponInput.toUpperCase() === 'SAVE10') {
      setAppliedDiscount(0.1);
    } else if (couponInput.toUpperCase() === 'WELCOME') {
      setAppliedDiscount(0.15);
    } else {
      setCouponError('Invalid coupon code');
      setAppliedDiscount(0);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || !chatSession) return;
    const userMsg = input;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setIsTyping(true);

    if (authStatus === 'awaiting_otp') {
        if (/^\d{6}$/.test(userMsg.trim())) {
            setTimeout(() => {
                setIsTyping(false);
                setAuthStatus('authenticated');
                setMessages(prev => [...prev, { role: 'model', text: "✅ **Access Granted**\n\nWelcome back!" }]);
                onModeChange('owner');
                setActiveView('dashboard'); 
            }, 1000);
            return;
        }
    }

    try {
      const response = await chatSession.sendMessage({ message: userMsg });
      
      if (response.functionCalls && response.functionCalls.length > 0) {
        for (const fc of response.functionCalls) {
          if (fc.name === 'recommendItem') {
            const args = fc.args as any;
            const fallbackImg = `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&q=80`;
            
            setMessages(prev => [...prev, { 
                role: 'model', 
                text: response.text || `I found exactly what you're looking for: **${args.name}**`, 
                isProductCard: true, 
                productData: {
                    name: args.name,
                    price: args.price,
                    description: args.description,
                    imageUrl: fallbackImg
                }
            }]);
          }
        }
      } else {
        const text = response.text || "I'm sorry, I couldn't process that.";
        setMessages(prev => [...prev, { role: 'model', text }]);
      }
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: "Connection error. Please try again." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
        setIsProcessing(false);
        setCheckoutStep('success');
    }, 2000);
  };

  const totalCartPrice = cart.reduce((acc, item) => {
    const p = parseFloat(item.price.replace(/[^0-9.]/g, ''));
    return acc + (isNaN(p) ? 0 : p * item.quantity);
  }, 0);

  const discountAmount = totalCartPrice * appliedDiscount;
  const subtotalWithDiscount = totalCartPrice - discountAmount;
  const finalTotal = subtotalWithDiscount * 1.08; // adding tax

  const primaryStyle = { backgroundColor: theme.primaryColor, color: '#fff' };

  const getContainerClasses = () => {
    const baseClasses = "fixed flex flex-col bg-white shadow-2xl overflow-hidden border border-slate-200 z-[60] animate-in fade-in duration-300 font-sans transition-all ease-in-out";
    const mobileClasses = "inset-0 w-full h-full rounded-none";
    let desktopClasses = "";
    switch(layoutMode) {
      case 'fixed': desktopClasses = "md:inset-y-0 md:right-0 md:left-auto md:bottom-0 md:top-0 md:w-[500px] md:h-full md:rounded-none md:border-l"; break;
      case 'fullscreen': desktopClasses = "md:inset-0 md:w-full md:h-full md:rounded-none"; break;
      case 'floating': default: desktopClasses = "md:inset-auto md:bottom-6 md:right-6 md:w-[400px] md:h-[650px] md:rounded-2xl"; break;
    }
    return `${baseClasses} ${mobileClasses} ${desktopClasses}`;
  };

  // --- MENU COMPONENT ---
  const renderMenu = () => (
    <div className="absolute inset-0 bg-slate-50 z-50 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-white shadow-sm shrink-0">
            <h3 className="font-bold text-slate-800 text-lg">System Options</h3>
            <button 
                onClick={() => setIsMenuOpen(false)} 
                className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-500"
            >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            {/* CLIENT OPTIONS - Prominent */}
            <div>
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <span className="w-8 h-px bg-slate-300"></span>
                    Client Options
                    <span className="flex-1 h-px bg-slate-300"></span>
                </h4>
                <div className="grid grid-cols-1 gap-3">
                    <button 
                        onClick={() => handleMenuNavigation('chat')} 
                        className="flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md hover:border-blue-300 transition-all group text-left"
                    >
                        <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" />
                            </svg>
                        </div>
                        <div>
                            <span className="block font-bold text-slate-900">Chat</span>
                            <span className="text-xs text-slate-500">Ask questions & get recommendations</span>
                        </div>
                    </button>

                    <button 
                        onClick={() => handleMenuNavigation('cart')} 
                        className="flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md hover:border-blue-300 transition-all group text-left relative"
                    >
                        <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
                            </svg>
                        </div>
                        <div>
                            <span className="block font-bold text-slate-900">Shopping Cart</span>
                            <span className="text-xs text-slate-500">View selected items</span>
                        </div>
                        {cart.length > 0 && (
                            <span className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full shadow-sm">
                                {cart.length}
                            </span>
                        )}
                    </button>

                    <button 
                        onClick={() => handleMenuNavigation('cashier')} 
                        className="flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md hover:border-blue-300 transition-all group text-left"
                    >
                        <div className="w-10 h-10 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5z" />
                            </svg>
                        </div>
                        <div>
                            <span className="block font-bold text-slate-900">Cashier</span>
                            <span className="text-xs text-slate-500">Checkout and pay</span>
                        </div>
                    </button>

                    <button 
                        onClick={() => handleMenuNavigation('chat')} 
                        className="flex items-center gap-4 p-4 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md hover:border-blue-300 transition-all group text-left"
                    >
                        <div className="w-10 h-10 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                            </svg>
                        </div>
                        <div>
                            <span className="block font-bold text-slate-900">Customer Service</span>
                            <span className="text-xs text-slate-500">Get help with orders</span>
                        </div>
                    </button>
                </div>
            </div>

            {/* ADMIN ACCESS - Less Prominent */}
            <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Business Access</h4>
                <button 
                    onClick={handleAdminRequest} 
                    className="w-full flex items-center gap-3 p-3 text-slate-600 hover:bg-slate-200 hover:text-slate-900 rounded-lg transition-colors text-left"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
                    </svg>
                    <span className="font-medium text-sm">Admin Dashboard</span>
                </button>
            </div>
        </div>

        {/* SDK TOOLS - Bottom */}
        <div className="p-4 border-t border-slate-200 bg-white shrink-0">
             <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">SDK Tools</h4>
             <button 
                onClick={() => handleMenuNavigation('customizer')} 
                className="w-full flex items-center gap-3 p-3 text-slate-600 hover:bg-slate-200 hover:text-slate-900 rounded-lg transition-colors text-left"
             >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122l9.37-9.37a2.828 2.828 0 114 4.001l-9.37 9.37a4.5 4.5 0 01-1.697 1.134l-2.623.873a.75.75 0 01-.921-.921l.873-2.623a4.5 4.5 0 011.134-1.697zM15 8.121l1.77-1.77m-1.77 1.77l1.77 1.77m-1.77-1.77l-1.77-1.77" />
                </svg>
                <span className="font-medium text-sm">SDK Settings</span>
             </button>
        </div>
    </div>
  );

  const renderCartView = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300 h-full flex flex-col">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg text-slate-800">Your Order</h3>
        <button onClick={() => setActiveView('chat')} className="text-xs text-blue-600 font-bold uppercase tracking-wider">Back to Chat</button>
      </div>

      {cart.length === 0 ? (
        <div className="text-center py-20 bg-slate-50 rounded-2xl border border-dashed border-slate-200 flex-1 flex flex-col justify-center">
          <p className="text-slate-400 text-sm">Your cart is empty.</p>
          <button onClick={() => setActiveView('chat')} className="text-blue-600 font-bold text-xs mt-4">Order something tasty!</button>
        </div>
      ) : (
        <div className="space-y-4 flex-1 overflow-y-auto">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm divide-y divide-slate-100">
            {cart.map((item, idx) => (
              <div key={idx} className="p-4 flex gap-4">
                <div className="w-16 h-16 bg-slate-100 rounded-lg overflow-hidden shrink-0 border border-slate-100">
                   <img 
                     src={item.imageUrl || `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=100&q=80`} 
                     alt={item.name} 
                     className="w-full h-full object-cover" 
                   />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-bold text-slate-900 text-sm">{item.name}</h4>
                    <span className="font-bold text-slate-900 text-sm">{item.price}</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-xs text-slate-500 font-medium">Qty: {item.quantity}</span>
                    <button onClick={() => onRemoveFromCart(item.name)} className="text-[10px] text-red-500 font-bold uppercase hover:underline">Remove</button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl mt-auto">
             <div className="flex justify-between items-center mb-6">
               <span className="text-slate-400 text-sm font-medium">Order Total</span>
               <span className="text-2xl font-black">${totalCartPrice.toFixed(2)}</span>
             </div>
             <button 
                onClick={() => { setActiveView('cashier'); setCheckoutStep('form'); }}
                className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-all shadow-lg active:scale-95"
             >
               Proceed to Cashier
             </button>
          </div>
        </div>
      )}
    </div>
  );

  const renderCashierView = () => {
    if (checkoutStep === 'success') {
        return (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-6 animate-in zoom-in-95 duration-500">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center shadow-inner">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" className="w-10 h-10">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                    </svg>
                </div>
                <div>
                    <h3 className="text-2xl font-black text-slate-900">Order Placed!</h3>
                    <p className="text-slate-500 text-sm mt-2">Your receipt has been sent to your email.</p>
                </div>
                <button 
                    onClick={() => { setActiveView('chat'); }}
                    style={primaryStyle}
                    className="px-8 py-3 rounded-xl font-bold text-sm shadow-lg hover:opacity-90"
                >
                    Return to Shop
                </button>
            </div>
        );
    }

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300 h-full flex flex-col overflow-y-auto">
            <div className="flex justify-between items-center">
                <h3 className="font-bold text-lg text-slate-800">Cashier</h3>
                <button onClick={() => setActiveView('cart')} className="text-xs text-slate-400 font-bold uppercase tracking-wider">Back to Cart</button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm font-medium text-slate-500">
                        <span>Items Total</span>
                        <span>${totalCartPrice.toFixed(2)}</span>
                    </div>
                    {appliedDiscount > 0 && (
                        <div className="flex justify-between items-center text-sm font-bold text-green-600">
                            <span>Discount ({appliedDiscount * 100}%)</span>
                            <span>-${discountAmount.toFixed(2)}</span>
                        </div>
                    )}
                    <div className="flex justify-between items-center pt-2 border-t border-slate-200 text-lg font-black text-slate-900">
                        <span>Final Total</span>
                        <span className="text-blue-600">${finalTotal.toFixed(2)}</span>
                    </div>
                </div>
            </div>

            {/* Coupon Code Section */}
            <div className="bg-white p-4 rounded-xl border border-slate-200">
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Coupon Code</label>
                <div className="flex gap-2">
                    <input 
                        type="text"
                        value={couponInput}
                        onChange={(e) => setCouponInput(e.target.value)}
                        placeholder="e.g. SAVE10"
                        className="flex-1 px-4 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none uppercase"
                    />
                    <button 
                        type="button"
                        onClick={handleApplyCoupon}
                        className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-lg hover:bg-slate-800 transition-colors"
                    >
                        Apply
                    </button>
                </div>
                {couponError && <p className="text-red-500 text-[10px] font-bold mt-1">{couponError}</p>}
                {appliedDiscount > 0 && <p className="text-green-600 text-[10px] font-bold mt-1">✓ Coupon applied successfully!</p>}
            </div>

            <form onSubmit={handleCheckoutSubmit} className="space-y-5 pb-8">
                <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Payment Method</label>
                    <div className="grid grid-cols-3 gap-2">
                        {['card', 'apple', 'google'].map(m => (
                            <button 
                                key={m}
                                type="button"
                                onClick={() => setPaymentInfo({...paymentInfo, method: m})}
                                className={`py-3 border-2 rounded-xl flex items-center justify-center transition-all ${paymentInfo.method === m ? 'border-blue-600 bg-blue-50' : 'border-slate-100 bg-white hover:border-slate-300'}`}
                            >
                                {m === 'card' && <svg className="w-6 h-6 text-slate-700" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>}
                                {m === 'apple' && <span className="font-bold text-slate-900">Apple</span>}
                                {m === 'google' && <span className="font-bold text-slate-900">Google</span>}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="space-y-4">
                    <div>
                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5">Cardholder Name</label>
                        <input 
                            required
                            type="text" 
                            className="w-full px-4 py-3 bg-white text-slate-900 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="John Doe"
                            value={paymentInfo.name}
                            onChange={e => setPaymentInfo({...paymentInfo, name: e.target.value})}
                        />
                    </div>
                    <div>
                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5">Card Number</label>
                        <input 
                            required
                            type="text" 
                            className="w-full px-4 py-3 bg-white text-slate-900 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="0000 0000 0000 0000"
                            value={paymentInfo.cardNumber}
                            onChange={e => setPaymentInfo({...paymentInfo, cardNumber: e.target.value})}
                        />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5">Expiry Date</label>
                            <input 
                                required
                                type="text" 
                                className="w-full px-4 py-3 bg-white text-slate-900 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                                placeholder="MM/YY"
                                value={paymentInfo.expiry}
                                onChange={e => setPaymentInfo({...paymentInfo, expiry: e.target.value})}
                            />
                        </div>
                        <div>
                            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1.5">CVC</label>
                            <input 
                                required
                                type="text" 
                                className="w-full px-4 py-3 bg-white text-slate-900 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                                placeholder="123"
                                value={paymentInfo.cvc}
                                onChange={e => setPaymentInfo({...paymentInfo, cvc: e.target.value})}
                            />
                        </div>
                    </div>
                </div>

                <button 
                    disabled={isProcessing}
                    style={primaryStyle}
                    className="w-full py-4 rounded-xl font-bold shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-70 mt-4"
                >
                    {isProcessing ? (
                        <>
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                            Processing...
                        </>
                    ) : (
                        `Complete Purchase • $${finalTotal.toFixed(2)}`
                    )}
                </button>
            </form>
        </div>
    );
  };

  const renderSdkCustomizer = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300 h-full">
        <div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500 rounded-full blur-3xl opacity-20"></div>
            <div className="relative z-10">
                <h3 className="font-bold text-lg mb-1">SDK Appearance</h3>
                <p className="text-xs text-slate-400">Configure how the chat agent looks and behaves.</p>
            </div>
        </div>
        <div className="space-y-5 px-1">
            <div>
               <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 block">Layout Mode</label>
               <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1 rounded-xl">
                  {['floating', 'fixed', 'fullscreen'].map((m) => (
                    <button key={m} onClick={() => onLayoutChange(m as ChatLayoutMode)} className={`text-xs py-2 rounded-lg capitalize transition-all font-semibold ${layoutMode === m ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}>{m}</button>
                  ))}
               </div>
            </div>
            <div>
               <label className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 block">Brand Theme Color</label>
               <div className="flex flex-wrap gap-3">
                  {['#2563eb', '#16a34a', '#dc2626', '#9333ea', '#ea580c', '#0f172a'].map(color => (
                     <button key={color} onClick={() => onUpdateTheme?.({ primaryColor: color })} className={`w-8 h-8 rounded-full border-2 transition-all shadow-sm ${theme.primaryColor === color ? 'border-slate-900 scale-110' : 'border-transparent hover:scale-105'}`} style={{ backgroundColor: color }} />
                  ))}
               </div>
            </div>
            <div className="pt-4">
                <button onClick={() => setActiveView('chat')} style={primaryStyle} className="w-full py-3 rounded-xl font-bold text-sm shadow-lg hover:opacity-90 transition-all">Apply & Return to Chat</button>
            </div>
        </div>
    </div>
  );

  if (!isOpen) return null;

  return (
    <div className={getContainerClasses()} style={{ borderRadius: layoutMode === 'floating' ? theme.borderRadius : '0', fontFamily: theme.fontFamily }}>
      <div className="p-4 flex justify-between items-center text-white transition-colors duration-300 shrink-0" style={{ backgroundColor: activeView === 'customizer' ? '#0f172a' : (mode === 'developer' ? '#0f172a' : (mode === 'owner' ? '#1e293b' : theme.primaryColor)) }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-sm font-bold border border-white/20">
            {activeView === 'customizer' ? <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path fillRule="evenodd" d="M20.599 1.5c-.376 0-.743.111-1.055.32l-5.08 3.385a18.747 18.747 0 00-3.471 2.987 10.04 10.04 0 01.712.129c1.017.23 2.006.604 2.935 1.106a18.75 18.75 0 002.987-3.472l3.385-5.08A1.875 1.875 0 0020.599 1.5zm-8.5 7.77a18.75 18.75 0 00-2.987 3.472l-3.385 5.08a1.875 1.875 0 001.875 1.875c.376 0 .743-.111 1.055-.32l5.08-3.385a18.75 18.75 0 003.472-2.988 10.04 10.04 0 01-.712-.128 9.986 9.986 0 01-2.935-1.106zM9.75 1.5c0-.828-.672-1.5-1.5-1.5s-1.5.672-1.5 1.5v1.5H5.25C4.422 3 3.75 3.672 3.75 4.5s.672 1.5 1.5 1.5h1.5v1.5c0 .828.672 1.5 1.5 1.5s1.5-.672 1.5-1.5V6h1.5c.828 0 1.5-.672 1.5-1.5S12.078 3 11.25 3H9.75V1.5zM3 13.5c-.828 0-1.5.672-1.5 1.5s.672 1.5 1.5 1.5h1.5v1.5c0 .828.672 1.5 1.5 1.5s1.5-.672 1.5-1.5V16.5h1.5c.828 0 1.5-.672 1.5-1.5s-.672-1.5-1.5-1.5H7.5V12c0-.828-.672-1.5-1.5-1.5s-1.5.672-1.5 1.5v1.5H3z" clipRule="evenodd" /></svg> : (mode === 'customer' ? 'AI' : mode === 'owner' ? 'Biz' : 'Dev')}
          </div>
          <div>
            <div className="font-bold leading-tight">{activeView === 'customizer' ? 'SDK Settings' : botConfig.agentProfile.name}</div>
            <div className="text-[10px] opacity-80 uppercase tracking-wider font-semibold">{activeView === 'customizer' ? 'Appearance' : (mode === 'customer' ? botConfig.agentProfile.role : `${mode} Portal`)}</div>
          </div>
        </div>
        
        <div className="flex items-center gap-1.5">
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)} 
            className={`p-1.5 rounded-full transition-all relative ${isMenuOpen ? 'bg-white text-slate-900 shadow-lg' : 'hover:bg-white/20 text-white'}`} 
            title="System Options"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
            </svg>
            {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 w-3 h-3 rounded-full border-2 border-white"></span>
            )}
          </button>
          
          <button onClick={onClose} className="hover:bg-white/20 p-1.5 rounded-full transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden relative bg-slate-50/50">
        <div className="absolute inset-0 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
            {activeView === 'chat' && (
                <div className="max-w-3xl mx-auto w-full">
                {messages.map((msg, i) => (
                    <div key={i} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} mb-4`}>
                    <div className={`max-w-[85%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed shadow-sm ${msg.role === 'user' ? 'text-white rounded-tr-none' : 'bg-white text-slate-700 border border-slate-100 rounded-tl-none'}`} style={msg.role === 'user' ? primaryStyle : {}}>
                        {msg.text.split('\n').map((line, idx) => (<p key={idx} className={idx > 0 ? 'mt-2' : ''}>{line.split('**').map((part, pIdx) => (pIdx % 2 === 1 ? <strong key={pIdx}>{part}</strong> : part))}</p>))}
                    </div>
                    {msg.isProductCard && msg.productData && (
                        <div className="mt-3 w-full max-w-[280px] bg-white rounded-2xl overflow-hidden shadow-xl border border-slate-100 animate-in zoom-in-95 duration-300">
                            <div className="h-40 bg-slate-100 overflow-hidden">
                            <img src={msg.productData.imageUrl || `https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&q=80`} alt={msg.productData.name} className="w-full h-full object-cover" />
                            </div>
                            <div className="p-4">
                            <div className="flex justify-between items-start gap-2 mb-2">
                                <h4 className="font-bold text-slate-900 text-sm leading-tight">{msg.productData.name}</h4>
                                <span className="font-bold text-blue-600 text-sm">{msg.productData.price}</span>
                            </div>
                            <p className="text-[11px] text-slate-500 line-clamp-2 mb-3 leading-relaxed italic">{msg.productData.description}</p>
                            <button onClick={() => onAddToCart(msg.productData!)} className="w-full py-2 bg-slate-900 hover:bg-blue-600 text-white text-[11px] font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-slate-900/10">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-3.5 h-3.5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>
                                Add to Order
                            </button>
                            </div>
                        </div>
                    )}
                    </div>
                ))}
                {isTyping && (
                    <div className="flex justify-start"><div className="bg-white px-4 py-3 rounded-2xl rounded-tl-none shadow-sm border border-slate-100"><div className="flex space-x-1"><div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div><div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-75"></div><div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-150"></div></div></div></div>
                )}
                </div>
            )}
            {activeView === 'cart' && renderCartView()}
            {activeView === 'cashier' && renderCashierView()}
            {activeView === 'dashboard' && <div className="space-y-6 animate-in fade-in duration-500"><div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg relative overflow-hidden"><div className="absolute top-0 right-0 w-32 h-32 bg-blue-500 rounded-full blur-3xl opacity-20"></div><div className="relative z-10"><h2 className="text-2xl font-bold">Biz Portal</h2><p className="text-slate-400 text-sm">Manage your operations here.</p></div></div></div>}
            {activeView === 'customizer' && renderSdkCustomizer()}
        </div>
        {isMenuOpen && renderMenu()}
      </div>

      {activeView === 'chat' && (
        <div className="p-4 bg-white border-t border-slate-100 shrink-0">
          <div className="flex gap-2 max-w-3xl mx-auto w-full">
            <input type="text" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} placeholder={authStatus === 'awaiting_otp' ? "Enter 6-digit code..." : "Tell me what you're looking for..."} className="flex-1 px-4 py-3 bg-slate-100 text-slate-900 rounded-full text-sm focus:outline-none focus:ring-2 focus:bg-white transition-all" style={{ caretColor: theme.primaryColor }} />
            <button onClick={handleSend} disabled={!input.trim()} style={input.trim() ? primaryStyle : {}} className={`p-3 rounded-full text-white transition-all hover:scale-105 active:scale-95 disabled:opacity-50 disabled:scale-100 ${!input.trim() ? 'bg-slate-300' : ''}`}><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" /></svg></button>
          </div>
        </div>
      )}
    </div>
  );
};

export default StandardizedChatInterface;