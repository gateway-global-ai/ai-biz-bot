# AI Biz Bot - Quick Reference Guide

**For:** Sales conversations and API recommendations  
**Version:** 1.0.0  
**Last Updated:** February 7, 2026

---

## 🎯 Decision Tree - Quick Navigation

```
What does the customer need?
│
├─ Maps/Location Services
│  ├─ Usage > 10K/month? → RECOMMEND OUR ALTERNATIVE (90% savings)
│  └─ Usage ≤ 10K/month? → Google free tier
│
├─ Speech Transcription
│  ├─ Usage > 100 hrs/month? → RECOMMEND OUR WHISPER (80% savings)
│  └─ Usage ≤ 100 hrs/month? → Google free tier
│
├─ Text Analysis (NLP)
│  ├─ Usage > 5K records/month? → RECOMMEND OUR NLP (85% savings)
│  └─ Usage ≤ 5K records/month? → Google free tier
│
├─ Document OCR → Google Vision AI (FREE!)
│
├─ Business Profile Management
│  ├─ 3+ locations? → Google Business Profile APIs (FREE)
│  └─ < 3 locations? → Manual management
│
├─ Route Optimization → RECOMMEND OUR ROUTING (80% savings)
│
├─ Translation
│  ├─ > 500K chars/month? → Evaluate alternatives
│  └─ ≤ 500K chars/month? → Google free tier
│
└─ Spreadsheet Automation → Google Sheets API (FREE)
```

---

## 💰 Pricing Cheat Sheet

### Google vs Our Alternatives

| Service | Google Price | Our Price | Savings |
|---------|-------------|-----------|---------|
| **Maps** (100K loads) | $700/mo | $50/mo | **93%** |
| **Geocoding** (1M req) | $5,000/mo | $200/mo | **96%** |
| **Speech** (1K hrs) | $960/mo | $100/mo | **90%** |
| **NLP** (100K records) | $200/mo | $30/mo | **85%** |
| **OCR** | FREE* | $200/mo | Use Google! |
| **Translation** (10M chars) | $200/mo | $150/mo | **25%** |

*Google Vision OCR text detection is free tier

---

## 🚨 Key Triggers - When to Recommend

### TRIGGER-001: Multi-Location Business
**When:** Customer has 3+ locations  
**Ask:** "Are you updating each Google Business Profile manually?"  
**Solution:** Google Business Profile APIs (FREE)  
**Our Upsell:** Multi-location management dashboard ($300/mo)

---

### TRIGGER-002: High-Volume Maps
**When:** > 10,000 map loads/month  
**Ask:** "Do you know how many times your map loads each month?"  
**Solution:** Our OpenStreetMap stack  
**Value Prop:** "Save 90% - from $700 to $50/month"

---

### TRIGGER-003: Call Transcription
**When:** 100+ hours of calls/month  
**Ask:** "How do you handle call recordings?"  
**Solution:** Our Whisper-based transcription  
**Value Prop:** "80% cost savings + on-premise privacy option"

---

### TRIGGER-004: Document OCR
**When:** Processing documents  
**Ask:** "Are you manually entering data from documents?"  
**Solution:** Google Vision AI (FREE!)  
**Value Prop:** "Google's OCR is completely FREE"

---

### TRIGGER-005: Customer Feedback Analysis
**When:** Collecting reviews/surveys  
**Ask:** "How do you analyze customer feedback?"  
**Solution:** Our NLP solution  
**Value Prop:** "AI analyzes everything automatically at 85% less cost"

---

## 🗣️ Conversation Starters

### Maps/Location
```
"I see you have a store locator on your website. 
Do you know how many times your map loads each month?"
```

### Speech Transcription
```
"How do you currently handle call recordings? 
Are you transcribing them for analysis?"
```

### Document Processing
```
"I understand you process a significant number of documents. 
Are you currently using any OCR technology?"
```

### Multi-Location
```
"I see you're managing [X] locations. 
Are you currently updating each Google Business Profile manually?"
```

### Customer Feedback
```
"How do you currently analyze customer feedback 
from reviews, surveys, or support tickets?"
```

---

## 🛡️ Objection Handling

### "It's too expensive"
```
"I understand budget is a concern. Let's look at your current costs - 
our solution typically saves customers 80-90% compared to what 
they're paying now."
```

### "It's too complicated"
```
"We handle all the technical setup and maintenance. 
You just use the service through a simple dashboard."
```

### "We're already using Google"
```
"Google's APIs are great for low volume. Let me show you 
how much you could save as you scale."
```

### "Data privacy concerns"
```
"Our solution can be deployed on your own servers, 
so your data never leaves your infrastructure."
```

### "We don't have a technical team"
```
"No technical team needed - we provide full managed 
service with 24/7 support."
```

---

## 📊 Value Propositions by Industry

### Retail / E-commerce
- **Maps:** Store locators, delivery tracking
- **Savings:** $3,600/year typical

### Healthcare
- **Speech:** Call transcription, dictation
- **OCR:** Patient forms, insurance documents
- **Savings:** $5,400/year typical

### Logistics / Delivery
- **Maps:** Route optimization, ETAs
- **Geocoding:** Address validation
- **Savings:** $8,640/year typical

### Financial Services
- **Speech:** Call recording compliance
- **NLP:** Customer feedback analysis
- **Savings:** $4,560/year typical

### Hospitality
- **Maps:** Location services
- **Speech:** Reservation calls
- **Savings:** $2,400/year typical

---

## 🎁 Free Tier Opportunities

Always mention these FREE options:

| Service | Free Tier | When to Use |
|---------|-----------|-------------|
| Google Vision OCR | 1,000+ units/month | Document processing |
| Google Sheets API | 300 req/min | Automation |
| Google Translation | 500K chars/month | Localization |
| Google Business Profile | Unlimited | Multi-location mgmt |
| Google Speech-to-Text | 60 min/month | Low volume testing |
| Google Natural Language | 5K records/month | Small-scale analysis |

---

## 🔄 Alternative Technology Stack

### Our Recommended Stack

**Maps:**
- OpenStreetMap (data)
- Leaflet.js (frontend)
- Nominatim (geocoding)
- OSRM (routing)

**Speech-to-Text:**
- OpenAI Whisper (large-v3)
- WhisperX (diarization)
- FastAPI (API layer)

**NLP:**
- spaCy (framework)
- Hugging Face Transformers (models)
- Redis (caching)

**OCR:**
- PaddleOCR (primary)
- Tesseract (fallback)
- OpenCV (preprocessing)

---

## 📈 Revenue Calculator

### Quick Estimates

| Service | Our Cost | Sell For | Margin | To Make $10K/mo |
|---------|----------|----------|--------|-----------------|
| Maps | $50 | $200 | 75% | 67 customers |
| Speech | $200 | $800 | 75% | 17 customers |
| NLP | $100 | $400 | 75% | 33 customers |
| GMB Mgmt | $50 | $300 | 83% | 40 customers |

---

## ✅ Checklist for Sales Calls

### Before the Call
- [ ] Research customer's industry
- [ ] Identify potential triggers
- [ ] Prepare relevant case studies
- [ ] Have pricing calculator ready

### During the Call
- [ ] Ask about current tools/solutions
- [ ] Quantify current costs (if any)
- [ ] Identify pain points
- [ ] Match to appropriate trigger
- [ ] Present solution with savings
- [ ] Address objections
- [ ] Propose next steps

### After the Call
- [ ] Send follow-up email with summary
- [ ] Provide relevant documentation
- [ ] Schedule technical demo if needed
- [ ] Add to CRM with trigger tags

---

## 🔗 Quick Links

- **Full Documentation:** `docs/google-business-apis-comprehensive-guide.md`
- **Pricing Matrix:** `comparisons/pricing-matrix.json`
- **Trigger Conditions:** `triggers/ai-biz-bot-triggers.json`
- **MCP Server:** `mcp-server/`
- **SDK Examples:** `sdk-examples/`

---

## 📞 Escalation Path

### Technical Questions
→ Technical Team / Solutions Architect

### Pricing Negotiation
→ Sales Manager

### Custom Requirements
→ Product Team

### Implementation Support
→ Customer Success

---

## 💡 Pro Tips

1. **Always lead with savings** - "Our customers typically save 80-90%"

2. **Quantify everything** - "That's $X per month, $Y per year"

3. **Use the free tier** - "Google offers this FREE up to X units"

4. **Emphasize privacy** - "Your data stays on your servers"

5. **No lock-in** - "Open source means you're never trapped"

6. **Start small** - "Let's pilot with one location first"

7. **Show, don't tell** - Use live demos when possible

---

**Remember:** Our goal is to help customers save money while building our recurring revenue. Always be consultative, not pushy.

---

*For detailed information, refer to the comprehensive guide in `docs/google-business-apis-comprehensive-guide.md`*
