#!/usr/bin/env node

/**
 * Google Business APIs MCP Server
 * 
 * This MCP server provides tools and resources for:
 * 1. Querying Google Business APIs documentation
 * 2. Comparing pricing between Google and alternatives
 * 3. Getting recommendations for API usage
 * 4. Accessing trigger conditions for AI Biz Bot
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ErrorCode,
  McpError,
} from "@modelcontextprotocol/sdk/types.js";
import { z } from "zod";
import * as fs from "fs/promises";
import * as path from "path";
import { fileURLToPath } from "url";

// Logger setup
const logger = {
  debug: (msg: string) => console.error(`[DEBUG] ${msg}`),
  info: (msg: string) => console.error(`[INFO] ${msg}`),
  warn: (msg: string) => console.error(`[WARN] ${msg}`),
  error: (msg: string) => console.error(`[ERROR] ${msg}`),
};

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Paths to knowledge base files
const KNOWLEDGE_BASE_PATH = path.join(__dirname, "../../docs");
const COMPARISONS_PATH = path.join(__dirname, "../../comparisons");
const TRIGGERS_PATH = path.join(__dirname, "../../triggers");

// In-memory cache for loaded data
let pricingMatrix: any = null;
let triggerConditions: any = null;

/**
 * Load JSON file with caching
 */
async function loadJsonFile(filePath: string): Promise<any> {
  try {
    const content = await fs.readFile(filePath, "utf-8");
    return JSON.parse(content);
  } catch (error) {
    logger.error(`Failed to load ${filePath}: ${error}`);
    throw new McpError(ErrorCode.InternalError, `Failed to load data: ${error}`);
  }
}

/**
 * Initialize data caches
 */
async function initializeCaches() {
  try {
    pricingMatrix = await loadJsonFile(path.join(COMPARISONS_PATH, "pricing-matrix.json"));
    triggerConditions = await loadJsonFile(path.join(TRIGGERS_PATH, "ai-biz-bot-triggers.json"));
    logger.info("Data caches initialized successfully");
  } catch (error) {
    logger.error(`Failed to initialize caches: ${error}`);
  }
}

/**
 * Create and configure MCP Server
 */
const server = new Server(
  {
    name: "google-apis-knowledge-base",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
      resources: {},
    },
  }
);

/**
 * Tool Definitions
 */
const TOOLS = [
  {
    name: "get_api_info",
    description: "Get comprehensive information about a specific Google Business API including pricing, access requirements, and alternatives",
    inputSchema: {
      type: "object",
      properties: {
        api_name: {
          type: "string",
          description: "Name of the API (e.g., 'Maps JavaScript API', 'Speech-to-Text API', 'Business Information API')",
        },
        category: {
          type: "string",
          enum: ["business_profile", "maps_platform", "ai_ml", "workspace"],
          description: "Category of the API",
        },
      },
      required: ["api_name"],
    },
  },
  {
    name: "compare_pricing",
    description: "Compare pricing between Google APIs and our alternative solutions",
    inputSchema: {
      type: "object",
      properties: {
        service: {
          type: "string",
          enum: ["maps", "geocoding", "speech_to_text", "ocr", "nlp", "translation", "places"],
          description: "Service to compare pricing for",
        },
        monthly_usage: {
          type: "number",
          description: "Estimated monthly usage (units vary by service)",
        },
        usage_unit: {
          type: "string",
          description: "Unit of usage (e.g., 'requests', 'hours', 'characters')",
        },
      },
      required: ["service", "monthly_usage"],
    },
  },
  {
    name: "get_recommendation",
    description: "Get API recommendations based on business needs and usage patterns",
    inputSchema: {
      type: "object",
      properties: {
        business_type: {
          type: "string",
          description: "Type of business (e.g., 'retail', 'healthcare', 'logistics')",
        },
        use_case: {
          type: "string",
          enum: ["maps", "transcription", "document_processing", "text_analysis", "translation", "business_management", "automation"],
          description: "Primary use case",
        },
        estimated_volume: {
          type: "string",
          enum: ["low", "medium", "high"],
          description: "Estimated usage volume",
        },
        location_count: {
          type: "number",
          description: "Number of business locations (if applicable)",
        },
      },
      required: ["use_case"],
    },
  },
  {
    name: "check_triggers",
    description: "Check which trigger conditions apply to a given business scenario",
    inputSchema: {
      type: "object",
      properties: {
        business_profile: {
          type: "object",
          properties: {
            location_count: { type: "number" },
            industry: { type: "string" },
            has_google_business_profile: { type: "boolean" },
          },
        },
        usage: {
          type: "object",
          properties: {
            estimated_monthly_map_loads: { type: "number" },
            estimated_monthly_call_hours: { type: "number" },
            estimated_monthly_documents: { type: "number" },
            estimated_monthly_feedback_items: { type: "number" },
          },
        },
        needs: {
          type: "array",
          items: { type: "string" },
          description: "List of business needs (e.g., 'route_optimization', 'call_transcription')",
        },
      },
      required: [],
    },
  },
  {
    name: "get_alternative_stack",
    description: "Get our recommended open-source alternative technology stack for a service",
    inputSchema: {
      type: "object",
      properties: {
        service: {
          type: "string",
          enum: ["maps", "speech_to_text", "nlp", "ocr", "translation"],
          description: "Service to get alternative stack for",
        },
        include_cost_estimate: {
          type: "boolean",
          description: "Include monthly cost estimate",
          default: true,
        },
      },
      required: ["service"],
    },
  },
  {
    name: "calculate_savings",
    description: "Calculate potential savings by switching from Google APIs to our alternatives",
    inputSchema: {
      type: "object",
      properties: {
        current_services: {
          type: "array",
          items: {
            type: "object",
            properties: {
              service: { type: "string" },
              monthly_usage: { type: "number" },
              usage_unit: { type: "string" },
            },
            required: ["service", "monthly_usage"],
          },
        },
        time_period: {
          type: "string",
          enum: ["monthly", "annual"],
          default: "annual",
        },
      },
      required: ["current_services"],
    },
  },
  {
    name: "get_conversation_script",
    description: "Get conversation script for a specific trigger to help sales conversations",
    inputSchema: {
      type: "object",
      properties: {
        trigger_id: {
          type: "string",
          description: "Trigger ID (e.g., 'TRIGGER-002')",
        },
        business_context: {
          type: "object",
          description: "Business context variables to populate the script",
        },
      },
      required: ["trigger_id"],
    },
  },
];

/**
 * List available tools
 */
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return { tools: TOOLS };
});

/**
 * Handle tool calls
 */
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  logger.info(`Tool called: ${name}`);

  try {
    switch (name) {
      case "get_api_info":
        return await handleGetApiInfo(args);
      case "compare_pricing":
        return await handleComparePricing(args);
      case "get_recommendation":
        return await handleGetRecommendation(args);
      case "check_triggers":
        return await handleCheckTriggers(args);
      case "get_alternative_stack":
        return await handleGetAlternativeStack(args);
      case "calculate_savings":
        return await handleCalculateSavings(args);
      case "get_conversation_script":
        return await handleGetConversationScript(args);
      default:
        throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`);
    }
  } catch (error) {
    logger.error(`Error in tool ${name}: ${error}`);
    if (error instanceof McpError) {
      throw error;
    }
    throw new McpError(ErrorCode.InternalError, `Tool execution failed: ${error}`);
  }
});

/**
 * Handle get_api_info tool
 */
async function handleGetApiInfo(args: any) {
  const { api_name, category } = args;

  if (!pricingMatrix) {
    throw new McpError(ErrorCode.InternalError, "Pricing data not loaded");
  }

  // Search across all categories
  const categories = category ? [category] : Object.keys(pricingMatrix.categories);
  
  for (const cat of categories) {
    const catData = pricingMatrix.categories[cat];
    if (!catData) continue;

    const api = catData.apis?.find((a: any) => 
      a.name.toLowerCase().includes(api_name.toLowerCase())
    );

    if (api) {
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify({
              category: catData.name,
              api: api,
              documentation_url: getDocumentationUrl(cat, api.name),
            }, null, 2),
          },
        ],
      };
    }
  }

  throw new McpError(ErrorCode.InvalidRequest, `API '${api_name}' not found`);
}

/**
 * Handle compare_pricing tool
 */
async function handleComparePricing(args: any) {
  const { service, monthly_usage, usage_unit } = args;

  if (!pricingMatrix) {
    throw new McpError(ErrorCode.InternalError, "Pricing data not loaded");
  }

  const comparison = calculatePricingComparison(service, monthly_usage);

  return {
    content: [
      {
        type: "text",
        text: JSON.stringify(comparison, null, 2),
      },
    ],
  };
}

/**
 * Handle get_recommendation tool
 */
async function handleGetRecommendation(args: any) {
  const { business_type, use_case, estimated_volume, location_count } = args;

  if (!triggerConditions) {
    throw new McpError(ErrorCode.InternalError, "Trigger data not loaded");
  }

  // Find matching triggers
  const matchingTriggers = triggerConditions.triggers.filter((trigger: any) => {
    // Check use case match
    if (trigger.name.toLowerCase().includes(use_case.replace("_", " "))) {
      return true;
    }
    // Check location count for multi-location trigger
    if (location_count && location_count >= 3 && trigger.id === "TRIGGER-001") {
      return true;
    }
    return false;
  });

  const recommendations = matchingTriggers.map((trigger: any) => ({
    trigger_id: trigger.id,
    trigger_name: trigger.name,
    recommendation: trigger.recommendation,
    our_service: trigger.our_service_opportunity,
  }));

  return {
    content: [
      {
        type: "text",
        text: JSON.stringify({
          business_context: { business_type, use_case, estimated_volume, location_count },
          recommendations: recommendations,
        }, null, 2),
      },
    ],
  };
}

/**
 * Handle check_triggers tool
 */
async function handleCheckTriggers(args: any) {
  const { business_profile, usage, needs } = args;

  if (!triggerConditions) {
    throw new McpError(ErrorCode.InternalError, "Trigger data not loaded");
  }

  const matchedTriggers = [];

  for (const trigger of triggerConditions.triggers) {
    let matches = true;

    // Check location count
    if (trigger.conditions.all) {
      for (const condition of trigger.conditions.all) {
        if (condition.field === "business.location_count" && business_profile?.location_count) {
          if (condition.operator === ">=" && business_profile.location_count < condition.value) {
            matches = false;
          }
        }
      }
    }

    // Check usage thresholds
    if (usage?.estimated_monthly_map_loads > 10000 && trigger.id === "TRIGGER-002") {
      matchedTriggers.push(trigger);
      continue;
    }

    if (usage?.estimated_monthly_call_hours > 100 && trigger.id === "TRIGGER-003") {
      matchedTriggers.push(trigger);
      continue;
    }

    if (matches && trigger.id !== "TRIGGER-002" && trigger.id !== "TRIGGER-003") {
      matchedTriggers.push(trigger);
    }
  }

  return {
    content: [
      {
        type: "text",
        text: JSON.stringify({
          input: { business_profile, usage, needs },
          matched_triggers: matchedTriggers.map((t: any) => ({
            id: t.id,
            name: t.name,
            recommendation: t.recommendation.primary,
            value_proposition: t.recommendation.value_proposition,
          })),
        }, null, 2),
      },
    ],
  };
}

/**
 * Handle get_alternative_stack tool
 */
async function handleGetAlternativeStack(args: any) {
  const { service, include_cost_estimate } = args;

  if (!pricingMatrix) {
    throw new McpError(ErrorCode.InternalError, "Pricing data not loaded");
  }

  const stack = pricingMatrix.alternative_technology_stack[service];

  if (!stack) {
    throw new McpError(ErrorCode.InvalidRequest, `No alternative stack found for '${service}'`);
  }

  return {
    content: [
      {
        type: "text",
        text: JSON.stringify({
          service: service,
          alternative_stack: stack,
          estimated_monthly_cost: include_cost_estimate ? stack.estimated_monthly_cost : undefined,
        }, null, 2),
      },
    ],
  };
}

/**
 * Handle calculate_savings tool
 */
async function handleCalculateSavings(args: any) {
  const { current_services, time_period } = args;

  if (!pricingMatrix) {
    throw new McpError(ErrorCode.InternalError, "Pricing data not loaded");
  }

  let totalGoogleCost = 0;
  let totalOurCost = 0;
  const serviceBreakdown = [];

  for (const svc of current_services) {
    const comparison = calculatePricingComparison(svc.service, svc.monthly_usage);
    const multiplier = time_period === "annual" ? 12 : 1;

    const googleCost = (comparison.google_cost || 0) * multiplier;
    const ourCost = (comparison.our_cost || 0) * multiplier;

    totalGoogleCost += googleCost;
    totalOurCost += ourCost;

    serviceBreakdown.push({
      service: svc.service,
      monthly_usage: svc.monthly_usage,
      google_cost: googleCost,
      our_cost: ourCost,
      savings: googleCost - ourCost,
      savings_percentage: googleCost > 0 ? ((googleCost - ourCost) / googleCost * 100).toFixed(1) : "0",
    });
  }

  const totalSavings = totalGoogleCost - totalOurCost;
  const savingsPercentage = totalGoogleCost > 0 ? (totalSavings / totalGoogleCost * 100).toFixed(1) : "0";

  return {
    content: [
      {
        type: "text",
        text: JSON.stringify({
          time_period: time_period,
          services: serviceBreakdown,
          summary: {
            total_google_cost: totalGoogleCost,
            total_our_cost: totalOurCost,
            total_savings: totalSavings,
            savings_percentage: `${savingsPercentage}%`,
          },
        }, null, 2),
      },
    ],
  };
}

/**
 * Handle get_conversation_script tool
 */
async function handleGetConversationScript(args: any) {
  const { trigger_id, business_context } = args;

  if (!triggerConditions) {
    throw new McpError(ErrorCode.InternalError, "Trigger data not loaded");
  }

  const trigger = triggerConditions.triggers.find((t: any) => t.id === trigger_id);

  if (!trigger) {
    throw new McpError(ErrorCode.InvalidRequest, `Trigger '${trigger_id}' not found`);
  }

  // Replace placeholders in script
  let script = { ...trigger.conversation_script };
  
  if (business_context) {
    for (const [key, value] of Object.entries(business_context)) {
      const placeholder = `{${key}}`;
      script.opening = script.opening.replace(placeholder, String(value));
      script.pain_point = script.pain_point.replace(placeholder, String(value));
      script.solution = script.solution.replace(placeholder, String(value));
    }
  }

  return {
    content: [
      {
        type: "text",
        text: JSON.stringify({
          trigger_id: trigger.id,
          trigger_name: trigger.name,
          script: script,
          objection_handling: triggerConditions.conversation_guidelines.objection_handling,
        }, null, 2),
      },
    ],
  };
}

/**
 * Helper function to calculate pricing comparison
 */
function calculatePricingComparison(service: string, monthlyUsage: number) {
  const serviceMap: Record<string, { category: string; apiName: string }> = {
    maps: { category: "maps_platform", apiName: "Maps JavaScript API" },
    geocoding: { category: "maps_platform", apiName: "Geocoding API" },
    places: { category: "maps_platform", apiName: "Places API" },
    speech_to_text: { category: "ai_ml", apiName: "Speech-to-Text API" },
    ocr: { category: "ai_ml", apiName: "Vision AI" },
    nlp: { category: "ai_ml", apiName: "Natural Language API" },
    translation: { category: "ai_ml", apiName: "Translation API" },
  };

  const mapping = serviceMap[service];
  if (!mapping) {
    return { error: `Unknown service: ${service}` };
  }

  const category = pricingMatrix.categories[mapping.category];
  const api = category?.apis?.find((a: any) => a.name.includes(mapping.apiName.split(" ")[0]));

  if (!api) {
    return { error: `API data not found for ${service}` };
  }

  // Calculate Google cost
  let googleCost = 0;
  if (api.pricing.essentials || api.pricing.standard_v2) {
    const pricing = api.pricing.essentials || api.pricing.standard_v2;
    const freeTier = pricing.free || 10000;
    const per1k = pricing.per_1k || 0.016;
    
    if (monthlyUsage > freeTier) {
      const billableUnits = Math.ceil((monthlyUsage - freeTier) / 1000);
      googleCost = billableUnits * per1k;
    }
  }

  // Get our alternative cost
  const ourAlternative = api.our_alternative;
  const ourCost = ourAlternative?.our_cost_per_month || 0;

  return {
    service: service,
    monthly_usage: monthlyUsage,
    google_cost: googleCost,
    our_cost: ourCost,
    monthly_savings: googleCost - ourCost,
    savings_percentage: googleCost > 0 ? ((googleCost - ourCost) / googleCost * 100).toFixed(1) : "0",
    alternative: ourAlternative,
  };
}

/**
 * Get documentation URL for an API
 */
function getDocumentationUrl(category: string, apiName: string): string {
  const docs: Record<string, string> = {
    "business_profile": "https://developers.google.com/my-business",
    "maps_platform": "https://developers.google.com/maps/documentation",
    "ai_ml": "https://cloud.google.com/products/ai",
    "workspace": "https://developers.google.com/workspace",
  };
  return docs[category] || "https://developers.google.com";
}

/**
 * Resource Definitions
 */
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: "knowledge-base://pricing-matrix",
        name: "Complete Pricing Matrix",
        mimeType: "application/json",
        description: "Full pricing comparison between Google APIs and alternatives",
      },
      {
        uri: "knowledge-base://trigger-conditions",
        name: "AI Biz Bot Trigger Conditions",
        mimeType: "application/json",
        description: "Trigger conditions for automated recommendations",
      },
      {
        uri: "knowledge-base://alternative-stacks",
        name: "Alternative Technology Stacks",
        mimeType: "application/json",
        description: "Recommended open-source alternatives for each service",
      },
    ],
  };
});

/**
 * Handle resource requests
 */
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const { uri } = request.params;

  try {
    switch (uri) {
      case "knowledge-base://pricing-matrix":
        return {
          contents: [
            {
              uri,
              mimeType: "application/json",
              text: JSON.stringify(pricingMatrix, null, 2),
            },
          ],
        };
      case "knowledge-base://trigger-conditions":
        return {
          contents: [
            {
              uri,
              mimeType: "application/json",
              text: JSON.stringify(triggerConditions, null, 2),
            },
          ],
        };
      case "knowledge-base://alternative-stacks":
        return {
          contents: [
            {
              uri,
              mimeType: "application/json",
              text: JSON.stringify(pricingMatrix?.alternative_technology_stack || {}, null, 2),
            },
          ],
        };
      default:
        throw new McpError(ErrorCode.InvalidRequest, `Unknown resource: ${uri}`);
    }
  } catch (error) {
    logger.error(`Error reading resource ${uri}: ${error}`);
    throw new McpError(ErrorCode.InternalError, `Failed to read resource: ${error}`);
  }
});

/**
 * Main entry point
 */
async function main() {
  // Initialize data caches
  await initializeCaches();

  // Create stdio transport
  const transport = new StdioServerTransport();

  // Connect server to transport
  await server.connect(transport);

  logger.info("Google Business APIs MCP Server running on stdio");
}

// Run the server
main().catch((error) => {
  logger.error(`Fatal error: ${error}`);
  process.exit(1);
});
