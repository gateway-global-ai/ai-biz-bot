/**
 * Google Business APIs MCP Server - Node.js SDK Example
 * 
 * This example demonstrates how to interact with the MCP server
 * using the Model Context Protocol SDK in Node.js.
 * 
 * Prerequisites:
 * npm install @modelcontextprotocol/sdk
 */

import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { spawn } from "child_process";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Client for interacting with the Google Business APIs MCP Server
 */
class GoogleAPIsMCPClient {
  constructor() {
    this.client = null;
    this.transport = null;
  }

  /**
   * Connect to the MCP server
   */
  async connect(serverScriptPath) {
    this.transport = new StdioClientTransport({
      command: "node",
      args: [serverScriptPath],
    });

    this.client = new Client(
      {
        name: "google-apis-client",
        version: "1.0.0",
      },
      {
        capabilities: {
          tools: {},
          resources: {},
        },
      }
    );

    await this.client.connect(this.transport);
    console.log("✅ Connected to Google Business APIs MCP Server");
  }

  /**
   * Disconnect from the MCP server
   */
  async disconnect() {
    if (this.transport) {
      await this.transport.close();
    }
    console.log("🔌 Disconnected from MCP Server");
  }

  /**
   * List available tools
   */
  async listTools() {
    return await this.client.listTools();
  }

  /**
   * Get information about a specific API
   */
  async getApiInfo(apiName, category = null) {
    const result = await this.client.callTool("get_api_info", {
      api_name: apiName,
      category: category,
    });
    return JSON.parse(result.content[0].text);
  }

  /**
   * Compare pricing between Google and alternatives
   */
  async comparePricing(service, monthlyUsage, usageUnit = null) {
    const args = { service, monthly_usage: monthlyUsage };
    if (usageUnit) args.usage_unit = usageUnit;

    const result = await this.client.callTool("compare_pricing", args);
    return JSON.parse(result.content[0].text);
  }

  /**
   * Get API recommendations based on business needs
   */
  async getRecommendation(useCase, options = {}) {
    const args = { use_case: useCase, ...options };
    const result = await this.client.callTool("get_recommendation", args);
    return JSON.parse(result.content[0].text);
  }

  /**
   * Check which trigger conditions apply
   */
  async checkTriggers(businessProfile = null, usage = null, needs = null) {
    const args = {};
    if (businessProfile) args.business_profile = businessProfile;
    if (usage) args.usage = usage;
    if (needs) args.needs = needs;

    const result = await this.client.callTool("check_triggers", args);
    return JSON.parse(result.content[0].text);
  }

  /**
   * Get recommended alternative technology stack
   */
  async getAlternativeStack(service, includeCostEstimate = true) {
    const result = await this.client.callTool("get_alternative_stack", {
      service,
      include_cost_estimate: includeCostEstimate,
    });
    return JSON.parse(result.content[0].text);
  }

  /**
   * Calculate potential savings
   */
  async calculateSavings(currentServices, timePeriod = "annual") {
    const result = await this.client.callTool("calculate_savings", {
      current_services: currentServices,
      time_period: timePeriod,
    });
    return JSON.parse(result.content[0].text);
  }

  /**
   * Get conversation script for a trigger
   */
  async getConversationScript(triggerId, businessContext = null) {
    const args = { trigger_id: triggerId };
    if (businessContext) args.business_context = businessContext;

    const result = await this.client.callTool("get_conversation_script", args);
    return JSON.parse(result.content[0].text);
  }

  /**
   * Read a resource from the server
   */
  async readResource(uri) {
    const result = await this.client.readResource(uri);
    return result.contents[0].text;
  }
}

/**
 * Demo function showcasing all capabilities
 */
async function demo() {
  // Path to the compiled MCP server
  const serverPath = path.join(__dirname, "../mcp-server/dist/index.js");

  const client = new GoogleAPIsMCPClient();

  try {
    // Connect to the server
    await client.connect(serverPath);

    console.log("\n" + "=".repeat(60));
    console.log("📋 LISTING AVAILABLE TOOLS");
    console.log("=".repeat(60));
    const tools = await client.listTools();
    for (const tool of tools.tools) {
      console.log(`\n🔧 ${tool.name}`);
      console.log(`   ${tool.description}`);
    }

    console.log("\n" + "=".repeat(60));
    console.log("🔍 GETTING API INFO - Speech-to-Text API");
    console.log("=".repeat(60));
    const apiInfo = await client.getApiInfo("Speech-to-Text API", "ai_ml");
    console.log(JSON.stringify(apiInfo, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("💰 COMPARING PRICING - Maps (50K loads/month)");
    console.log("=".repeat(60));
    const mapsPricing = await client.comparePricing("maps", 50000, "map loads");
    console.log(JSON.stringify(mapsPricing, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("💰 COMPARING PRICING - NLP (100K records/month)");
    console.log("=".repeat(60));
    const nlpPricing = await client.comparePricing("nlp", 100000, "records");
    console.log(JSON.stringify(nlpPricing, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("🎯 GETTING RECOMMENDATION - Document Processing");
    console.log("=".repeat(60));
    const recommendation = await client.getRecommendation("document_processing", {
      business_type: "accounting",
      estimated_volume: "high",
    });
    console.log(JSON.stringify(recommendation, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("⚡ CHECKING TRIGGERS - High-Volume Usage");
    console.log("=".repeat(60));
    const triggers = await client.checkTriggers(
      null,
      {
        estimated_monthly_map_loads: 100000,
        estimated_monthly_call_hours: 1000,
        estimated_monthly_documents: 5000,
      },
      ["route_optimization", "call_transcription"]
    );
    console.log(JSON.stringify(triggers, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("🛠️ GETTING ALTERNATIVE STACK - Maps");
    console.log("=".repeat(60));
    const mapsStack = await client.getAlternativeStack("maps");
    console.log(JSON.stringify(mapsStack, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("🛠️ GETTING ALTERNATIVE STACK - NLP");
    console.log("=".repeat(60));
    const nlpStack = await client.getAlternativeStack("nlp");
    console.log(JSON.stringify(nlpStack, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("💵 CALCULATING SAVINGS - Enterprise Scenario");
    console.log("=".repeat(60));
    const savings = await client.calculateSavings(
      [
        { service: "maps", monthly_usage: 100000, usage_unit: "map loads" },
        { service: "geocoding", monthly_usage: 500000, usage_unit: "requests" },
        { service: "speech_to_text", monthly_usage: 5000, usage_unit: "hours" },
        { service: "nlp", monthly_usage: 200000, usage_unit: "records" },
      ],
      "annual"
    );
    console.log(JSON.stringify(savings, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("📝 GETTING CONVERSATION SCRIPT - Multi-Location Business");
    console.log("=".repeat(60));
    const script = await client.getConversationScript("TRIGGER-001", {
      location_count: 10,
    });
    console.log(JSON.stringify(script, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("📝 GETTING CONVERSATION SCRIPT - Call Center");
    console.log("=".repeat(60));
    const callScript = await client.getConversationScript("TRIGGER-003", {
      vehicle_count: 25,
    });
    console.log(JSON.stringify(callScript, null, 2));

    console.log("\n" + "=".repeat(60));
    console.log("📚 READING RESOURCE - Alternative Stacks");
    console.log("=".repeat(60));
    const resource = await client.readResource("knowledge-base://alternative-stacks");
    console.log(resource.substring(0, 1500) + "...");

  } catch (error) {
    console.error("Error:", error);
  } finally {
    await client.disconnect();
  }
}

// Run the demo
console.log("🚀 Starting Google Business APIs MCP Client Demo\n");
demo().catch(console.error);
