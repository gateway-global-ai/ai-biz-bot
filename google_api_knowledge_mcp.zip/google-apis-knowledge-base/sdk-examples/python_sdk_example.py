"""
Google Business APIs MCP Server - Python SDK Example

This example demonstrates how to interact with the MCP server
using the Model Context Protocol SDK in Python.
"""

import asyncio
import json
from typing import Any, Dict, List, Optional
from contextlib import AsyncExitStack

# You'll need to install the MCP Python SDK:
# pip install mcp

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
except ImportError:
    print("Please install the MCP Python SDK: pip install mcp")
    raise


class GoogleAPIsMCPClient:
    """Client for interacting with the Google Business APIs MCP Server."""
    
    def __init__(self):
        self.session: Optional[ClientSession] = None
        self.exit_stack = AsyncExitStack()
    
    async def connect(self, server_script_path: str):
        """Connect to the MCP server."""
        server_params = StdioServerParameters(
            command="node",
            args=[server_script_path],
            env=None
        )
        
        stdio_transport = await self.exit_stack.enter_async_context(
            stdio_client(server_params)
        )
        self.stdio, self.write = stdio_transport
        self.session = await self.exit_stack.enter_async_context(
            ClientSession(self.stdio, self.write)
        )
        
        await self.session.initialize()
        print("✅ Connected to Google Business APIs MCP Server")
    
    async def disconnect(self):
        """Disconnect from the MCP server."""
        await self.exit_stack.aclose()
        print("🔌 Disconnected from MCP Server")
    
    async def list_tools(self) -> List[Dict[str, Any]]:
        """List available tools."""
        tools = await self.session.list_tools()
        return tools.tools
    
    async def get_api_info(self, api_name: str, category: Optional[str] = None) -> Dict[str, Any]:
        """Get information about a specific API."""
        result = await self.session.call_tool(
            "get_api_info",
            arguments={"api_name": api_name, "category": category}
        )
        return json.loads(result.content[0].text)
    
    async def compare_pricing(self, service: str, monthly_usage: int, usage_unit: Optional[str] = None) -> Dict[str, Any]:
        """Compare pricing between Google and alternatives."""
        args = {"service": service, "monthly_usage": monthly_usage}
        if usage_unit:
            args["usage_unit"] = usage_unit
        
        result = await self.session.call_tool("compare_pricing", arguments=args)
        return json.loads(result.content[0].text)
    
    async def get_recommendation(
        self,
        use_case: str,
        business_type: Optional[str] = None,
        estimated_volume: Optional[str] = None,
        location_count: Optional[int] = None
    ) -> Dict[str, Any]:
        """Get API recommendations based on business needs."""
        args = {"use_case": use_case}
        if business_type:
            args["business_type"] = business_type
        if estimated_volume:
            args["estimated_volume"] = estimated_volume
        if location_count:
            args["location_count"] = location_count
        
        result = await self.session.call_tool("get_recommendation", arguments=args)
        return json.loads(result.content[0].text)
    
    async def check_triggers(
        self,
        business_profile: Optional[Dict] = None,
        usage: Optional[Dict] = None,
        needs: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Check which trigger conditions apply."""
        args = {}
        if business_profile:
            args["business_profile"] = business_profile
        if usage:
            args["usage"] = usage
        if needs:
            args["needs"] = needs
        
        result = await self.session.call_tool("check_triggers", arguments=args)
        return json.loads(result.content[0].text)
    
    async def get_alternative_stack(self, service: str, include_cost_estimate: bool = True) -> Dict[str, Any]:
        """Get recommended alternative technology stack."""
        result = await self.session.call_tool(
            "get_alternative_stack",
            arguments={"service": service, "include_cost_estimate": include_cost_estimate}
        )
        return json.loads(result.content[0].text)
    
    async def calculate_savings(
        self,
        current_services: List[Dict[str, Any]],
        time_period: str = "annual"
    ) -> Dict[str, Any]:
        """Calculate potential savings."""
        result = await self.session.call_tool(
            "calculate_savings",
            arguments={"current_services": current_services, "time_period": time_period}
        )
        return json.loads(result.content[0].text)
    
    async def get_conversation_script(
        self,
        trigger_id: str,
        business_context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Get conversation script for a trigger."""
        args = {"trigger_id": trigger_id}
        if business_context:
            args["business_context"] = business_context
        
        result = await self.session.call_tool("get_conversation_script", arguments=args)
        return json.loads(result.content[0].text)
    
    async def read_resource(self, uri: str) -> str:
        """Read a resource from the server."""
        resource = await self.session.read_resource(uri)
        return resource.contents[0].text


async def demo():
    """Demonstrate the MCP client capabilities."""
    
    # Path to the compiled MCP server
    server_path = "../mcp-server/dist/index.js"
    
    client = GoogleAPIsMCPClient()
    
    try:
        # Connect to the server
        await client.connect(server_path)
        
        print("\n" + "="*60)
        print("📋 LISTING AVAILABLE TOOLS")
        print("="*60)
        tools = await client.list_tools()
        for tool in tools:
            print(f"\n🔧 {tool.name}")
            print(f"   {tool.description}")
        
        print("\n" + "="*60)
        print("🔍 GETTING API INFO - Google Maps JavaScript API")
        print("="*60)
        api_info = await client.get_api_info("Maps JavaScript API", "maps_platform")
        print(json.dumps(api_info, indent=2))
        
        print("\n" + "="*60)
        print("💰 COMPARING PRICING - Maps (100K loads/month)")
        print("="*60)
        pricing = await client.compare_pricing("maps", 100000, "map loads")
        print(json.dumps(pricing, indent=2))
        
        print("\n" + "="*60)
        print("💰 COMPARING PRICING - Speech-to-Text (1,000 hours/month)")
        print("="*60)
        pricing = await client.compare_pricing("speech_to_text", 1000, "hours")
        print(json.dumps(pricing, indent=2))
        
        print("\n" + "="*60)
        print("🎯 GETTING RECOMMENDATION - Call Center Transcription")
        print("="*60)
        recommendation = await client.get_recommendation(
            use_case="transcription",
            business_type="healthcare",
            estimated_volume="high"
        )
        print(json.dumps(recommendation, indent=2))
        
        print("\n" + "="*60)
        print("⚡ CHECKING TRIGGERS - Multi-location Business")
        print("="*60)
        triggers = await client.check_triggers(
            business_profile={
                "location_count": 5,
                "industry": "retail",
                "has_google_business_profile": True
            },
            usage={
                "estimated_monthly_map_loads": 50000,
                "estimated_monthly_call_hours": 500
            }
        )
        print(json.dumps(triggers, indent=2))
        
        print("\n" + "="*60)
        print("🛠️ GETTING ALTERNATIVE STACK - Speech-to-Text")
        print("="*60)
        stack = await client.get_alternative_stack("speech_to_text")
        print(json.dumps(stack, indent=2))
        
        print("\n" + "="*60)
        print("💵 CALCULATING SAVINGS - Multiple Services")
        print("="*60)
        savings = await client.calculate_savings(
            current_services=[
                {"service": "maps", "monthly_usage": 50000, "usage_unit": "map loads"},
                {"service": "speech_to_text", "monthly_usage": 500, "usage_unit": "hours"},
                {"service": "nlp", "monthly_usage": 50000, "usage_unit": "records"},
            ],
            time_period="annual"
        )
        print(json.dumps(savings, indent=2))
        
        print("\n" + "="*60)
        print("📝 GETTING CONVERSATION SCRIPT - High-Volume Maps")
        print("="*60)
        script = await client.get_conversation_script(
            trigger_id="TRIGGER-002",
            business_context={"vehicle_count": 10}
        )
        print(json.dumps(script, indent=2))
        
        print("\n" + "="*60)
        print("📚 READING RESOURCE - Pricing Matrix")
        print("="*60)
        # Read first 1000 characters
        resource = await client.read_resource("knowledge-base://pricing-matrix")
        print(resource[:1000] + "...")
        
    finally:
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(demo())
