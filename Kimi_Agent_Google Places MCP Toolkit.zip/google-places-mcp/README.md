# Google Places MCP Server

A comprehensive [Model Context Protocol (MCP)](https://modelcontextprotocol.io) server that provides AI agents with powerful access to Google Places APIs. This server enables sophisticated location-based intelligence, business discovery, and competitive analysis capabilities.

## Features

### 🗺️ **Complete API Coverage**
- **Place Details** - Comprehensive business information with AI-powered summaries
- **Text Search** - Natural language place discovery
- **Nearby Search** - Geographic location-based search
- **Autocomplete** - Type-ahead predictions with session optimization
- **Place Photos** - High-quality business imagery
- **Business Intelligence** - Automated analysis and insights

### 🤖 **AI-Powered Insights**
- Gemini-generated business summaries
- Review sentiment analysis
- Industry pain point identification
- Competitive analysis
- Personalized recommendations

### 💰 **Cost Optimization**
- Smart field masking for API cost control
- Session token management
- Request batching and caching
- Usage monitoring and optimization

### 🔧 **Developer Experience**
- TypeScript SDK with full type safety
- Comprehensive examples
- MCP-compliant tool interface
- Extensive documentation

## Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/aibizbot/google-places-mcp.git
cd google-places-mcp

# Install dependencies
npm install

# Build the project
npm run build
```

### Configuration

Set your Google Places API key:

```bash
export GOOGLE_PLACES_API_KEY="your_api_key_here"
```

### Running the Server

```bash
# Start the MCP server
npm start

# Or run in development mode
npm run dev
```

### Using with Claude Desktop

Add to your Claude Desktop configuration (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "google-places": {
      "command": "node",
      "args": ["/path/to/google-places-mcp/dist/index.js"],
      "env": {
        "GOOGLE_PLACES_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

## Available Tools

### `google_places_get_details`
Retrieve comprehensive information about a specific place.

```json
{
  "placeId": "ChIJj61dQgK6j4AR4GeTYWZsKWw",
  "fieldPreset": "complete",
  "includeBusinessProfile": true
}
```

### `google_places_text_search`
Search for places using natural language queries.

```json
{
  "textQuery": "pizza restaurants in Manhattan",
  "locationBias": {
    "circle": {
      "center": { "latitude": 40.7589, "longitude": -73.9851 },
      "radius": 5000
    }
  },
  "maxResultCount": 10,
  "fieldPreset": "basic"
}
```

### `google_places_nearby_search`
Find places near a specific geographic location.

```json
{
  "locationRestriction": {
    "circle": {
      "center": { "latitude": 37.7749, "longitude": -122.4194 },
      "radius": 1000
    }
  },
  "includedTypes": ["cafe"],
  "maxResultCount": 20
}
```

### `google_places_autocomplete`
Get place predictions as users type.

```json
{
  "input": "Starbucks",
  "sessionToken": "session_1234567890",
  "locationBias": {
    "circle": {
      "center": { "latitude": 40.7128, "longitude": -74.0060 },
      "radius": 10000
    }
  }
}
```

### `google_places_get_photo`
Retrieve photos for a place.

```json
{
  "photoName": "places/ChIJ.../photos/AXCi...",
  "maxWidthPx": 800
}
```

### `google_places_business_intelligence`
Perform comprehensive business analysis.

```json
{
  "placeId": "ChIJj61dQgK6j4AR4GeTYWZsKWw",
  "includeCompetitors": true,
  "competitorSearchRadius": 1000,
  "maxCompetitors": 5
}
```

## TypeScript SDK

### Installation

```bash
npm install @aibizbot/google-places-sdk
```

### Usage

```typescript
import { GooglePlacesSDK } from '@aibizbot/google-places-sdk';

const sdk = new GooglePlacesSDK({
  serverPath: './node_modules/.bin/google-places-mcp'
});

await sdk.connect();

// Search for places
const results = await sdk.textSearch({
  textQuery: 'coffee shops in San Francisco',
  maxResultCount: 10
});

// Get business intelligence
const analysis = await sdk.businessIntelligence({
  placeId: 'ChIJ...',
  includeCompetitors: true
});

await sdk.disconnect();
```

## Field Presets

Field presets optimize API costs by requesting only necessary data:

| Preset | Fields | Use Case |
|--------|--------|----------|
| `minimal` | id, displayName | List views |
| `basic` | + address, location | Basic info cards |
| `contact` | + phone, website | Contact listings |
| `ratings` | + rating, reviews | Review displays |
| `hours` | + opening hours | Hours display |
| `photos` | + photos | Photo galleries |
| `ai_summary` | + Gemini summaries | AI insights |
| `complete` | All fields | Full profiles |

## Examples

### Business Onboarding

```typescript
import { onboardBusiness } from './examples/business-onboarding';

const result = await onboardBusiness('Joe\'s Pizza', {
  latitude: 40.7589,
  longitude: -73.9851
});

console.log(result.businessProfile);
console.log(result.recommendations);
```

### Competitive Analysis

```typescript
import { analyzeCompetitors } from './examples/competitive-analysis';

const competitors = await analyzeCompetitors('cafe', {
  latitude: 37.7749,
  longitude: -122.4194
}, 1000);
```

## Cost Optimization

### Field Masking

Always use field masks to control costs:

```typescript
// ❌ Expensive - requests all fields
const details = await sdk.getPlaceDetails({ placeId: '...' });

// ✅ Optimized - requests only needed fields
const details = await sdk.getPlaceDetails({
  placeId: '...',
  fieldPreset: 'basic'
});
```

### Session Tokens

Use session tokens for autocomplete to reduce billing:

```typescript
import { generateSessionToken } from '@aibizbot/google-places-sdk';

const token = generateSessionToken();

// Use same token for all autocomplete calls
await sdk.autocomplete({ input: 'Star', sessionToken: token });
await sdk.autocomplete({ input: 'Starb', sessionToken: token });
await sdk.autocomplete({ input: 'Starbu', sessionToken: token });
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `GOOGLE_PLACES_API_KEY` | Your Google Places API key | Required |
| `GOOGLE_PLACES_TIMEOUT` | Request timeout (ms) | 30000 |
| `GOOGLE_PLACES_RETRIES` | Number of retries | 3 |

## Documentation

- [AI Biz Bot Knowledge Resource](./docs/AI-BIZ-BOT-KNOWLEDGE.md) - Comprehensive guide for AI agents
- [SDK Documentation](./docs/SDK.md) - TypeScript SDK reference
- [API Reference](./docs/API.md) - Complete API documentation
- [Examples](./examples/) - Working code examples

## Architecture

```
┌─────────────────┐
│   AI Agent      │
│  (Claude, etc)  │
└────────┬────────┘
         │ MCP Protocol
         ▼
┌─────────────────┐
│  MCP Server     │
│ Google Places   │
└────────┬────────┘
         │ HTTP/JSON
         ▼
┌─────────────────┐
│ Google Places   │
│   API (New)     │
└─────────────────┘
```

## Pricing

Google Places API uses pay-as-you-go pricing. Key factors:

- **Field selection** - Different fields have different costs
- **Request volume** - Monthly quotas and pricing tiers
- **Session tokens** - Reduce autocomplete costs significantly

See [Google's pricing documentation](https://developers.google.com/maps/documentation/places/web-service/usage-and-billing) for details.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see [LICENSE](./LICENSE) for details.

## Support

- 📧 Email: support@aibizbot.com
- 💬 Discord: [Join our community](https://discord.gg/aibizbot)
- 🐛 Issues: [GitHub Issues](https://github.com/aibizbot/google-places-mcp/issues)

---

**Built with ❤️ by AI Biz Bot**

*Empowering AI agents with location intelligence*
