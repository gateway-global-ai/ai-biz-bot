# AI Biz Bot Knowledge Resource: Google Places Mastery

## Overview

This document serves as the comprehensive knowledge base for AI Biz Bot to become a master at Google Places APIs and their application for small business customers and owners.

---

## Table of Contents

1. [Google Places APIs Fundamentals](#1-google-places-apis-fundamentals)
2. [API Endpoints & Capabilities](#2-api-endpoints--capabilities)
3. [Business Owner Strategies](#3-business-owner-strategies)
4. [Consumer Application Strategies](#4-consumer-application-strategies)
5. [Cost Optimization](#5-cost-optimization)
6. [Integration Patterns](#6-integration-patterns)
7. [Use Cases by Industry](#7-use-cases-by-industry)
8. [Troubleshooting & Best Practices](#8-troubleshooting--best-practices)

---

## 1. Google Places APIs Fundamentals

### What is Google Places API (New)?

The Google Places API (New) is a comprehensive service that provides access to Google's database of over **250 million places** worldwide. It's built on modern infrastructure and offers AI-powered insights through Google's Gemini model.

### Key Improvements Over Legacy API

| Feature | Legacy API | Places API (New) |
|---------|------------|------------------|
| AI Summaries | ❌ Not available | ✅ Gemini-powered |
| Place Types | ~100 types | 200+ types |
| Field Masking | Limited | Comprehensive |
| Authentication | API Key only | API Key + OAuth |
| Response Format | Mixed | Consistent JSON |
| Performance | Standard | Optimized RPC |

### Core Concepts

#### Place ID
- Unique identifier for every place in Google's database
- Format: `ChIJj61dQgK6j4AR4GeTYWZsKWw`
- Persistent across API calls
- Used to retrieve detailed information

#### Field Masks
- Control which data fields are returned
- Critical for cost optimization
- Different fields trigger different pricing SKUs

#### Session Tokens
- Group related autocomplete requests
- Significantly reduce billing costs
- Generate once per user session

---

## 2. API Endpoints & Capabilities

### 2.1 Place Details (New)

**Purpose**: Retrieve comprehensive information about a specific place

**Endpoint**: `GET /v1/places/{PLACE_ID}`

**Key Data Returned**:
- Basic info (name, address, phone, website)
- Business hours (regular & current)
- Ratings and reviews
- Photos
- AI-powered summaries (Gemini)
- Accessibility options
- Payment options
- Amenities and services

**Best For**:
- Building detailed business profiles
- Displaying comprehensive business information
- AI-powered business analysis

**Example Use Case**:
```
Customer: "Tell me about this restaurant"
AI Bot: [Retrieves Place Details] 
"Based on 1,247 reviews with a 4.6-star rating, this Italian restaurant 
is known for its handmade pasta and extensive wine list. The AI summary 
notes: 'A cozy neighborhood spot with authentic Northern Italian cuisine...'"
```

### 2.2 Text Search (New)

**Purpose**: Search for places using natural language queries

**Endpoint**: `POST /v1/places:searchText`

**Key Features**:
- Natural language queries ("pizza near Central Park")
- Location bias/restriction
- Filter by rating, price, open status
- Pagination support

**Best For**:
- General place discovery
- Location-aware search
- Building search interfaces

**Example Use Case**:
```
Customer: "Find highly-rated coffee shops open now near me"
AI Bot: [Text Search with filters]
"I found 5 coffee shops within 1 mile that are open now with 4.5+ ratings..."
```

### 2.3 Nearby Search (New)

**Purpose**: Find places near a specific geographic location

**Endpoint**: `POST /v1/places:searchNearby`

**Key Features**:
- Circle or rectangular search areas
- Filter by place types
- Rank by popularity or distance
- Competitive analysis

**Best For**:
- "Near me" functionality
- Competitive analysis
- Local business discovery

**Example Use Case**:
```
Customer: "What restaurants are near this hotel?"
AI Bot: [Nearby Search from hotel location]
"Within 500 meters of your hotel, there are 12 restaurants including..."
```

### 2.4 Autocomplete (New)

**Purpose**: Provide type-ahead place predictions

**Endpoint**: `POST /v1/places:autocomplete`

**Key Features**:
- Place predictions
- Query predictions
- Session token support
- Location bias

**Best For**:
- Search box suggestions
- Address autocomplete
- Business name lookup

**Example Use Case**:
```
Customer types: "Starb"
AI Bot: [Autocomplete suggestions]
- Starbucks - 123 Main St
- Starbucks Reserve - 456 Oak Ave
- Starbelly Restaurant - 789 Pine St
```

### 2.5 Place Photos (New)

**Purpose**: Retrieve photos of places

**Endpoint**: `GET /v1/{PHOTO_NAME}/media`

**Key Features**:
- Size control (max width/height)
- High-quality images
- Attribution information

**Best For**:
- Business photo galleries
- Visual listings
- Marketing materials

---

## 3. Business Owner Strategies

### 3.1 Maximizing Google Business Profile

The Google Places API data comes from Google Business Profile. Owners should:

#### Keep Information Current
- ✅ Update hours for holidays and special events
- ✅ Ensure phone number and website are correct
- ✅ Maintain accurate address and service area
- ✅ Respond to reviews promptly

#### Rich Content
- ✅ Upload high-quality photos (exterior, interior, products, team)
- ✅ Add business description with keywords
- ✅ List all services and amenities
- ✅ Specify accessibility features

#### Engagement
- ✅ Post regular updates (offers, events, news)
- ✅ Respond to all reviews (positive and negative)
- ✅ Answer Q&A from customers
- ✅ Use Google Posts for promotions

### 3.2 Leveraging AI Summaries

Google's Gemini AI generates summaries from:
- Customer reviews
- Editorial content
- Business information

**How to Improve Your AI Summary**:
1. Encourage detailed customer reviews
2. Maintain complete business information
3. Use relevant keywords in description
4. Keep categories and attributes accurate

### 3.3 Pain Points by Industry

Understanding common pain points helps owners prioritize improvements:

| Industry | Top Pain Points |
|----------|-----------------|
| Restaurants | Peak hour rush, staff turnover, online orders |
| Retail | Inventory management, online competition |
| Healthcare | Appointment scheduling, patient wait times |
| Professional Services | Client scheduling, billable tracking |
| Hospitality | Booking management, guest requests |
| Automotive | Service scheduling, parts inventory |
| Beauty & Wellness | Appointment no-shows, client retention |

---

## 4. Consumer Application Strategies

### 4.1 Building Great Search Experiences

#### Efficient Search Flow
1. **Autocomplete First**: Reduce typing with predictions
2. **Location Awareness**: Use GPS for "near me" results
3. **Smart Filtering**: Allow rating, price, hours filters
4. **Visual Results**: Show photos and ratings prominently

#### Contextual Information
- Show current open/closed status
- Display peak hours when available
- Highlight accessibility features
- Show price range indicators

### 4.2 Displaying Business Information

#### Essential Information (Always Show)
- Business name
- Address with map
- Phone number (click-to-call)
- Current hours and open status
- Rating and review count

#### Enhanced Information (When Available)
- AI-generated summary
- Photos gallery
- Full review excerpts
- Amenities and services
- Accessibility options
- Payment methods accepted

### 4.3 Cost-Aware Design

#### Optimize API Calls
- Use field masks to request only needed data
- Cache place details for repeated views
- Use session tokens for autocomplete
- Batch requests when possible

#### Smart Data Loading
- Load basic info first, details on demand
- Lazy-load photos and reviews
- Cache results locally
- Implement intelligent prefetching

---

## 5. Cost Optimization

### 5.1 Understanding Pricing SKUs

| SKU | Fields | Typical Cost |
|-----|--------|--------------|
| Essentials ID Only | id, name, photos | $ |
| Essentials | address, location, types | $$ |
| Pro | displayName, businessStatus | $$$ |
| Enterprise | hours, phone, rating | $$$$ |
| Enterprise + Atmosphere | reviews, amenities | $$$$$ |

### 5.2 Field Mask Best Practices

#### Use Preset Masks
```
minimal:      id, displayName
basic:        + formattedAddress, location, types
contact:      + phone, website
ratings:      + rating, reviewCount, priceLevel
hours:        + opening hours
photos:       + photos
reviews:      + reviews, reviewSummary
ai_summary:   + generativeSummary, reviewSummary
complete:     All fields
```

#### Request Only What You Need
```
❌ Bad:  Requesting all fields for a list view
✅ Good: Request id, name, rating for list; 
        fetch details only when selected
```

### 5.3 Session Token Strategy

```
1. User starts typing → Generate session token
2. Each keystroke → Use same token
3. User selects place → Include token in Place Details
4. Result: Single billable session instead of multiple
```

---

## 6. Integration Patterns

### 6.1 Business Onboarding Flow

```
1. Search for business by name
   ↓
2. User selects correct business
   ↓
3. Retrieve complete place details
   ↓
4. Transform to business profile
   ↓
5. Analyze industry and pain points
   ↓
6. Generate personalized recommendations
   ↓
7. Create voice AI workflows
```

### 6.2 Competitive Analysis Flow

```
1. Get target business details
   ↓
2. Extract location and business type
   ↓
3. Search for nearby competitors
   ↓
4. Analyze each competitor
   ↓
5. Calculate market insights
   ↓
6. Generate competitive recommendations
```

### 6.3 Customer Discovery Flow

```
1. Capture customer location
   ↓
2. Accept search query or filters
   ↓
3. Execute text or nearby search
   ↓
4. Display results with key info
   ↓
5. Fetch details on selection
   ↓
6. Show comprehensive profile
```

---

## 7. Use Cases by Industry

### 7.1 Restaurants & Food Service

**Key APIs**: Place Details, Text Search, Photos

**Use Cases**:
- Menu discovery with photos
- Review analysis for quality
- Peak hour identification
- Dietary option filtering

**Example**:
```
"Find Italian restaurants with outdoor seating 
that are open now and rated 4.5+"
```

### 7.2 Retail & E-commerce

**Key APIs**: Place Details, Nearby Search, Photos

**Use Cases**:
- Store locator with hours
- Product availability by location
- In-store pickup coordination
- Return location finder

### 7.3 Healthcare

**Key APIs**: Place Details, Text Search

**Use Cases**:
- Provider search by specialty
- Appointment scheduling
- Insurance acceptance info
- Accessibility verification

### 7.4 Real Estate

**Key APIs**: Nearby Search, Place Details

**Use Cases**:
- Neighborhood amenity mapping
- School district identification
- Walkability scoring
- Property comparison

### 7.5 Travel & Hospitality

**Key APIs**: All endpoints

**Use Cases**:
- Attraction discovery
- Hotel amenity comparison
- Route planning
- Local guide generation

### 7.6 Logistics & Delivery

**Key APIs**: Place Details, Autocomplete

**Use Cases**:
- Address validation
- Delivery location details
- Route optimization
- Pickup/dropoff instructions

---

## 8. Troubleshooting & Best Practices

### 8.1 Common Issues

#### "Place Not Found"
- Try variations of business name
- Use location bias
- Check for typos
- Verify place hasn't closed

#### "Incomplete Data"
- Business may not have claimed profile
- Some fields are optional
- Check businessStatus field
- Consider data freshness

#### "Rate Limiting"
- Implement exponential backoff
- Cache responses
- Use field masks
- Monitor quota usage

### 8.2 Best Practices

#### Data Quality
- Always validate place IDs
- Handle missing fields gracefully
- Show data freshness indicators
- Implement fallback content

#### User Experience
- Show loading states
- Handle errors gracefully
- Provide retry options
- Cache for offline viewing

#### Performance
- Use appropriate field masks
- Implement request batching
- Cache aggressively
- Monitor API latency

### 8.3 Security Considerations

- Never expose API keys in client code
- Use server-side proxy for API calls
- Implement rate limiting
- Validate all user inputs
- Log API usage for auditing

---

## Quick Reference Cards

### Field Mask Selection Guide

| Use Case | Recommended Mask |
|----------|-----------------|
| List view | `basic` |
| Map pins | `minimal` |
| Contact card | `contact` |
| Review display | `ratings` + `reviews` |
| Full profile | `complete` |
| AI analysis | `business_intelligence` |

### API Selection Guide

| Goal | Use API |
|------|---------|
| Find by name | Text Search |
| Find near location | Nearby Search |
| Get details | Place Details |
| Type-ahead | Autocomplete |
| Get photos | Place Photos |
| Full analysis | Business Intelligence |

### Cost Optimization Checklist

- [ ] Using field masks?
- [ ] Session tokens for autocomplete?
- [ ] Caching responses?
- [ ] Lazy-loading details?
- [ ] Monitoring usage?
- [ ] Optimizing for use case?

---

## Resources

- [Google Places API Documentation](https://developers.google.com/maps/documentation/places/web-service/overview)
- [Place Types Reference](https://developers.google.com/maps/documentation/places/web-service/place-types)
- [Pricing Calculator](https://developers.google.com/maps/documentation/places/web-service/usage-and-billing)
- [MCP Server Repository](./README.md)
- [SDK Documentation](./SDK.md)

---

**Last Updated**: 2024-12-19  
**Version**: 1.0.0  
**Maintainer**: AI Biz Bot Team
