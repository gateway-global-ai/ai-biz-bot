# Google Places SDK Documentation

## Overview

The TypeScript SDK provides a high-level, type-safe interface for interacting with the Google Places MCP Server. It handles connection management, request formatting, and response parsing.

## Installation

```bash
npm install @aibizbot/google-places-sdk
```

## Quick Start

```typescript
import { GooglePlacesSDK } from '@aibizbot/google-places-sdk';

// Initialize SDK
const sdk = new GooglePlacesSDK({
  serverPath: './node_modules/.bin/google-places-mcp'
});

// Connect to server
await sdk.connect();

// Use the SDK
const results = await sdk.textSearch({
  textQuery: 'pizza restaurants in New York'
});

// Disconnect when done
await sdk.disconnect();
```

## Configuration

### SDKConfig Interface

```typescript
interface SDKConfig {
  /** Path to the MCP server executable */
  serverPath?: string;
  
  /** Google Places API key (for direct API access) */
  apiKey?: string;
  
  /** Request timeout in milliseconds */
  timeout?: number;
}
```

### Example Configurations

#### Basic Usage
```typescript
const sdk = new GooglePlacesSDK({
  serverPath: './dist/index.js'
});
```

#### With Timeout
```typescript
const sdk = new GooglePlacesSDK({
  serverPath: './dist/index.js',
  timeout: 60000 // 60 seconds
});
```

## Core Methods

### Place Details

```typescript
async getPlaceDetails(params: {
  placeId: string;
  fields?: string[];
  fieldPreset?: FieldPreset;
  languageCode?: string;
  regionCode?: string;
  includeBusinessProfile?: boolean;
}): Promise<Place | BusinessProfile>
```

**Example:**
```typescript
const details = await sdk.getPlaceDetails({
  placeId: 'ChIJj61dQgK6j4AR4GeTYWZsKWw',
  fieldPreset: 'complete',
  includeBusinessProfile: true
});
```

### Text Search

```typescript
async textSearch(params: {
  textQuery: string;
  fields?: string[];
  fieldPreset?: FieldPreset;
  languageCode?: string;
  regionCode?: string;
  locationBias?: LocationBias;
  locationRestriction?: LocationRestriction;
  includedType?: string;
  openNow?: boolean;
  minRating?: number;
  maxResultCount?: number;
  priceLevels?: string[];
  includeBusinessProfiles?: boolean;
}): Promise<TextSearchResponse>
```

**Example:**
```typescript
const results = await sdk.textSearch({
  textQuery: 'coffee shops near Central Park',
  locationBias: {
    circle: {
      center: { latitude: 40.785091, longitude: -73.968285 },
      radius: 1000
    }
  },
  openNow: true,
  minRating: 4.0,
  maxResultCount: 10
});
```

### Nearby Search

```typescript
async nearbySearch(params: {
  locationRestriction: LocationRestriction;
  fields?: string[];
  fieldPreset?: FieldPreset;
  languageCode?: string;
  regionCode?: string;
  includedTypes?: string[];
  excludedTypes?: string[];
  includedPrimaryTypes?: string[];
  excludedPrimaryTypes?: string[];
  maxResultCount?: number;
  rankPreference?: 'POPULARITY' | 'DISTANCE';
  openNow?: boolean;
  minRating?: number;
  includeBusinessProfiles?: boolean;
}): Promise<NearbySearchResponse>
```

**Example:**
```typescript
const results = await sdk.nearbySearch({
  locationRestriction: {
    circle: {
      center: { latitude: 37.7749, longitude: -122.4194 },
      radius: 500
    }
  },
  includedTypes: ['restaurant', 'cafe'],
  rankPreference: 'POPULARITY',
  maxResultCount: 20
});
```

### Autocomplete

```typescript
async autocomplete(params: {
  input: string;
  sessionToken?: string;
  fields?: string[];
  includedPrimaryTypes?: string[];
  includePureServiceAreaBusinesses?: boolean;
  includeQueryPredictions?: boolean;
  includedRegionCodes?: string[];
  inputOffset?: number;
  languageCode?: string;
  locationBias?: LocationBias;
  locationRestriction?: LocationRestriction;
  origin?: LatLng;
  regionCode?: string;
}): Promise<AutocompleteResponse>
```

**Example:**
```typescript
import { generateSessionToken } from '@aibizbot/google-places-sdk';

const sessionToken = generateSessionToken();

const suggestions = await sdk.autocomplete({
  input: 'Empire State',
  sessionToken,
  locationBias: {
    circle: {
      center: { latitude: 40.7128, longitude: -74.0060 },
      radius: 10000
    }
  }
});
```

### Place Photos

```typescript
async getPlacePhoto(params: {
  photoName: string;
  maxWidthPx?: number;
  maxHeightPx?: number;
  skipHttpRedirect?: boolean;
}): Promise<PlacePhotoResponse>
```

**Example:**
```typescript
const photo = await sdk.getPlacePhoto({
  photoName: 'places/ChIJ.../photos/AXCi...',
  maxWidthPx: 800
});

console.log(photo.photoUri); // URL to the photo
```

### Business Intelligence

```typescript
async businessIntelligence(params: {
  placeId: string;
  includeCompetitors?: boolean;
  competitorSearchRadius?: number;
  maxCompetitors?: number;
  languageCode?: string;
}): Promise<BusinessIntelligenceResponse>
```

**Example:**
```typescript
const analysis = await sdk.businessIntelligence({
  placeId: 'ChIJj61dQgK6j4AR4GeTYWZsKWw',
  includeCompetitors: true,
  competitorSearchRadius: 1000,
  maxCompetitors: 5
});

console.log(analysis.businessProfile);
console.log(analysis.recommendations);
console.log(analysis.competitiveAnalysis);
```

## Convenience Methods

### Find Business

Combines text search and place details for easy business lookup:

```typescript
async findBusiness(
  name: string,
  location?: { latitude: number; longitude: number },
  options?: { radius?: number; includeBusinessProfile?: boolean }
): Promise<Place | BusinessProfile | null>
```

**Example:**
```typescript
const business = await sdk.findBusiness(
  'Starbucks',
  { latitude: 40.7128, longitude: -74.0060 },
  { radius: 1000, includeBusinessProfile: true }
);
```

### Find Competitors

Find competitors near a specific business:

```typescript
async findCompetitors(
  placeId: string,
  options?: { radius?: number; maxResults?: number }
): Promise<Place[]>
```

**Example:**
```typescript
const competitors = await sdk.findCompetitors('ChIJ...', {
  radius: 500,
  maxResults: 10
});
```

## Types

### Core Types

```typescript
interface Place {
  id: string;
  name: string;
  displayName?: LocalizedText;
  formattedAddress?: string;
  location?: LatLng;
  types?: string[];
  primaryType?: string;
  rating?: number;
  userRatingCount?: number;
  // ... and more
}

interface BusinessProfile {
  placeId: string;
  name: string;
  address: string;
  phone?: string;
  website?: string;
  rating?: number;
  reviewCount?: number;
  industry: string;
  industryProfile?: IndustryProfile;
  aiSummary?: string;
  reviewSummary?: string;
  // ... and more
}

interface LatLng {
  latitude: number;
  longitude: number;
}
```

### Field Presets

```typescript
type FieldPreset = 
  | 'minimal'
  | 'basic'
  | 'contact'
  | 'ratings'
  | 'hours'
  | 'photos'
  | 'reviews'
  | 'ai_summary'
  | 'complete';
```

## Error Handling

```typescript
try {
  const results = await sdk.textSearch({
    textQuery: 'restaurants in New York'
  });
} catch (error) {
  if (error instanceof SDKError) {
    console.error('SDK Error:', error.message);
    console.error('Error Code:', error.code);
  } else {
    console.error('Unexpected error:', error);
  }
}
```

## Best Practices

### 1. Always Use Field Presets

```typescript
// ❌ Bad - requests all fields
const details = await sdk.getPlaceDetails({ placeId: '...' });

// ✅ Good - requests only needed fields
const details = await sdk.getPlaceDetails({
  placeId: '...',
  fieldPreset: 'basic'
});
```

### 2. Use Session Tokens for Autocomplete

```typescript
import { generateSessionToken } from '@aibizbot/google-places-sdk';

const token = generateSessionToken();

// Reuse token for all autocomplete calls in a session
await sdk.autocomplete({ input: 'Sta', sessionToken: token });
await sdk.autocomplete({ input: 'Star', sessionToken: token });
await sdk.autocomplete({ input: 'Starb', sessionToken: token });
```

### 3. Handle Connection Lifecycle

```typescript
const sdk = new GooglePlacesSDK({ serverPath: '...' });

try {
  await sdk.connect();
  // Use SDK
} finally {
  await sdk.disconnect();
}
```

### 4. Cache Results

```typescript
const cache = new Map();

async function getCachedPlaceDetails(placeId: string) {
  if (cache.has(placeId)) {
    return cache.get(placeId);
  }
  
  const details = await sdk.getPlaceDetails({ placeId });
  cache.set(placeId, details);
  return details;
}
```

## Advanced Usage

### Custom Field Selection

```typescript
const details = await sdk.getPlaceDetails({
  placeId: 'ChIJ...',
  fields: [
    'id',
    'displayName',
    'formattedAddress',
    'rating',
    'userRatingCount',
    'photos',
    'generativeSummary'
  ]
});
```

### Paginated Results

```typescript
let pageToken: string | undefined;
const allPlaces: Place[] = [];

do {
  const results = await sdk.textSearch({
    textQuery: 'restaurants in Manhattan',
    maxResultCount: 20,
    pageToken
  });
  
  allPlaces.push(...(results.places || []));
  pageToken = results.nextPageToken;
} while (pageToken);
```

### Batch Requests

```typescript
const placeIds = ['ChIJ...', 'ChIJ...', 'ChIJ...'];

const details = await Promise.all(
  placeIds.map(id => 
    sdk.getPlaceDetails({ 
      placeId: id, 
      fieldPreset: 'basic' 
    })
  )
);
```

## Troubleshooting

### Connection Issues

```typescript
// Verify server path
const sdk = new GooglePlacesSDK({
  serverPath: path.resolve(__dirname, '../dist/index.js')
});

// Check environment variables
console.log('API Key set:', !!process.env.GOOGLE_PLACES_API_KEY);
```

### Timeout Issues

```typescript
const sdk = new GooglePlacesSDK({
  serverPath: './dist/index.js',
  timeout: 60000 // Increase timeout
});
```

### Rate Limiting

```typescript
// Implement exponential backoff
async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries = 3
): Promise<T> {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      await delay(Math.pow(2, i) * 1000);
    }
  }
  throw new Error('Max retries exceeded');
}
```

---

For more examples, see the [examples directory](../examples/).
