/**
 * Field Mask Utilities for Google Places API
 * Predefined field masks for common use cases to optimize API requests
 */

/**
 * Field categories based on billing SKUs
 */
export const FieldCategories = {
  // Essentials ID Only SKU (lowest cost)
  ID_ONLY: [
    'id',
    'name',
    'attributions',
    'moved_place',
    'moved_place_id',
    'photos',
  ],

  // Essentials SKU
  ESSENTIALS: [
    'addressComponents',
    'addressDescriptor',
    'adrFormatAddress',
    'formattedAddress',
    'location',
    'plusCode',
    'postalAddress',
    'shortFormattedAddress',
    'types',
    'viewport',
  ],

  // Pro SKU
  PRO: [
    'accessibilityOptions',
    'businessStatus',
    'containingPlaces',
    'displayName',
    'googleMapsLinks',
    'googleMapsUri',
    'iconBackgroundColor',
    'iconMaskBaseUri',
    'primaryType',
    'primaryTypeDisplayName',
    'pureServiceAreaBusiness',
    'subDestinations',
    'utcOffsetMinutes',
  ],

  // Enterprise SKU
  ENTERPRISE: [
    'currentOpeningHours',
    'currentSecondaryOpeningHours',
    'internationalPhoneNumber',
    'nationalPhoneNumber',
    'priceLevel',
    'priceRange',
    'rating',
    'regularOpeningHours',
    'regularSecondaryOpeningHours',
    'userRatingCount',
    'websiteUri',
  ],

  // Enterprise + Atmosphere SKU (highest cost)
  ATMOSPHERE: [
    'allowsDogs',
    'curbsidePickup',
    'delivery',
    'dineIn',
    'editorialSummary',
    'evChargeAmenitySummary',
    'evChargeOptions',
    'fuelOptions',
    'generativeSummary',
    'goodForChildren',
    'goodForGroups',
    'goodForWatchingSports',
    'liveMusic',
    'menuForChildren',
    'neighborhoodSummary',
    'outdoorSeating',
    'parkingOptions',
    'paymentOptions',
    'reservable',
    'restroom',
    'reviews',
    'reviewSummary',
    'routingSummaries',
    'servesBeer',
    'servesBreakfast',
    'servesBrunch',
    'servesCocktails',
    'servesCoffee',
    'servesDessert',
    'servesDinner',
    'servesLunch',
    'servesVegetarianFood',
    'servesWine',
    'takeout',
  ],
};

/**
 * Predefined field masks for common use cases
 */
export const FieldMasks = {
  /**
   * Minimal fields - just identifiers
   * Use when: You only need to verify place existence or get photo references
   * Cost: Lowest (Essentials ID Only SKU)
   */
  MINIMAL: [
    'id',
    'displayName',
  ],

  /**
   * Basic fields for simple listings
   * Use when: Displaying a list of places with basic info
   * Cost: Essentials + Pro SKU
   */
  BASIC: [
    'id',
    'displayName',
    'formattedAddress',
    'location',
    'types',
    'primaryType',
    'primaryTypeDisplayName',
  ],

  /**
   * Contact fields for business listings
   * Use when: You need contact information
   * Cost: Essentials + Pro + Enterprise SKU
   */
  CONTACT: [
    'id',
    'displayName',
    'formattedAddress',
    'nationalPhoneNumber',
    'internationalPhoneNumber',
    'websiteUri',
    'location',
  ],

  /**
   * Rating fields for reviews and ratings
   * Use when: Displaying ratings and review counts
   * Cost: Essentials + Pro + Enterprise SKU
   */
  RATINGS: [
    'id',
    'displayName',
    'rating',
    'userRatingCount',
    'priceLevel',
    'priceRange',
  ],

  /**
   * Hours fields for operating hours
   * Use when: Displaying business hours
   * Cost: Essentials + Pro + Enterprise SKU
   */
  HOURS: [
    'id',
    'displayName',
    'regularOpeningHours',
    'currentOpeningHours',
    'utcOffsetMinutes',
    'businessStatus',
  ],

  /**
   * Photos fields for image display
   * Use when: Displaying place photos
   * Cost: Essentials ID Only + Pro SKU
   */
  PHOTOS: [
    'id',
    'displayName',
    'photos',
  ],

  /**
   * AI Summary fields for intelligent insights
   * Use when: Using Gemini AI-powered summaries
   * Cost: Essentials + Pro + Enterprise + Atmosphere SKU
   */
  AI_SUMMARY: [
    'id',
    'displayName',
    'generativeSummary',
    'reviewSummary',
    'areaSummary',
    'editorialSummary',
  ],

  /**
   * Reviews fields for customer feedback
   * Use when: Displaying customer reviews
   * Cost: Essentials + Pro + Enterprise + Atmosphere SKU
   */
  REVIEWS: [
    'id',
    'displayName',
    'reviews',
    'reviewSummary',
    'rating',
    'userRatingCount',
  ],

  /**
   * Accessibility fields for accessibility info
   * Use when: Displaying accessibility options
   * Cost: Essentials + Pro + Enterprise + Atmosphere SKU
   */
  ACCESSIBILITY: [
    'id',
    'displayName',
    'accessibilityOptions',
    'parkingOptions',
  ],

  /**
   * Amenities fields for business amenities
   * Use when: Displaying business amenities and services
   * Cost: Essentials + Pro + Enterprise + Atmosphere SKU
   */
  AMENITIES: [
    'id',
    'displayName',
    'curbsidePickup',
    'delivery',
    'dineIn',
    'outdoorSeating',
    'reservable',
    'restroom',
    'takeout',
    'servesBeer',
    'servesBreakfast',
    'servesBrunch',
    'servesCocktails',
    'servesCoffee',
    'servesDessert',
    'servesDinner',
    'servesLunch',
    'servesVegetarianFood',
    'servesWine',
    'allowsDogs',
    'goodForChildren',
    'goodForGroups',
    'goodForWatchingSports',
    'liveMusic',
    'menuForChildren',
    'paymentOptions',
  ],

  /**
   * EV Charging fields for electric vehicle charging stations
   * Use when: Displaying EV charging information
   * Cost: Essentials + Pro + Enterprise + Atmosphere SKU
   */
  EV_CHARGING: [
    'id',
    'displayName',
    'evChargeOptions',
    'evChargeAmenitySummary',
    'formattedAddress',
    'location',
  ],

  /**
   * Fuel fields for gas stations
   * Use when: Displaying fuel prices and options
   * Cost: Essentials + Pro + Enterprise + Atmosphere SKU
   */
  FUEL: [
    'id',
    'displayName',
    'fuelOptions',
    'formattedAddress',
    'location',
  ],

  /**
   * Complete business profile
   * Use when: Building a comprehensive business profile
   * Cost: All SKUs (highest cost)
   */
  COMPLETE_BUSINESS_PROFILE: [
    'id',
    'displayName',
    'formattedAddress',
    'shortFormattedAddress',
    'addressComponents',
    'location',
    'viewport',
    'types',
    'primaryType',
    'primaryTypeDisplayName',
    'nationalPhoneNumber',
    'internationalPhoneNumber',
    'websiteUri',
    'googleMapsUri',
    'rating',
    'userRatingCount',
    'priceLevel',
    'priceRange',
    'regularOpeningHours',
    'currentOpeningHours',
    'businessStatus',
    'photos',
    'reviews',
    'reviewSummary',
    'generativeSummary',
    'editorialSummary',
    'accessibilityOptions',
    'parkingOptions',
    'paymentOptions',
    'curbsidePickup',
    'delivery',
    'dineIn',
    'outdoorSeating',
    'reservable',
    'restroom',
    'takeout',
    'utcOffsetMinutes',
    'iconMaskBaseUri',
    'iconBackgroundColor',
  ],

  /**
   * Business intelligence fields for AI analysis
   * Use when: Performing business intelligence analysis
   * Cost: All SKUs (highest cost)
   */
  BUSINESS_INTELLIGENCE: [
    'id',
    'displayName',
    'formattedAddress',
    'location',
    'types',
    'primaryType',
    'primaryTypeDisplayName',
    'nationalPhoneNumber',
    'websiteUri',
    'rating',
    'userRatingCount',
    'priceLevel',
    'priceRange',
    'regularOpeningHours',
    'currentOpeningHours',
    'businessStatus',
    'photos',
    'reviews',
    'reviewSummary',
    'generativeSummary',
    'editorialSummary',
    'areaSummary',
    'accessibilityOptions',
    'parkingOptions',
    'paymentOptions',
    'curbsidePickup',
    'delivery',
    'dineIn',
    'outdoorSeating',
    'reservable',
    'restroom',
    'takeout',
    'servesBeer',
    'servesBreakfast',
    'servesBrunch',
    'servesCocktails',
    'servesCoffee',
    'servesDessert',
    'servesDinner',
    'servesLunch',
    'servesVegetarianFood',
    'servesWine',
    'allowsDogs',
    'goodForChildren',
    'goodForGroups',
    'goodForWatchingSports',
    'liveMusic',
    'menuForChildren',
  ],

  /**
   * All fields - use sparingly in production
   * Use when: Development and testing only
   * Cost: All SKUs (maximum cost)
   */
  ALL: ['*'],
};

/**
 * Get field mask for a specific use case
 */
export function getFieldMask(useCase: keyof typeof FieldMasks): string[] {
  return FieldMasks[useCase] || FieldMasks.BASIC;
}

/**
 * Combine multiple field masks
 */
export function combineFieldMasks(...masks: string[][]): string[] {
  const combined = new Set<string>();
  masks.forEach(mask => mask.forEach(field => combined.add(field)));
  return Array.from(combined);
}

/**
 * Create custom field mask from array of fields
 */
export function createFieldMask(fields: string[]): string[] {
  return [...new Set(fields)];
}

/**
 * Get fields by category
 */
export function getFieldsByCategory(category: keyof typeof FieldCategories): string[] {
  return FieldCategories[category] || [];
}

/**
 * Estimate API cost based on field mask
 * Returns approximate SKU categories that will be charged
 */
export function estimateCost(fields: string[]): {
  skus: string[];
  estimatedCost: 'low' | 'medium' | 'high' | 'very_high';
} {
  const skus: string[] = [];
  let hasIdOnly = false;
  let hasEssentials = false;
  let hasPro = false;
  let hasEnterprise = false;
  let hasAtmosphere = false;

  // Check for ID only fields
  const idOnlyFields = fields.filter(f => 
    FieldCategories.ID_ONLY.includes(f) || f === 'id' || f === 'name'
  );
  if (idOnlyFields.length > 0) {
    hasIdOnly = true;
    skus.push('Place Details Essentials ID Only');
  }

  // Check for essentials fields
  const essentialsFields = fields.filter(f => FieldCategories.ESSENTIALS.includes(f));
  if (essentialsFields.length > 0) {
    hasEssentials = true;
    skus.push('Place Details Essentials');
  }

  // Check for pro fields
  const proFields = fields.filter(f => FieldCategories.PRO.includes(f));
  if (proFields.length > 0) {
    hasPro = true;
    skus.push('Place Details Pro');
  }

  // Check for enterprise fields
  const enterpriseFields = fields.filter(f => FieldCategories.ENTERPRISE.includes(f));
  if (enterpriseFields.length > 0) {
    hasEnterprise = true;
    skus.push('Place Details Enterprise');
  }

  // Check for atmosphere fields
  const atmosphereFields = fields.filter(f => FieldCategories.ATMOSPHERE.includes(f));
  if (atmosphereFields.length > 0) {
    hasAtmosphere = true;
    skus.push('Place Details Enterprise + Atmosphere');
  }

  // Determine cost level
  let estimatedCost: 'low' | 'medium' | 'high' | 'very_high' = 'low';
  if (hasAtmosphere) {
    estimatedCost = 'very_high';
  } else if (hasEnterprise) {
    estimatedCost = 'high';
  } else if (hasPro) {
    estimatedCost = 'medium';
  } else if (hasEssentials || hasIdOnly) {
    estimatedCost = 'low';
  }

  return { skus, estimatedCost };
}

/**
 * Validate field mask
 * Returns validation result with any invalid fields
 */
export function validateFieldMask(fields: string[]): {
  valid: boolean;
  invalidFields: string[];
  allValidFields: string[];
} {
  const allValidFields = [
    ...FieldCategories.ID_ONLY,
    ...FieldCategories.ESSENTIALS,
    ...FieldCategories.PRO,
    ...FieldCategories.ENTERPRISE,
    ...FieldCategories.ATMOSPHERE,
  ];

  const invalidFields = fields.filter(f => 
    f !== '*' && !allValidFields.includes(f)
  );

  return {
    valid: invalidFields.length === 0,
    invalidFields,
    allValidFields: [...new Set(allValidFields)],
  };
}

export default {
  FieldCategories,
  FieldMasks,
  getFieldMask,
  combineFieldMasks,
  createFieldMask,
  getFieldsByCategory,
  estimateCost,
  validateFieldMask,
};
