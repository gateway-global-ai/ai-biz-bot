/**
 * Google Places API Client
 * HTTP client for making requests to Google Places API (New)
 */

import axios, { AxiosInstance, AxiosError } from 'axios';
import {
  Place,
  TextSearchResponse,
  NearbySearchResponse,
  AutocompleteResponse,
  PlacePhotoResponse,
  GooglePlacesError,
  PlaceDetailsParams,
  TextSearchParams,
  NearbySearchParams,
  AutocompleteParams,
  PlacePhotoParams,
} from '../types/index.js';

export interface APIClientConfig {
  apiKey: string;
  baseURL?: string;
  timeout?: number;
  retries?: number;
}

export class GooglePlacesAPIClient {
  private client: AxiosInstance;
  private apiKey: string;
  private retries: number;

  constructor(config: APIClientConfig) {
    this.apiKey = config.apiKey;
    this.retries = config.retries || 3;
    
    this.client = axios.create({
      baseURL: config.baseURL || 'https://places.googleapis.com/v1',
      timeout: config.timeout || 30000,
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': this.apiKey,
      },
    });

    // Add response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      async (error: AxiosError) => {
        const config = error.config;
        
        if (!config) {
          return Promise.reject(this.handleError(error));
        }

        // @ts-ignore - retry count tracking
        const retryCount = config.__retryCount || 0;
        
        // Retry on network errors or 5xx responses
        if (retryCount < this.retries && (
          !error.response || 
          (error.response.status >= 500 && error.response.status < 600) ||
          error.code === 'ECONNRESET' ||
          error.code === 'ETIMEDOUT'
        )) {
          // @ts-ignore
          config.__retryCount = retryCount + 1;
          
          // Exponential backoff
          const delay = Math.pow(2, retryCount) * 1000;
          await new Promise(resolve => setTimeout(resolve, delay));
          
          return this.client(config);
        }
        
        return Promise.reject(this.handleError(error));
      }
    );
  }

  /**
   * Get Place Details by Place ID
   */
  async getPlaceDetails(params: PlaceDetailsParams): Promise<Place> {
    const { placeId, fields, languageCode, regionCode, sessionToken } = params;
    
    const headers: Record<string, string> = {};
    
    if (fields && fields.length > 0) {
      headers['X-Goog-FieldMask'] = fields.join(',');
    } else {
      // Default fields if none specified
      headers['X-Goog-FieldMask'] = 'id,displayName,formattedAddress';
    }

    const queryParams: Record<string, string> = {};
    if (languageCode) queryParams.languageCode = languageCode;
    if (regionCode) queryParams.regionCode = regionCode;
    if (sessionToken) queryParams.sessionToken = sessionToken;

    const queryString = Object.keys(queryParams).length > 0
      ? '?' + new URLSearchParams(queryParams).toString()
      : '';

    const response = await this.client.get<Place>(
      `/places/${placeId}${queryString}`,
      { headers }
    );

    return response.data;
  }

  /**
   * Perform Text Search
   */
  async textSearch(params: TextSearchParams): Promise<TextSearchResponse> {
    const {
      textQuery,
      fields,
      languageCode,
      regionCode,
      locationBias,
      locationRestriction,
      includedType,
      openNow,
      minRating,
      maxResultCount,
      priceLevels,
      strictTypeFiltering,
      pageToken,
      evOptions,
    } = params;

    const headers: Record<string, string> = {};
    
    if (fields && fields.length > 0) {
      headers['X-Goog-FieldMask'] = `places.${fields.join(',places.')}`;
    } else {
      headers['X-Goog-FieldMask'] = 'places.id,places.displayName,places.formattedAddress';
    }

    const body: Record<string, any> = {
      textQuery,
    };

    if (languageCode) body.languageCode = languageCode;
    if (regionCode) body.regionCode = regionCode;
    if (locationBias) body.locationBias = locationBias;
    if (locationRestriction) body.locationRestriction = locationRestriction;
    if (includedType) body.includedType = includedType;
    if (openNow !== undefined) body.openNow = openNow;
    if (minRating !== undefined) body.minRating = minRating;
    if (maxResultCount) body.maxResultCount = maxResultCount;
    if (priceLevels) body.priceLevels = priceLevels;
    if (strictTypeFiltering !== undefined) body.strictTypeFiltering = strictTypeFiltering;
    if (pageToken) body.pageToken = pageToken;
    if (evOptions) body.evOptions = evOptions;

    const response = await this.client.post<TextSearchResponse>(
      '/places:searchText',
      body,
      { headers }
    );

    return response.data;
  }

  /**
   * Perform Nearby Search
   */
  async nearbySearch(params: NearbySearchParams): Promise<NearbySearchResponse> {
    const {
      locationRestriction,
      fields,
      languageCode,
      regionCode,
      includedTypes,
      excludedTypes,
      includedPrimaryTypes,
      excludedPrimaryTypes,
      maxResultCount,
      rankPreference,
      openNow,
      minRating,
      pageToken,
    } = params;

    const headers: Record<string, string> = {};
    
    if (fields && fields.length > 0) {
      headers['X-Goog-FieldMask'] = `places.${fields.join(',places.')}`;
    } else {
      headers['X-Goog-FieldMask'] = 'places.id,places.displayName,places.formattedAddress';
    }

    const body: Record<string, any> = {
      locationRestriction,
    };

    if (languageCode) body.languageCode = languageCode;
    if (regionCode) body.regionCode = regionCode;
    if (includedTypes) body.includedTypes = includedTypes;
    if (excludedTypes) body.excludedTypes = excludedTypes;
    if (includedPrimaryTypes) body.includedPrimaryTypes = includedPrimaryTypes;
    if (excludedPrimaryTypes) body.excludedPrimaryTypes = excludedPrimaryTypes;
    if (maxResultCount) body.maxResultCount = maxResultCount;
    if (rankPreference) body.rankPreference = rankPreference;
    if (openNow !== undefined) body.openNow = openNow;
    if (minRating !== undefined) body.minRating = minRating;
    if (pageToken) body.pageToken = pageToken;

    const response = await this.client.post<NearbySearchResponse>(
      '/places:searchNearby',
      body,
      { headers }
    );

    return response.data;
  }

  /**
   * Get Autocomplete Suggestions
   */
  async autocomplete(params: AutocompleteParams): Promise<AutocompleteResponse> {
    const {
      input,
      fields,
      includedPrimaryTypes,
      includePureServiceAreaBusinesses,
      includeQueryPredictions,
      includedRegionCodes,
      inputOffset,
      languageCode,
      locationBias,
      locationRestriction,
      origin,
      regionCode,
      sessionToken,
    } = params;

    const headers: Record<string, string> = {};
    
    if (fields && fields.length > 0) {
      headers['X-Goog-FieldMask'] = fields.join(',');
    }

    const body: Record<string, any> = {
      input,
    };

    if (includedPrimaryTypes) body.includedPrimaryTypes = includedPrimaryTypes;
    if (includePureServiceAreaBusinesses !== undefined) {
      body.includePureServiceAreaBusinesses = includePureServiceAreaBusinesses;
    }
    if (includeQueryPredictions !== undefined) body.includeQueryPredictions = includeQueryPredictions;
    if (includedRegionCodes) body.includedRegionCodes = includedRegionCodes;
    if (inputOffset !== undefined) body.inputOffset = inputOffset;
    if (languageCode) body.languageCode = languageCode;
    if (locationBias) body.locationBias = locationBias;
    if (locationRestriction) body.locationRestriction = locationRestriction;
    if (origin) body.origin = origin;
    if (regionCode) body.regionCode = regionCode;
    if (sessionToken) body.sessionToken = sessionToken;

    const response = await this.client.post<AutocompleteResponse>(
      '/places:autocomplete',
      body,
      { headers }
    );

    return response.data;
  }

  /**
   * Get Place Photo
   */
  async getPlacePhoto(params: PlacePhotoParams): Promise<PlacePhotoResponse> {
    const { photoName, maxWidthPx, maxHeightPx, skipHttpRedirect } = params;

    const queryParams: Record<string, string> = {};
    if (maxWidthPx) queryParams.maxWidthPx = maxWidthPx.toString();
    if (maxHeightPx) queryParams.maxHeightPx = maxHeightPx.toString();
    if (skipHttpRedirect !== undefined) {
      queryParams.skipHttpRedirect = skipHttpRedirect.toString();
    }

    const queryString = Object.keys(queryParams).length > 0
      ? '?' + new URLSearchParams(queryParams).toString()
      : '';

    const response = await this.client.get<PlacePhotoResponse>(
      `/${photoName}/media${queryString}`
    );

    return response.data;
  }

  /**
   * Handle API errors
   */
  private handleError(error: AxiosError): GooglePlacesError {
    if (error.response) {
      const data = error.response.data as any;
      return {
        code: error.response.status,
        message: data?.error?.message || error.message,
        status: data?.error?.status || 'UNKNOWN_ERROR',
        details: data?.error?.details,
      };
    }

    return {
      code: 0,
      message: error.message,
      status: 'NETWORK_ERROR',
    };
  }
}

export default GooglePlacesAPIClient;
