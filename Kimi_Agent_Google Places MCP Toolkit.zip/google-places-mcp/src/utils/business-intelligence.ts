/**
 * Business Intelligence Utilities
 * Transform Google Places data into actionable business insights
 */

import {
  Place,
  Review,
  BusinessProfile,
  IndustryProfile,
  CompetitiveAnalysis,
  MarketInsights,
  OpeningHours,
} from '../types/index.js';

/**
 * Industry type mappings from Google Places types to business categories
 */
export const IndustryMappings: Record<string, { category: string; subcategory?: string }> = {
  // Restaurants & Food
  restaurant: { category: 'Food & Beverage', subcategory: 'Restaurant' },
  cafe: { category: 'Food & Beverage', subcategory: 'Cafe' },
  bakery: { category: 'Food & Beverage', subcategory: 'Bakery' },
  bar: { category: 'Food & Beverage', subcategory: 'Bar' },
  meal_takeaway: { category: 'Food & Beverage', subcategory: 'Takeaway' },
  meal_delivery: { category: 'Food & Beverage', subcategory: 'Delivery' },
  
  // Retail
  store: { category: 'Retail', subcategory: 'General Store' },
  shopping_mall: { category: 'Retail', subcategory: 'Shopping Mall' },
  clothing_store: { category: 'Retail', subcategory: 'Clothing' },
  electronics_store: { category: 'Retail', subcategory: 'Electronics' },
  furniture_store: { category: 'Retail', subcategory: 'Furniture' },
  grocery_or_supermarket: { category: 'Retail', subcategory: 'Grocery' },
  convenience_store: { category: 'Retail', subcategory: 'Convenience' },
  
  // Healthcare
  hospital: { category: 'Healthcare', subcategory: 'Hospital' },
  doctor: { category: 'Healthcare', subcategory: 'Doctor' },
  dentist: { category: 'Healthcare', subcategory: 'Dentist' },
  pharmacy: { category: 'Healthcare', subcategory: 'Pharmacy' },
  physiotherapist: { category: 'Healthcare', subcategory: 'Physiotherapy' },
  veterinary_care: { category: 'Healthcare', subcategory: 'Veterinary' },
  
  // Professional Services
  lawyer: { category: 'Professional Services', subcategory: 'Legal' },
  accountant: { category: 'Professional Services', subcategory: 'Accounting' },
  insurance_agency: { category: 'Professional Services', subcategory: 'Insurance' },
  real_estate_agency: { category: 'Professional Services', subcategory: 'Real Estate' },
  
  // Hospitality
  lodging: { category: 'Hospitality', subcategory: 'Lodging' },
  hotel: { category: 'Hospitality', subcategory: 'Hotel' },
  
  // Automotive
  car_dealer: { category: 'Automotive', subcategory: 'Car Dealer' },
  car_repair: { category: 'Automotive', subcategory: 'Car Repair' },
  car_wash: { category: 'Automotive', subcategory: 'Car Wash' },
  gas_station: { category: 'Automotive', subcategory: 'Gas Station' },
  
  // Beauty & Wellness
  beauty_salon: { category: 'Beauty & Wellness', subcategory: 'Beauty Salon' },
  hair_care: { category: 'Beauty & Wellness', subcategory: 'Hair Care' },
  spa: { category: 'Beauty & Wellness', subcategory: 'Spa' },
  gym: { category: 'Beauty & Wellness', subcategory: 'Fitness' },
  
  // Home Services
  electrician: { category: 'Home Services', subcategory: 'Electrical' },
  plumber: { category: 'Home Services', subcategory: 'Plumbing' },
  roofing_contractor: { category: 'Home Services', subcategory: 'Roofing' },
  general_contractor: { category: 'Home Services', subcategory: 'General Contracting' },
  
  // Entertainment
  movie_theater: { category: 'Entertainment', subcategory: 'Cinema' },
  night_club: { category: 'Entertainment', subcategory: 'Nightclub' },
  casino: { category: 'Entertainment', subcategory: 'Casino' },
  amusement_park: { category: 'Entertainment', subcategory: 'Amusement Park' },
  
  // Education
  school: { category: 'Education', subcategory: 'School' },
  university: { category: 'Education', subcategory: 'University' },
  
  // Financial
  bank: { category: 'Financial', subcategory: 'Banking' },
  atm: { category: 'Financial', subcategory: 'ATM' },
};

/**
 * Common pain points by industry category
 */
export const IndustryPainPoints: Record<string, string[]> = {
  'Food & Beverage': [
    'Managing peak hour rush and wait times',
    'Food quality consistency',
    'Staff scheduling and turnover',
    'Inventory management and waste',
    'Online ordering and delivery coordination',
    'Customer reservation management',
    'Handling customer complaints',
    'Maintaining hygiene standards',
  ],
  'Retail': [
    'Inventory management across channels',
    'Customer foot traffic conversion',
    'Competing with online retailers',
    'Staff product knowledge',
    'Returns and exchanges handling',
    'Seasonal demand fluctuations',
    'Loss prevention',
    'Customer loyalty retention',
  ],
  'Healthcare': [
    'Appointment scheduling efficiency',
    'Patient wait times',
    'Medical record management',
    'Insurance claim processing',
    'Patient communication and follow-up',
    'Staff coordination',
    'Emergency scheduling',
    'Regulatory compliance',
  ],
  'Professional Services': [
    'Client appointment scheduling',
    'Billable hour tracking',
    'Client communication management',
    'Document management',
    'Payment collection',
    'Lead qualification',
    'Service delivery consistency',
    'Professional development tracking',
  ],
  'Hospitality': [
    'Booking management across channels',
    'Guest check-in/check-out efficiency',
    'Room availability optimization',
    'Guest service requests',
    'Housekeeping coordination',
    'Special requests handling',
    'Review management',
    'Loyalty program management',
  ],
  'Automotive': [
    'Service appointment scheduling',
    'Parts inventory management',
    'Customer vehicle status updates',
    'Warranty claim processing',
    'Service recommendation communication',
    'Loaner vehicle coordination',
    'Customer wait time management',
    'Technician scheduling',
  ],
  'Beauty & Wellness': [
    'Appointment scheduling and no-shows',
    'Client preference tracking',
    'Product inventory management',
    'Staff scheduling',
    'Service upselling',
    'Client retention',
    'Treatment reminders',
    'Gift certificate management',
  ],
  'Home Services': [
    'Emergency call handling',
    'Appointment scheduling',
    'Quote and estimate management',
    'Job status updates',
    'Parts and material ordering',
    'Customer communication',
    'Payment collection',
    'Warranty service tracking',
  ],
  'Entertainment': [
    'Ticket sales and reservations',
    'Crowd management',
    'Event scheduling',
    'Customer experience optimization',
    'VIP guest handling',
    'Safety and security',
    'Food and beverage coordination',
    'Lost and found management',
  ],
  'Education': [
    'Student enrollment management',
    'Parent communication',
    'Schedule coordination',
    'Emergency notification',
    'Attendance tracking',
    'Performance reporting',
    'Resource booking',
    'Event management',
  ],
  'Financial': [
    'Account inquiry handling',
    'Appointment scheduling',
    'Fraud alert communication',
    'Loan application updates',
    'Document verification',
    'Customer authentication',
    'Product cross-selling',
    'Regulatory compliance',
  ],
};

/**
 * Transform Google Place into Business Profile
 */
export function transformToBusinessProfile(place: Place): BusinessProfile {
  // Determine industry from types
  const industry = determineIndustry(place.types || []);
  
  // Get AI summary
  const aiSummary = place.generativeSummary?.overview?.text || 
                    place.editorialSummary?.overview || 
                    undefined;
  
  // Get review summary
  const reviewSummary = place.reviewSummary?.text?.text || undefined;

  return {
    placeId: place.id,
    name: place.displayName?.text || 'Unknown',
    address: place.formattedAddress || 'No address available',
    phone: place.nationalPhoneNumber,
    website: place.websiteUri,
    rating: place.rating,
    reviewCount: place.userRatingCount,
    businessStatus: place.businessStatus,
    primaryType: place.primaryType,
    types: place.types || [],
    hours: place.regularOpeningHours,
    photos: place.photos,
    reviews: place.reviews,
    aiSummary,
    reviewSummary,
    industry: industry.category,
    industryProfile: {
      category: industry.category,
      subcategory: industry.subcategory,
      commonPainPoints: IndustryPainPoints[industry.category] || [],
      typicalServices: getTypicalServices(place.types || []),
      peakHours: extractPeakHours(place.regularOpeningHours),
    },
  };
}

/**
 * Determine industry from place types
 */
export function determineIndustry(types: string[]): { category: string; subcategory?: string } {
  for (const type of types) {
    if (IndustryMappings[type]) {
      return IndustryMappings[type];
    }
  }
  return { category: 'General Business', subcategory: 'Other' };
}

/**
 * Get typical services based on place types
 */
export function getTypicalServices(types: string[]): string[] {
  const services: string[] = [];
  
  if (types.includes('restaurant') || types.includes('cafe')) {
    services.push('Dine-in', 'Takeaway', 'Reservations');
  }
  if (types.includes('meal_delivery')) {
    services.push('Delivery');
  }
  if (types.includes('bar')) {
    services.push('Bar Service', 'Happy Hour');
  }
  if (types.includes('store') || types.includes('shopping_mall')) {
    services.push('In-store Shopping', 'Returns', 'Gift Cards');
  }
  if (types.includes('lodging') || types.includes('hotel')) {
    services.push('Room Service', 'Concierge', 'Housekeeping');
  }
  if (types.includes('hair_care') || types.includes('beauty_salon')) {
    services.push('Appointments', 'Walk-ins', 'Consultations');
  }
  if (types.includes('doctor') || types.includes('hospital')) {
    services.push('Appointments', 'Emergency Care', 'Telemedicine');
  }
  
  return services;
}

/**
 * Extract peak hours from opening hours
 */
export function extractPeakHours(hours?: OpeningHours): string[] | undefined {
  if (!hours || !hours.periods) return undefined;
  
  // Common peak hours patterns
  const peakPatterns = ['Lunch (11AM-2PM)', 'Dinner (6PM-9PM)', 'Weekends'];
  
  return peakPatterns;
}

/**
 * Analyze reviews for sentiment and themes
 */
export function analyzeReviews(reviews: Review[]): {
  averageRating: number;
  totalReviews: number;
  positiveThemes: string[];
  negativeThemes: string[];
  commonComplaints: string[];
  praisedAspects: string[];
} {
  const totalReviews = reviews.length;
  const averageRating = reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews;
  
  const positiveThemes: string[] = [];
  const negativeThemes: string[] = [];
  const commonComplaints: string[] = [];
  const praisedAspects: string[] = [];
  
  // Analyze review text for themes
  const positiveKeywords: Record<string, string[]> = {
    'Service': ['friendly', 'helpful', 'professional', 'courteous', 'attentive'],
    'Quality': ['excellent', 'high quality', 'fresh', 'delicious', 'amazing'],
    'Atmosphere': ['cozy', 'clean', 'beautiful', 'comfortable', 'welcoming'],
    'Value': ['affordable', 'reasonable', 'worth', 'great value', 'good price'],
    'Speed': ['fast', 'quick', 'efficient', 'prompt', 'timely'],
  };
  
  const negativeKeywords: Record<string, string[]> = {
    'Service': ['rude', 'unhelpful', 'slow service', 'ignored', 'unprofessional'],
    'Quality': ['poor quality', 'stale', 'bad', 'terrible', 'disappointing'],
    'Cleanliness': ['dirty', 'messy', 'unclean', 'filthy', 'unsanitary'],
    'Value': ['expensive', 'overpriced', 'not worth', 'rip off', 'costly'],
    'Wait Times': ['long wait', 'slow', 'delayed', 'forever', 'hours'],
  };
  
  reviews.forEach(review => {
    const text = review.text?.text?.toLowerCase() || '';
    
    // Check positive keywords
    Object.entries(positiveKeywords).forEach(([theme, keywords]) => {
      if (keywords.some(kw => text.includes(kw))) {
        if (!praisedAspects.includes(theme)) {
          praisedAspects.push(theme);
        }
      }
    });
    
    // Check negative keywords
    Object.entries(negativeKeywords).forEach(([theme, keywords]) => {
      if (keywords.some(kw => text.includes(kw))) {
        if (!commonComplaints.includes(theme)) {
          commonComplaints.push(theme);
        }
      }
    });
  });
  
  return {
    averageRating,
    totalReviews,
    positiveThemes,
    negativeThemes,
    commonComplaints,
    praisedAspects,
  };
}

/**
 * Perform competitive analysis
 */
export function performCompetitiveAnalysis(
  targetBusiness: BusinessProfile,
  competitors: Place[]
): CompetitiveAnalysis {
  const competitorProfiles = competitors.map(transformToBusinessProfile);
  
  // Calculate market insights
  const allRatings = [
    targetBusiness.rating,
    ...competitorProfiles.map(c => c.rating).filter((r): r is number => r !== undefined),
  ].filter((r): r is number => r !== undefined);
  
  const averageRating = allRatings.reduce((a, b) => a + b, 0) / allRatings.length;
  
  const totalReviews = [
    targetBusiness.reviewCount,
    ...competitorProfiles.map(c => c.reviewCount).filter((r): r is number => r !== undefined),
  ].filter((r): r is number => r !== undefined).reduce((a, b) => a + b, 0);
  
  // Price level distribution
  const priceLevelDistribution: Record<string, number> = {};
  competitors.forEach(c => {
    const level = c.priceLevel || 'UNKNOWN';
    priceLevelDistribution[level] = (priceLevelDistribution[level] || 0) + 1;
  });
  
  // Top amenities
  const amenityCounts: Record<string, number> = {};
  competitors.forEach(c => {
    // Count common amenities
    if (c.dineIn) amenityCounts['Dine-in'] = (amenityCounts['Dine-in'] || 0) + 1;
    if (c.delivery) amenityCounts['Delivery'] = (amenityCounts['Delivery'] || 0) + 1;
    if (c.takeout) amenityCounts['Takeout'] = (amenityCounts['Takeout'] || 0) + 1;
    if (c.outdoorSeating) amenityCounts['Outdoor Seating'] = (amenityCounts['Outdoor Seating'] || 0) + 1;
    if (c.reservable) amenityCounts['Reservations'] = (amenityCounts['Reservations'] || 0) + 1;
  });
  
  const topAmenities = Object.entries(amenityCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([amenity]) => amenity);
  
  return {
    targetBusiness,
    competitors: competitorProfiles,
    marketInsights: {
      averageRating,
      totalReviews,
      priceLevelDistribution,
      topAmenities,
      commonComplaints: [], // Would need review analysis
    },
  };
}

/**
 * Generate business recommendations based on profile
 */
export function generateRecommendations(profile: BusinessProfile): string[] {
  const recommendations: string[] = [];
  
  // Rating-based recommendations
  if (profile.rating !== undefined) {
    if (profile.rating < 4.0) {
      recommendations.push('Focus on improving customer satisfaction to boost ratings above 4.0');
    }
    if (profile.rating >= 4.5) {
      recommendations.push('Leverage high ratings in marketing materials and highlight customer satisfaction');
    }
  }
  
  // Review count recommendations
  if (profile.reviewCount !== undefined && profile.reviewCount < 50) {
    recommendations.push('Encourage satisfied customers to leave reviews to build social proof');
  }
  
  // Hours-based recommendations
  if (profile.hours) {
    recommendations.push('Consider extending hours during peak seasons to capture more business');
  }
  
  // Industry-specific recommendations
  if (profile.industry === 'Food & Beverage') {
    recommendations.push('Implement online reservation system to manage peak hour demand');
    recommendations.push('Consider offering delivery/takeout options if not already available');
  }
  
  if (profile.industry === 'Retail') {
    recommendations.push('Implement loyalty program to increase customer retention');
    recommendations.push('Consider omnichannel strategy to compete with online retailers');
  }
  
  if (profile.industry === 'Healthcare') {
    recommendations.push('Implement online appointment booking to reduce phone call volume');
    recommendations.push('Set up automated appointment reminders to reduce no-shows');
  }
  
  if (profile.industry === 'Professional Services') {
    recommendations.push('Implement online scheduling to streamline appointment booking');
    recommendations.push('Set up automated follow-up sequences for client engagement');
  }
  
  return recommendations;
}

/**
 * Format business hours for display
 */
export function formatBusinessHours(hours?: OpeningHours): string[] {
  if (!hours || !hours.weekdayDescriptions) {
    return ['Hours not available'];
  }
  
  return hours.weekdayDescriptions;
}

/**
 * Check if business is currently open
 */
export function isBusinessOpen(hours?: OpeningHours): boolean | undefined {
  if (!hours) return undefined;
  return hours.openNow;
}

/**
 * Get next opening time
 */
export function getNextOpeningTime(hours?: OpeningHours): string | undefined {
  if (!hours || !hours.periods) return undefined;
  
  // This would require more complex logic to determine next opening
  // For now, return a placeholder
  return 'Check regular hours';
}

export default {
  IndustryMappings,
  IndustryPainPoints,
  transformToBusinessProfile,
  determineIndustry,
  getTypicalServices,
  extractPeakHours,
  analyzeReviews,
  performCompetitiveAnalysis,
  generateRecommendations,
  formatBusinessHours,
  isBusinessOpen,
  getNextOpeningTime,
};
