/**
 * Google Places API Types
 * Comprehensive type definitions for Google Places API (New) responses
 */

// ============================================================================
// Common Types
// ============================================================================

export interface LatLng {
  latitude: number;
  longitude: number;
}

export interface Viewport {
  low: LatLng;
  high: LatLng;
}

export interface Circle {
  center: LatLng;
  radius: number;
}

export interface Rectangle {
  low: LatLng;
  high: LatLng;
}

export interface LocationBias {
  circle?: Circle;
  rectangle?: Rectangle;
}

export interface LocationRestriction {
  circle?: Circle;
  rectangle?: Rectangle;
}

export interface LocalizedText {
  text: string;
  languageCode?: string;
}

export interface AddressComponent {
  longText: string;
  shortText: string;
  types: string[];
}

export interface PlusCode {
  globalCode: string;
  compoundCode: string;
}

export interface PostalAddress {
  regionCode?: string;
  languageCode?: string;
  postalCode?: string;
  locality?: string;
  subLocality?: string;
  addressLines?: string[];
  recipients?: string[];
  organization?: string;
}

// ============================================================================
// Photo Types
// ============================================================================

export interface Photo {
  name: string;
  widthPx: number;
  heightPx: number;
  authorAttributions: AuthorAttribution[];
}

export interface AuthorAttribution {
  displayName: string;
  uri?: string;
  photoUri?: string;
}

// ============================================================================
// Opening Hours Types
// ============================================================================

export interface OpeningHours {
  openNow?: boolean;
  periods: Period[];
  weekdayDescriptions: string[];
  specialDays?: SpecialDay[];
  type?: string;
}

export interface Period {
  open: Point;
  close?: Point;
}

export interface Point {
  day: number;
  hour: number;
  minute: number;
  date?: {
    year: number;
    month: number;
    day: number;
  };
  truncated?: boolean;
}

export interface SpecialDay {
  date?: {
    year: number;
    month: number;
    day: number;
  };
}

// ============================================================================
// Review Types
// ============================================================================

export interface Review {
  name?: string;
  relativePublishTimeDescription: string;
  text?: LocalizedText;
  originalText?: LocalizedText;
  rating: number;
  authorAttribution: AuthorAttribution;
  publishTime: string;
  flagContentUri?: string;
  googleMapsUri?: string;
}

// ============================================================================
// AI Summary Types
// ============================================================================

export interface GenerativeSummary {
  overview?: LocalizedText;
  description?: LocalizedText;
  references?: Reference[];
}

export interface ReviewSummary {
  text?: LocalizedText;
  flagContentUri?: string;
}

export interface AreaSummary {
  content: LocalizedText;
  flagContentUri?: string;
}

export interface Reference {
  name: string;
  uri?: string;
  photoUri?: string;
}

export interface EditorialSummary {
  overview?: string;
  languageCode?: string;
}

// ============================================================================
// Place Types
// ============================================================================

export interface Place {
  // Core Identifiers
  name: string;
  id: string;
  displayName?: LocalizedText;
  
  // Address Information
  formattedAddress?: string;
  shortFormattedAddress?: string;
  addressComponents?: AddressComponent[];
  adrFormatAddress?: string;
  plusCode?: PlusCode;
  postalAddress?: PostalAddress;
  
  // Location
  location?: LatLng;
  viewport?: Viewport;
  
  // Types
  types?: string[];
  primaryType?: string;
  primaryTypeDisplayName?: LocalizedText;
  
  // Contact
  nationalPhoneNumber?: string;
  internationalPhoneNumber?: string;
  websiteUri?: string;
  
  // Business Info
  businessStatus?: 'OPERATIONAL' | 'CLOSED_TEMPORARILY' | 'CLOSED_PERMANENTLY';
  iconMaskBaseUri?: string;
  iconBackgroundColor?: string;
  
  // Ratings & Reviews
  rating?: number;
  userRatingCount?: number;
  reviews?: Review[];
  
  // Photos
  photos?: Photo[];
  
  // Hours
  regularOpeningHours?: OpeningHours;
  currentOpeningHours?: OpeningHours;
  regularSecondaryOpeningHours?: OpeningHours[];
  currentSecondaryOpeningHours?: OpeningHours[];
  utcOffsetMinutes?: number;
  
  // AI Summaries
  generativeSummary?: GenerativeSummary;
  reviewSummary?: ReviewSummary;
  areaSummary?: AreaSummary;
  editorialSummary?: EditorialSummary;
  
  // Price & Payment
  priceLevel?: 'PRICE_LEVEL_UNSPECIFIED' | 'PRICE_LEVEL_FREE' | 'PRICE_LEVEL_INEXPENSIVE' | 'PRICE_LEVEL_MODERATE' | 'PRICE_LEVEL_EXPENSIVE' | 'PRICE_LEVEL_VERY_EXPENSIVE';
  priceRange?: PriceRange;
  paymentOptions?: PaymentOptions;
  
  // Amenities
  accessibilityOptions?: AccessibilityOptions;
  parkingOptions?: ParkingOptions;
  evChargeOptions?: EVChargeOptions;
  fuelOptions?: FuelOptions;
  
  // Services
  curbsidePickup?: boolean;
  delivery?: boolean;
  dineIn?: boolean;
  goodForChildren?: boolean;
  goodForGroups?: boolean;
  goodForWatchingSports?: boolean;
  liveMusic?: boolean;
  menuForChildren?: boolean;
  outdoorSeating?: boolean;
  reservable?: boolean;
  restroom?: boolean;
  servesBeer?: boolean;
  servesBreakfast?: boolean;
  servesBrunch?: boolean;
  servesCocktails?: boolean;
  servesCoffee?: boolean;
  servesDessert?: boolean;
  servesDinner?: boolean;
  servesLunch?: boolean;
  servesVegetarianFood?: boolean;
  servesWine?: boolean;
  takeout?: boolean;
  allowsDogs?: boolean;
  
  // Other
  googleMapsUri?: string;
  googleMapsLinks?: GoogleMapsLinks;
  pureServiceAreaBusiness?: boolean;
  
  // Relocation
  movedPlace?: string;
  movedPlaceId?: string;
  
  // Sub-destinations
  subDestinations?: SubDestination[];
  containingPlaces?: ContainingPlace[];
  
  // Address Descriptor
  addressDescriptor?: AddressDescriptor;
}

export interface PriceRange {
  startPrice?: Money;
  endPrice?: Money;
}

export interface Money {
  currencyCode: string;
  units: string;
  nanos?: number;
}

export interface PaymentOptions {
  acceptsCreditCards?: boolean;
  acceptsDebitCards?: boolean;
  acceptsCashOnly?: boolean;
  acceptsNfc?: boolean;
}

export interface AccessibilityOptions {
  wheelchairAccessibleParking?: boolean;
  wheelchairAccessibleEntrance?: boolean;
  wheelchairAccessibleRestroom?: boolean;
  wheelchairAccessibleSeating?: boolean;
}

export interface ParkingOptions {
  freeParkingLot?: boolean;
  paidParkingLot?: boolean;
  freeStreetParking?: boolean;
  paidStreetParking?: boolean;
  valetParking?: boolean;
  freeGarageParking?: boolean;
  paidGarageParking?: boolean;
}

export interface EVChargeOptions {
  connectorAggregation: EVConnectorAggregation[];
}

export interface EVConnectorAggregation {
  type: string;
  maxChargeRateKw: number;
  count: number;
  availableCount?: number;
  outOfServiceCount?: number;
  availabilityLastUpdateTime?: string;
}

export interface FuelOptions {
  fuelPrices: FuelPrice[];
}

export interface FuelPrice {
  type: string;
  price?: Money;
  updateTime?: string;
}

export interface GoogleMapsLinks {
  directionsUri?: string;
  placeUri?: string;
  writeAReviewUri?: string;
  reviewsUri?: string;
  photosUri?: string;
}

export interface SubDestination {
  name: string;
  id: string;
  displayName?: LocalizedText;
}

export interface ContainingPlace {
  name: string;
  id: string;
  displayName?: LocalizedText;
}

export interface AddressDescriptor {
  landmarks: Landmark[];
  areas: Area[];
}

export interface Landmark {
  name: string;
  placeId: string;
  displayName: LocalizedText;
  types: string[];
  spatialRelationship?: string;
  straightLineDistanceMeters?: number;
}

export interface Area {
  name: string;
  placeId: string;
  displayName: LocalizedText;
  containment?: string;
}

// ============================================================================
// Search Response Types
// ============================================================================

export interface TextSearchResponse {
  places: Place[];
  nextPageToken?: string;
}

export interface NearbySearchResponse {
  places: Place[];
  nextPageToken?: string;
}

// ============================================================================
// Autocomplete Types
// ============================================================================

export interface AutocompleteResponse {
  suggestions: Suggestion[];
}

export interface Suggestion {
  placePrediction?: PlacePrediction;
  queryPrediction?: QueryPrediction;
}

export interface PlacePrediction {
  place: string;
  placeId: string;
  text: LocalizedText;
  structuredFormat?: StructuredFormat;
  types?: string[];
  distanceMeters?: number;
}

export interface QueryPrediction {
  text: LocalizedText;
  structuredFormat?: StructuredFormat;
}

export interface StructuredFormat {
  mainText: LocalizedText;
  secondaryText: LocalizedText;
}

// ============================================================================
// Photo Response Types
// ============================================================================

export interface PlacePhotoResponse {
  photoUri: string;
}

// ============================================================================
// Error Types
// ============================================================================

export interface GooglePlacesError {
  code: number;
  message: string;
  status: string;
  details?: ErrorDetail[];
}

export interface ErrorDetail {
  '@type': string;
  fieldViolations?: FieldViolation[];
}

export interface FieldViolation {
  field: string;
  description: string;
}

// ============================================================================
// Request Parameter Types
// ============================================================================

export interface PlaceDetailsParams {
  placeId: string;
  fields?: string[];
  languageCode?: string;
  regionCode?: string;
  sessionToken?: string;
}

export interface TextSearchParams {
  textQuery: string;
  fields?: string[];
  languageCode?: string;
  regionCode?: string;
  locationBias?: LocationBias;
  locationRestriction?: LocationRestriction;
  includedType?: string;
  openNow?: boolean;
  minRating?: number;
  maxResultCount?: number;
  priceLevels?: string[];
  strictTypeFiltering?: boolean;
  pageToken?: string;
  evOptions?: EVOptions;
}

export interface NearbySearchParams {
  locationRestriction: LocationRestriction;
  fields?: string[];
  languageCode?: string;
  regionCode?: string;
  includedTypes?: string[];
  excludedTypes?: string[];
  includedPrimaryTypes?: string[];
  excludedPrimaryTypes?: string[];
  maxResultCount?: number;
  rankPreference?: 'POPULARITY' | 'DISTANCE';
  openNow?: boolean;
  minRating?: number;
  pageToken?: string;
}

export interface AutocompleteParams {
  input: string;
  fields?: string[];
  includedPrimaryTypes?: string[];
  includePureServiceAreaBusinesses?: boolean;
  includeQueryPredictions?: boolean;
  includedRegionCodes?: string[];
  inputOffset?: number;
  languageCode?: string;
  locationBias?: LocationBias;
  locationRestriction?: LocationRestriction;
  origin?: LatLng;
  regionCode?: string;
  sessionToken?: string;
}

export interface PlacePhotoParams {
  photoName: string;
  maxWidthPx?: number;
  maxHeightPx?: number;
  skipHttpRedirect?: boolean;
}

export interface EVOptions {
  minimumChargingRateKw?: number;
  connectorTypes?: string[];
}

// ============================================================================
// MCP Tool Types
// ============================================================================

export interface MCPTool {
  name: string;
  description: string;
  inputSchema: object;
}

export interface MCPToolResponse {
  content: Array<{
    type: 'text' | 'image' | 'resource';
    text?: string;
    data?: string;
    mimeType?: string;
  }>;
  isError?: boolean;
}

// ============================================================================
// Business Intelligence Types
// ============================================================================

export interface BusinessProfile {
  placeId: string;
  name: string;
  address: string;
  phone?: string;
  website?: string;
  rating?: number;
  reviewCount?: number;
  businessStatus?: string;
  primaryType?: string;
  types: string[];
  hours?: OpeningHours;
  photos?: Photo[];
  reviews?: Review[];
  aiSummary?: string;
  reviewSummary?: string;
  industry: string;
  industryProfile?: IndustryProfile;
}

export interface IndustryProfile {
  category: string;
  subcategory?: string;
  commonPainPoints: string[];
  typicalServices: string[];
  peakHours?: string[];
  seasonality?: string;
}

export interface CompetitiveAnalysis {
  targetBusiness: BusinessProfile;
  competitors: BusinessProfile[];
  marketInsights: MarketInsights;
}

export interface MarketInsights {
  averageRating: number;
  totalReviews: number;
  priceLevelDistribution: Record<string, number>;
  topAmenities: string[];
  commonComplaints: string[];
}
