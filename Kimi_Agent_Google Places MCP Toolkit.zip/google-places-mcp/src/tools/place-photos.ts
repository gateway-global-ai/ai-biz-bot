/**
 * Place Photos Tool
 * MCP tool for retrieving place photos
 */

import { z } from 'zod';
import { GooglePlacesAPIClient } from '../utils/api-client.js';
import { MCPTool, MCPToolResponse } from '../types/index.js';

// Tool definition
export const placePhotosTool: MCPTool = {
  name: 'google_places_get_photo',
  description: `Retrieve a photo for a place using its photo reference. Returns a URL 
to the photo image that can be displayed or downloaded.

Use Cases:
- Displaying business photos in listings
- Creating photo galleries
- Building visual business profiles

Photo Sizing:
- Use 'maxWidthPx' or 'maxHeightPx' to control photo size
- Only specify one dimension to maintain aspect ratio
- Maximum size: 4800px for either dimension

Note: Photo URLs are not permanent. Cache photos locally if needed for extended use.`,
  inputSchema: {
    type: 'object',
    properties: {
      photoName: {
        type: 'string',
        description: 'Photo resource name from Place Details (e.g., "places/ChIJ.../photos/AXCi...")',
      },
      maxWidthPx: {
        type: 'number',
        description: 'Maximum width in pixels (1-4800)',
        minimum: 1,
        maximum: 4800,
      },
      maxHeightPx: {
        type: 'number',
        description: 'Maximum height in pixels (1-4800)',
        minimum: 1,
        maximum: 4800,
      },
      skipHttpRedirect: {
        type: 'boolean',
        description: 'Return photo data directly instead of redirect URL',
        default: false,
      },
    },
    required: ['photoName'],
  },
};

// Input validation schema
const PlacePhotoInputSchema = z.object({
  photoName: z.string().min(1),
  maxWidthPx: z.number().min(1).max(4800).optional(),
  maxHeightPx: z.number().min(1).max(4800).optional(),
  skipHttpRedirect: z.boolean().optional().default(false),
});

export type PlacePhotoInput = z.infer<typeof PlacePhotoInputSchema>;

/**
 * Execute place photo request
 */
export async function executePlacePhoto(
  input: PlacePhotoInput,
  apiClient: GooglePlacesAPIClient
): Promise<MCPToolResponse> {
  try {
    // Validate input
    const validatedInput = PlacePhotoInputSchema.parse(input);
    
    // Make API request
    const response = await apiClient.getPlacePhoto({
      photoName: validatedInput.photoName,
      maxWidthPx: validatedInput.maxWidthPx,
      maxHeightPx: validatedInput.maxHeightPx,
      skipHttpRedirect: validatedInput.skipHttpRedirect,
    });
    
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(response, null, 2),
        },
      ],
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ error: errorMessage }, null, 2),
        },
      ],
      isError: true,
    };
  }
}

/**
 * Extract photo name from place details response
 */
export function extractPhotoName(photo: { name?: string }): string | undefined {
  return photo?.name;
}

/**
 * Build photo URL from photo name (for direct access)
 */
export function buildPhotoUrl(
  photoName: string,
  apiKey: string,
  options?: { maxWidthPx?: number; maxHeightPx?: number }
): string {
  const baseUrl = `https://places.googleapis.com/v1/${photoName}/media`;
  const params = new URLSearchParams();
  
  params.append('key', apiKey);
  
  if (options?.maxWidthPx) {
    params.append('maxWidthPx', options.maxWidthPx.toString());
  }
  if (options?.maxHeightPx) {
    params.append('maxHeightPx', options.maxHeightPx.toString());
  }
  
  return `${baseUrl}?${params.toString()}`;
}

export default {
  tool: placePhotosTool,
  execute: executePlacePhoto,
  extractPhotoName,
  buildPhotoUrl,
};
