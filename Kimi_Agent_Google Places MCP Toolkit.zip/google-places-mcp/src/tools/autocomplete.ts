/**
 * Autocomplete Tool
 * MCP tool for getting place predictions as user types
 */

import { z } from 'zod';
import { GooglePlacesAPIClient } from '../utils/api-client.js';
import { MCPTool, MCPToolResponse } from '../types/index.js';

// Tool definition
export const autocompleteTool: MCPTool = {
  name: 'google_places_autocomplete',
  description: `Get place predictions and query suggestions as the user types. 
Returns matching places and suggested search queries based on partial input.

Use Cases:
- Search box type-ahead suggestions
- Address autocomplete
- Business name lookup
- Query suggestion

Session Tokens:
- Use session tokens to group autocomplete requests for billing optimization
- Generate a unique token when user starts typing
- Use same token for subsequent requests in the same session
- Include token in final Place Details call

Cost Optimization Tips:
- Always use session tokens for production
- Set appropriate location bias/restriction
- Use 'includeQueryPredictions' only when needed`,
  inputSchema: {
    type: 'object',
    properties: {
      input: {
        type: 'string',
        description: 'Partial text input from user (e.g., "pizza", "1600 Amphithea")',
      },
      sessionToken: {
        type: 'string',
        description: 'Session token for billing optimization (generate once per user session)',
      },
      fields: {
        type: 'array',
        items: { type: 'string' },
        description: 'Specific fields to return for predictions',
      },
      includedPrimaryTypes: {
        type: 'array',
        items: { type: 'string' },
        description: 'Restrict to specific primary types (max 5, e.g., ["restaurant", "cafe"])',
      },
      includePureServiceAreaBusinesses: {
        type: 'boolean',
        description: 'Include businesses without physical locations (service area businesses)',
        default: false,
      },
      includeQueryPredictions: {
        type: 'boolean',
        description: 'Include query predictions in addition to place predictions',
        default: false,
      },
      includedRegionCodes: {
        type: 'array',
        items: { type: 'string' },
        description: 'Restrict to specific countries (max 15, e.g., ["us", "ca", "gb"])',
      },
      inputOffset: {
        type: 'number',
        description: 'Cursor position in input string (0-based, defaults to end)',
      },
      languageCode: {
        type: 'string',
        description: 'Preferred language for results (e.g., en, es, fr)',
      },
      locationBias: {
        type: 'object',
        description: 'Bias results toward a location (results may be outside area)',
        properties: {
          circle: {
            type: 'object',
            properties: {
              center: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              radius: { type: 'number', description: 'Radius in meters (max 50000)' },
            },
            required: ['center', 'radius'],
          },
          rectangle: {
            type: 'object',
            properties: {
              low: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              high: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
            },
            required: ['low', 'high'],
          },
        },
      },
      locationRestriction: {
        type: 'object',
        description: 'Restrict results to within area (results outside are excluded)',
        properties: {
          circle: {
            type: 'object',
            properties: {
              center: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              radius: { type: 'number', description: 'Radius in meters (max 50000)' },
            },
            required: ['center', 'radius'],
          },
          rectangle: {
            type: 'object',
            properties: {
              low: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              high: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
            },
            required: ['low', 'high'],
          },
        },
      },
      origin: {
        type: 'object',
        description: 'Origin point for calculating distance to predictions',
        properties: {
          latitude: { type: 'number' },
          longitude: { type: 'number' },
        },
        required: ['latitude', 'longitude'],
      },
      regionCode: {
        type: 'string',
        description: 'Region code for formatting and biasing (e.g., us, gb, ca)',
      },
    },
    required: ['input'],
  },
};

// Input validation schema
const AutocompleteInputSchema = z.object({
  input: z.string().min(1),
  sessionToken: z.string().optional(),
  fields: z.array(z.string()).optional(),
  includedPrimaryTypes: z.array(z.string()).max(5).optional(),
  includePureServiceAreaBusinesses: z.boolean().optional().default(false),
  includeQueryPredictions: z.boolean().optional().default(false),
  includedRegionCodes: z.array(z.string()).max(15).optional(),
  inputOffset: z.number().optional(),
  languageCode: z.string().optional(),
  locationBias: z.object({
    circle: z.object({
      center: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
      radius: z.number().min(0).max(50000),
    }).optional(),
    rectangle: z.object({
      low: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
      high: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
    }).optional(),
  }).optional(),
  locationRestriction: z.object({
    circle: z.object({
      center: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
      radius: z.number().min(0).max(50000),
    }).optional(),
    rectangle: z.object({
      low: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
      high: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
    }).optional(),
  }).optional(),
  origin: z.object({
    latitude: z.number(),
    longitude: z.number(),
  }).optional(),
  regionCode: z.string().optional(),
});

export type AutocompleteInput = z.infer<typeof AutocompleteInputSchema>;

/**
 * Execute autocomplete request
 */
export async function executeAutocomplete(
  input: AutocompleteInput,
  apiClient: GooglePlacesAPIClient
): Promise<MCPToolResponse> {
  try {
    // Validate input
    const validatedInput = AutocompleteInputSchema.parse(input);
    
    // Make API request
    const response = await apiClient.autocomplete({
      input: validatedInput.input,
      sessionToken: validatedInput.sessionToken,
      fields: validatedInput.fields,
      includedPrimaryTypes: validatedInput.includedPrimaryTypes,
      includePureServiceAreaBusinesses: validatedInput.includePureServiceAreaBusinesses,
      includeQueryPredictions: validatedInput.includeQueryPredictions,
      includedRegionCodes: validatedInput.includedRegionCodes,
      inputOffset: validatedInput.inputOffset,
      languageCode: validatedInput.languageCode,
      locationBias: validatedInput.locationBias,
      locationRestriction: validatedInput.locationRestriction,
      origin: validatedInput.origin,
      regionCode: validatedInput.regionCode,
    });
    
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(response, null, 2),
        },
      ],
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ error: errorMessage }, null, 2),
        },
      ],
      isError: true,
    };
  }
}

/**
 * Generate a session token for autocomplete sessions
 * Use this to group related autocomplete requests for billing
 */
export function generateSessionToken(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}

export default {
  tool: autocompleteTool,
  execute: executeAutocomplete,
  generateSessionToken,
};
