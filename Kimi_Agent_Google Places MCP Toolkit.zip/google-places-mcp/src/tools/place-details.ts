/**
 * Place Details Tool
 * MCP tool for retrieving comprehensive place information
 */

import { z } from 'zod';
import { GooglePlacesAPIClient } from '../utils/api-client.js';
import { getFieldMask } from '../utils/field-masks.js';
import { transformToBusinessProfile } from '../utils/business-intelligence.js';
import { MCPTool, MCPToolResponse } from '../types/index.js';

// Tool definition
export const placeDetailsTool: MCPTool = {
  name: 'google_places_get_details',
  description: `Retrieve comprehensive details about a specific place using its Place ID. 
Returns business information including address, phone, hours, ratings, reviews, photos, 
and AI-powered summaries. Use this when you have a Place ID and need detailed information.

Cost Optimization Tips:
- Use 'fields' parameter to request only needed data
- Default fields: id, displayName, formattedAddress
- Use field presets: 'basic', 'contact', 'ratings', 'hours', 'photos', 'reviews', 'ai_summary', 'complete'`,
  inputSchema: {
    type: 'object',
    properties: {
      placeId: {
        type: 'string',
        description: 'The unique Place ID from Google Places (e.g., ChIJj61dQgK6j4AR4GeTYWZsKWw)',
      },
      fields: {
        type: 'array',
        items: { type: 'string' },
        description: 'Specific fields to return. Use field presets or custom field list.',
      },
      fieldPreset: {
        type: 'string',
        enum: ['minimal', 'basic', 'contact', 'ratings', 'hours', 'photos', 'reviews', 'ai_summary', 'complete'],
        description: 'Predefined field set for common use cases',
      },
      languageCode: {
        type: 'string',
        description: 'Preferred language for results (e.g., en, es, fr)',
      },
      regionCode: {
        type: 'string',
        description: 'Region code for formatting (e.g., US, GB, CA)',
      },
      includeBusinessProfile: {
        type: 'boolean',
        description: 'Transform response into structured business profile with industry analysis',
        default: false,
      },
    },
    required: ['placeId'],
  },
};

// Input validation schema
const PlaceDetailsInputSchema = z.object({
  placeId: z.string().min(1),
  fields: z.array(z.string()).optional(),
  fieldPreset: z.enum(['minimal', 'basic', 'contact', 'ratings', 'hours', 'photos', 'reviews', 'ai_summary', 'complete']).optional(),
  languageCode: z.string().optional(),
  regionCode: z.string().optional(),
  includeBusinessProfile: z.boolean().optional().default(false),
});

export type PlaceDetailsInput = z.infer<typeof PlaceDetailsInputSchema>;

/**
 * Execute place details request
 */
export async function executePlaceDetails(
  input: PlaceDetailsInput,
  apiClient: GooglePlacesAPIClient
): Promise<MCPToolResponse> {
  try {
    // Validate input
    const validatedInput = PlaceDetailsInputSchema.parse(input);
    
    // Determine fields to request
    let fields: string[];
    if (validatedInput.fields) {
      fields = validatedInput.fields;
    } else if (validatedInput.fieldPreset) {
      fields = getFieldMask(validatedInput.fieldPreset);
    } else {
      fields = getFieldMask('basic');
    }
    
    // Make API request
    const place = await apiClient.getPlaceDetails({
      placeId: validatedInput.placeId,
      fields,
      languageCode: validatedInput.languageCode,
      regionCode: validatedInput.regionCode,
    });
    
    // Transform to business profile if requested
    let responseData: any = place;
    if (validatedInput.includeBusinessProfile) {
      responseData = transformToBusinessProfile(place);
    }
    
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(responseData, null, 2),
        },
      ],
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ error: errorMessage }, null, 2),
        },
      ],
      isError: true,
    };
  }
}

export default {
  tool: placeDetailsTool,
  execute: executePlaceDetails,
};
