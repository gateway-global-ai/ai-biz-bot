/**
 * MCP Tools Index
 * Export all Google Places MCP tools
 */

export { placeDetailsTool, executePlaceDetails } from './place-details.js';
export { textSearchTool, executeTextSearch } from './text-search.js';
export { nearbySearchTool, executeNearbySearch } from './nearby-search.js';
export { autocompleteTool, executeAutocomplete, generateSessionToken } from './autocomplete.js';
export { placePhotosTool, executePlacePhoto } from './place-photos.js';
export { businessIntelligenceTool, executeBusinessIntelligence } from './business-intelligence.js';

import { placeDetailsTool } from './place-details.js';
import { textSearchTool } from './text-search.js';
import { nearbySearchTool } from './nearby-search.js';
import { autocompleteTool } from './autocomplete.js';
import { placePhotosTool } from './place-photos.js';
import { businessIntelligenceTool } from './business-intelligence.js';

/**
 * All available MCP tools
 */
export const allTools = [
  placeDetailsTool,
  textSearchTool,
  nearbySearchTool,
  autocompleteTool,
  placePhotosTool,
  businessIntelligenceTool,
];

export default allTools;
