/**
 * Nearby Search Tool
 * MCP tool for searching places near a specific location
 */

import { z } from 'zod';
import { GooglePlacesAPIClient } from '../utils/api-client.js';
import { getFieldMask } from '../utils/field-masks.js';
import { transformToBusinessProfile } from '../utils/business-intelligence.js';
import { MCPTool, MCPToolResponse } from '../types/index.js';

// Tool definition
export const nearbySearchTool: MCPTool = {
  name: 'google_places_nearby_search',
  description: `Search for places near a specific geographic location. Returns businesses 
and points of interest within a specified radius or rectangular area.

Use Cases:
- Finding businesses "near me" or near a specific address
- Discovering amenities around a property or location
- Competitive analysis in a specific area
- Building local business directories

Cost Optimization Tips:
- Use 'fields' parameter to request only needed data
- Set 'maxResultCount' to limit results (default: 20)
- Use 'rankPreference' to optimize for popularity or distance
- Use 'fieldPreset' for common field combinations`,
  inputSchema: {
    type: 'object',
    properties: {
      locationRestriction: {
        type: 'object',
        description: 'Required. Define search area as circle or rectangle',
        properties: {
          circle: {
            type: 'object',
            description: 'Circular search area',
            properties: {
              center: {
                type: 'object',
                properties: {
                  latitude: { type: 'number', description: 'Latitude (-90 to 90)' },
                  longitude: { type: 'number', description: 'Longitude (-180 to 180)' },
                },
                required: ['latitude', 'longitude'],
              },
              radius: { 
                type: 'number', 
                description: 'Radius in meters (0 to 50000)',
                minimum: 0,
                maximum: 50000,
              },
            },
            required: ['center', 'radius'],
          },
          rectangle: {
            type: 'object',
            description: 'Rectangular search area (viewport)',
            properties: {
              low: {
                type: 'object',
                description: 'Southwest corner',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              high: {
                type: 'object',
                description: 'Northeast corner',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
            },
            required: ['low', 'high'],
          },
        },
      },
      fields: {
        type: 'array',
        items: { type: 'string' },
        description: 'Specific fields to return for each place',
      },
      fieldPreset: {
        type: 'string',
        enum: ['minimal', 'basic', 'contact', 'ratings', 'hours', 'photos', 'reviews', 'ai_summary', 'complete'],
        description: 'Predefined field set for common use cases',
      },
      languageCode: {
        type: 'string',
        description: 'Preferred language for results (e.g., en, es, fr)',
      },
      regionCode: {
        type: 'string',
        description: 'Region code for formatting (e.g., US, GB, CA)',
      },
      includedTypes: {
        type: 'array',
        items: { type: 'string' },
        description: 'Include only places of these types (e.g., ["restaurant", "cafe"])',
      },
      excludedTypes: {
        type: 'array',
        items: { type: 'string' },
        description: 'Exclude places of these types',
      },
      includedPrimaryTypes: {
        type: 'array',
        items: { type: 'string' },
        description: 'Include only places with these primary types (max 50)',
      },
      excludedPrimaryTypes: {
        type: 'array',
        items: { type: 'string' },
        description: 'Exclude places with these primary types',
      },
      maxResultCount: {
        type: 'number',
        description: 'Maximum number of results (1-20)',
        minimum: 1,
        maximum: 20,
      },
      rankPreference: {
        type: 'string',
        enum: ['POPULARITY', 'DISTANCE'],
        description: 'How to rank results: by popularity or distance from center',
      },
      openNow: {
        type: 'boolean',
        description: 'Only return places that are currently open',
      },
      minRating: {
        type: 'number',
        description: 'Minimum rating (0.0 to 5.0)',
        minimum: 0,
        maximum: 5,
      },
      pageToken: {
        type: 'string',
        description: 'Token for retrieving next page of results',
      },
      includeBusinessProfiles: {
        type: 'boolean',
        description: 'Transform results into structured business profiles with industry analysis',
        default: false,
      },
    },
    required: ['locationRestriction'],
  },
};

// Input validation schema
const NearbySearchInputSchema = z.object({
  locationRestriction: z.object({
    circle: z.object({
      center: z.object({
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
      }),
      radius: z.number().min(0).max(50000),
    }).optional(),
    rectangle: z.object({
      low: z.object({
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
      }),
      high: z.object({
        latitude: z.number().min(-90).max(90),
        longitude: z.number().min(-180).max(180),
      }),
    }).optional(),
  }).refine(data => data.circle || data.rectangle, {
    message: 'Either circle or rectangle must be specified',
  }),
  fields: z.array(z.string()).optional(),
  fieldPreset: z.enum(['minimal', 'basic', 'contact', 'ratings', 'hours', 'photos', 'reviews', 'ai_summary', 'complete']).optional(),
  languageCode: z.string().optional(),
  regionCode: z.string().optional(),
  includedTypes: z.array(z.string()).optional(),
  excludedTypes: z.array(z.string()).optional(),
  includedPrimaryTypes: z.array(z.string()).max(50).optional(),
  excludedPrimaryTypes: z.array(z.string()).optional(),
  maxResultCount: z.number().min(1).max(20).optional(),
  rankPreference: z.enum(['POPULARITY', 'DISTANCE']).optional(),
  openNow: z.boolean().optional(),
  minRating: z.number().min(0).max(5).optional(),
  pageToken: z.string().optional(),
  includeBusinessProfiles: z.boolean().optional().default(false),
});

export type NearbySearchInput = z.infer<typeof NearbySearchInputSchema>;

/**
 * Execute nearby search request
 */
export async function executeNearbySearch(
  input: NearbySearchInput,
  apiClient: GooglePlacesAPIClient
): Promise<MCPToolResponse> {
  try {
    // Validate input
    const validatedInput = NearbySearchInputSchema.parse(input);
    
    // Determine fields to request
    let fields: string[];
    if (validatedInput.fields) {
      fields = validatedInput.fields;
    } else if (validatedInput.fieldPreset) {
      fields = getFieldMask(validatedInput.fieldPreset);
    } else {
      fields = getFieldMask('basic');
    }
    
    // Make API request
    const response = await apiClient.nearbySearch({
      locationRestriction: validatedInput.locationRestriction,
      fields,
      languageCode: validatedInput.languageCode,
      regionCode: validatedInput.regionCode,
      includedTypes: validatedInput.includedTypes,
      excludedTypes: validatedInput.excludedTypes,
      includedPrimaryTypes: validatedInput.includedPrimaryTypes,
      excludedPrimaryTypes: validatedInput.excludedPrimaryTypes,
      maxResultCount: validatedInput.maxResultCount,
      rankPreference: validatedInput.rankPreference,
      openNow: validatedInput.openNow,
      minRating: validatedInput.minRating,
      pageToken: validatedInput.pageToken,
    });
    
    // Transform to business profiles if requested
    let responseData: any = response;
    if (validatedInput.includeBusinessProfiles && response.places) {
      responseData = {
        ...response,
        places: response.places.map(transformToBusinessProfile),
      };
    }
    
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(responseData, null, 2),
        },
      ],
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ error: errorMessage }, null, 2),
        },
      ],
      isError: true,
    };
  }
}

export default {
  tool: nearbySearchTool,
  execute: executeNearbySearch,
};
