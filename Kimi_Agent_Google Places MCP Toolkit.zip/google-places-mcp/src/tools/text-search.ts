/**
 * Text Search Tool
 * MCP tool for searching places using text queries
 */

import { z } from 'zod';
import { GooglePlacesAPIClient } from '../utils/api-client.js';
import { getFieldMask } from '../utils/field-masks.js';
import { transformToBusinessProfile } from '../utils/business-intelligence.js';
import { MCPTool, MCPToolResponse } from '../types/index.js';

// Tool definition
export const textSearchTool: MCPTool = {
  name: 'google_places_text_search',
  description: `Search for places using a text query. Supports natural language queries like 
"pizza restaurants in New York" or "gas stations near me". Returns matching places with 
detailed information.

Use Cases:
- Finding businesses by name, type, or description
- Location-aware searches with geographic bias
- Filtering by ratings, price level, and open status
- Pagination for large result sets

Cost Optimization Tips:
- Use 'fields' parameter to request only needed data
- Set 'maxResultCount' to limit results (default: 20)
- Use 'fieldPreset' for common field combinations`,
  inputSchema: {
    type: 'object',
    properties: {
      textQuery: {
        type: 'string',
        description: 'Search query text (e.g., "pizza restaurants in Manhattan", "Starbucks near Central Park")',
      },
      fields: {
        type: 'array',
        items: { type: 'string' },
        description: 'Specific fields to return for each place',
      },
      fieldPreset: {
        type: 'string',
        enum: ['minimal', 'basic', 'contact', 'ratings', 'hours', 'photos', 'reviews', 'ai_summary', 'complete'],
        description: 'Predefined field set for common use cases',
      },
      languageCode: {
        type: 'string',
        description: 'Preferred language for results (e.g., en, es, fr)',
      },
      regionCode: {
        type: 'string',
        description: 'Region code for formatting (e.g., US, GB, CA)',
      },
      locationBias: {
        type: 'object',
        description: 'Bias results toward a specific location (circle or rectangle)',
        properties: {
          circle: {
            type: 'object',
            properties: {
              center: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              radius: { type: 'number', description: 'Radius in meters (max 50000)' },
            },
            required: ['center', 'radius'],
          },
          rectangle: {
            type: 'object',
            properties: {
              low: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              high: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
            },
            required: ['low', 'high'],
          },
        },
      },
      locationRestriction: {
        type: 'object',
        description: 'Restrict results to within a specific area (circle or rectangle)',
        properties: {
          circle: {
            type: 'object',
            properties: {
              center: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              radius: { type: 'number', description: 'Radius in meters (max 50000)' },
            },
            required: ['center', 'radius'],
          },
          rectangle: {
            type: 'object',
            properties: {
              low: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
              high: {
                type: 'object',
                properties: {
                  latitude: { type: 'number' },
                  longitude: { type: 'number' },
                },
                required: ['latitude', 'longitude'],
              },
            },
            required: ['low', 'high'],
          },
        },
      },
      includedType: {
        type: 'string',
        description: 'Filter to specific place type (e.g., restaurant, cafe, store)',
      },
      openNow: {
        type: 'boolean',
        description: 'Only return places that are currently open',
      },
      minRating: {
        type: 'number',
        description: 'Minimum rating (0.0 to 5.0)',
        minimum: 0,
        maximum: 5,
      },
      maxResultCount: {
        type: 'number',
        description: 'Maximum number of results (1-20)',
        minimum: 1,
        maximum: 20,
      },
      priceLevels: {
        type: 'array',
        items: {
          type: 'string',
          enum: ['PRICE_LEVEL_FREE', 'PRICE_LEVEL_INEXPENSIVE', 'PRICE_LEVEL_MODERATE', 'PRICE_LEVEL_EXPENSIVE', 'PRICE_LEVEL_VERY_EXPENSIVE'],
        },
        description: 'Filter by price levels',
      },
      pageToken: {
        type: 'string',
        description: 'Token for retrieving next page of results',
      },
      includeBusinessProfiles: {
        type: 'boolean',
        description: 'Transform results into structured business profiles with industry analysis',
        default: false,
      },
    },
    required: ['textQuery'],
  },
};

// Input validation schema
const TextSearchInputSchema = z.object({
  textQuery: z.string().min(1),
  fields: z.array(z.string()).optional(),
  fieldPreset: z.enum(['minimal', 'basic', 'contact', 'ratings', 'hours', 'photos', 'reviews', 'ai_summary', 'complete']).optional(),
  languageCode: z.string().optional(),
  regionCode: z.string().optional(),
  locationBias: z.object({
    circle: z.object({
      center: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
      radius: z.number().min(0).max(50000),
    }).optional(),
    rectangle: z.object({
      low: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
      high: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
    }).optional(),
  }).optional(),
  locationRestriction: z.object({
    circle: z.object({
      center: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
      radius: z.number().min(0).max(50000),
    }).optional(),
    rectangle: z.object({
      low: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
      high: z.object({
        latitude: z.number(),
        longitude: z.number(),
      }),
    }).optional(),
  }).optional(),
  includedType: z.string().optional(),
  openNow: z.boolean().optional(),
  minRating: z.number().min(0).max(5).optional(),
  maxResultCount: z.number().min(1).max(20).optional(),
  priceLevels: z.array(z.enum(['PRICE_LEVEL_FREE', 'PRICE_LEVEL_INEXPENSIVE', 'PRICE_LEVEL_MODERATE', 'PRICE_LEVEL_EXPENSIVE', 'PRICE_LEVEL_VERY_EXPENSIVE'])).optional(),
  pageToken: z.string().optional(),
  includeBusinessProfiles: z.boolean().optional().default(false),
});

export type TextSearchInput = z.infer<typeof TextSearchInputSchema>;

/**
 * Execute text search request
 */
export async function executeTextSearch(
  input: TextSearchInput,
  apiClient: GooglePlacesAPIClient
): Promise<MCPToolResponse> {
  try {
    // Validate input
    const validatedInput = TextSearchInputSchema.parse(input);
    
    // Determine fields to request
    let fields: string[];
    if (validatedInput.fields) {
      fields = validatedInput.fields;
    } else if (validatedInput.fieldPreset) {
      fields = getFieldMask(validatedInput.fieldPreset);
    } else {
      fields = getFieldMask('basic');
    }
    
    // Make API request
    const response = await apiClient.textSearch({
      textQuery: validatedInput.textQuery,
      fields,
      languageCode: validatedInput.languageCode,
      regionCode: validatedInput.regionCode,
      locationBias: validatedInput.locationBias,
      locationRestriction: validatedInput.locationRestriction,
      includedType: validatedInput.includedType,
      openNow: validatedInput.openNow,
      minRating: validatedInput.minRating,
      maxResultCount: validatedInput.maxResultCount,
      priceLevels: validatedInput.priceLevels,
      pageToken: validatedInput.pageToken,
    });
    
    // Transform to business profiles if requested
    let responseData: any = response;
    if (validatedInput.includeBusinessProfiles && response.places) {
      responseData = {
        ...response,
        places: response.places.map(transformToBusinessProfile),
      };
    }
    
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(responseData, null, 2),
        },
      ],
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ error: errorMessage }, null, 2),
        },
      ],
      isError: true,
    };
  }
}

export default {
  tool: textSearchTool,
  execute: executeTextSearch,
};
