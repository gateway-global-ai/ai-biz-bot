/**
 * Business Intelligence Tool
 * MCP tool for comprehensive business analysis using Google Places data
 */

import { z } from 'zod';
import { GooglePlacesAPIClient } from '../utils/api-client.js';
import { 
  transformToBusinessProfile, 
  performCompetitiveAnalysis,
  generateRecommendations,
  analyzeReviews,
  determineIndustry,
} from '../utils/business-intelligence.js';
import { getFieldMask } from '../utils/field-masks.js';
import { MCPTool, MCPToolResponse } from '../types/index.js';

// Tool definition
export const businessIntelligenceTool: MCPTool = {
  name: 'google_places_business_intelligence',
  description: `Perform comprehensive business intelligence analysis using Google Places data.
Retrieves detailed business information, analyzes reviews, identifies industry pain points,
and generates actionable recommendations.

Analysis Includes:
- Complete business profile with industry classification
- AI-generated business summaries (Gemini-powered)
- Review sentiment analysis and theme extraction
- Industry-specific pain points identification
- Competitive positioning insights
- Personalized business recommendations

Use Cases:
- Business onboarding and profiling
- Competitive analysis
- Market research
- Voice AI workflow generation
- Customer pain point identification

Note: This tool makes multiple API calls. Use judiciously to manage costs.`,
  inputSchema: {
    type: 'object',
    properties: {
      placeId: {
        type: 'string',
        description: 'Google Place ID of the business to analyze',
      },
      includeCompetitors: {
        type: 'boolean',
        description: 'Include nearby competitor analysis',
        default: false,
      },
      competitorSearchRadius: {
        type: 'number',
        description: 'Radius in meters for competitor search (default: 1000)',
        default: 1000,
      },
      maxCompetitors: {
        type: 'number',
        description: 'Maximum number of competitors to analyze (default: 5)',
        default: 5,
      },
      languageCode: {
        type: 'string',
        description: 'Preferred language for results (e.g., en, es, fr)',
      },
    },
    required: ['placeId'],
  },
};

// Input validation schema
const BusinessIntelligenceInputSchema = z.object({
  placeId: z.string().min(1),
  includeCompetitors: z.boolean().optional().default(false),
  competitorSearchRadius: z.number().min(100).max(50000).optional().default(1000),
  maxCompetitors: z.number().min(1).max(20).optional().default(5),
  languageCode: z.string().optional(),
});

export type BusinessIntelligenceInput = z.infer<typeof BusinessIntelligenceInputSchema>;

/**
 * Execute business intelligence analysis
 */
export async function executeBusinessIntelligence(
  input: BusinessIntelligenceInput,
  apiClient: GooglePlacesAPIClient
): Promise<MCPToolResponse> {
  try {
    // Validate input
    const validatedInput = BusinessIntelligenceInputSchema.parse(input);
    
    // Step 1: Get detailed place information
    const businessFields = getFieldMask('business_intelligence');
    const place = await apiClient.getPlaceDetails({
      placeId: validatedInput.placeId,
      fields: businessFields,
      languageCode: validatedInput.languageCode,
    });
    
    // Step 2: Transform to business profile
    const businessProfile = transformToBusinessProfile(place);
    
    // Step 3: Analyze reviews if available
    const reviewAnalysis = place.reviews 
      ? analyzeReviews(place.reviews)
      : undefined;
    
    // Step 4: Generate recommendations
    const recommendations = generateRecommendations(businessProfile);
    
    // Step 5: Competitor analysis if requested
    let competitiveAnalysis = undefined;
    if (validatedInput.includeCompetitors && place.location) {
      const competitorFields = getFieldMask('ratings');
      const nearbyResponse = await apiClient.nearbySearch({
        locationRestriction: {
          circle: {
            center: place.location,
            radius: validatedInput.competitorSearchRadius,
          },
        },
        fields: competitorFields,
        includedPrimaryTypes: place.primaryType ? [place.primaryType] : undefined,
        maxResultCount: validatedInput.maxCompetitors + 1, // +1 to include target business
      });
      
      // Filter out the target business and limit competitors
      const competitors = nearbyResponse.places
        ?.filter(p => p.id !== place.id)
        .slice(0, validatedInput.maxCompetitors) || [];
      
      competitiveAnalysis = performCompetitiveAnalysis(businessProfile, competitors);
    }
    
    // Compile comprehensive analysis
    const analysis = {
      businessProfile,
      reviewAnalysis,
      recommendations,
      competitiveAnalysis,
      metadata: {
        analyzedAt: new Date().toISOString(),
        dataSource: 'Google Places API (New)',
        includesAiSummaries: !!place.generativeSummary || !!place.reviewSummary,
      },
    };
    
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(analysis, null, 2),
        },
      ],
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ error: errorMessage }, null, 2),
        },
      ],
      isError: true,
    };
  }
}

export default {
  tool: businessIntelligenceTool,
  execute: executeBusinessIntelligence,
};
