#!/usr/bin/env node
/**
 * Google Places MCP Server
 * Model Context Protocol server for Google Places APIs
 * 
 * This server provides AI agents with comprehensive access to Google Places data
 * through standardized MCP tool interfaces.
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from '@modelcontextprotocol/sdk/types.js';
import { GooglePlacesAPIClient } from './utils/api-client.js';
import {
  executePlaceDetails,
  executeTextSearch,
  executeNearbySearch,
  executeAutocomplete,
  executePlacePhoto,
  executeBusinessIntelligence,
  allTools,
} from './tools/index.js';

// Server configuration
const SERVER_NAME = 'google-places-mcp';
const SERVER_VERSION = '1.0.0';

/**
 * Get API key from environment
 */
function getApiKey(): string {
  const apiKey = process.env.GOOGLE_PLACES_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GOOGLE_PLACES_API_KEY environment variable is required. ' +
      'Please set your Google Places API key.'
    );
  }
  return apiKey;
}

/**
 * Create and configure the MCP server
 */
async function main() {
  // Initialize API client
  const apiKey = getApiKey();
  const apiClient = new GooglePlacesAPIClient({
    apiKey,
    timeout: parseInt(process.env.GOOGLE_PLACES_TIMEOUT || '30000'),
    retries: parseInt(process.env.GOOGLE_PLACES_RETRIES || '3'),
  });

  // Create MCP server
  const server = new Server(
    {
      name: SERVER_NAME,
      version: SERVER_VERSION,
    },
    {
      capabilities: {
        tools: {},
      },
    }
  );

  // Register tool list handler
  server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
      tools: allTools as Tool[],
    };
  });

  // Register tool call handler
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;

    try {
      switch (name) {
        case 'google_places_get_details':
          return await executePlaceDetails(args as any, apiClient);

        case 'google_places_text_search':
          return await executeTextSearch(args as any, apiClient);

        case 'google_places_nearby_search':
          return await executeNearbySearch(args as any, apiClient);

        case 'google_places_autocomplete':
          return await executeAutocomplete(args as any, apiClient);

        case 'google_places_get_photo':
          return await executePlacePhoto(args as any, apiClient);

        case 'google_places_business_intelligence':
          return await executeBusinessIntelligence(args as any, apiClient);

        default:
          return {
            content: [
              {
                type: 'text',
                text: JSON.stringify({ error: `Unknown tool: ${name}` }, null, 2),
              },
            ],
            isError: true,
          };
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({ error: errorMessage }, null, 2),
          },
        ],
        isError: true,
      };
    }
  });

  // Start server with stdio transport
  const transport = new StdioServerTransport();
  
  console.error('Google Places MCP Server starting...');
  console.error(`Server: ${SERVER_NAME} v${SERVER_VERSION}`);
  console.error(`Tools available: ${allTools.length}`);
  
  await server.connect(transport);
  
  console.error('Google Places MCP Server running on stdio');
}

// Run the server
main().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});

export { GooglePlacesAPIClient };
export * from './types/index.js';
export * from './utils/index.js';
export * from './tools/index.js';
