/**
 * Competitive Analysis Example
 * Demonstrates how to analyze competitors in a specific area
 */

import { GooglePlacesSDK } from '../sdk/typescript/src/index.js';

const sdk = new GooglePlacesSDK({
  serverPath: './dist/index.js',
});

interface CompetitorAnalysis {
  name: string;
  rating: number;
  reviewCount: number;
  distance: number;
  strengths: string[];
  weaknesses: string[];
}

/**
 * Analyze competitors for a business
 */
async function analyzeCompetitors(
  businessType: string,
  location: { latitude: number; longitude: number },
  radius: number = 1000
) {
  console.log(`\n🏆 Competitive Analysis: ${businessType}`);
  console.log('=' .repeat(60));
  console.log(`Location: ${location.latitude}, ${location.longitude}`);
  console.log(`Search Radius: ${radius}m\n`);

  try {
    // Step 1: Search for competitors
    console.log('🔍 Searching for competitors...');
    const searchResults = await sdk.nearbySearch({
      locationRestriction: {
        circle: {
          center: location,
          radius,
        },
      },
      includedPrimaryTypes: [businessType],
      maxResultCount: 20,
      rankPreference: 'POPULARITY',
      fieldPreset: 'ratings',
    });

    const competitors = searchResults.places || [];
    console.log(`Found ${competitors.length} competitors\n`);

    if (competitors.length === 0) {
      console.log('No competitors found in the specified area.');
      return;
    }

    // Step 2: Analyze each competitor
    console.log('📊 Competitor Analysis');
    console.log('----------------------');

    const analysisResults: CompetitorAnalysis[] = [];

    for (let i = 0; i < Math.min(competitors.length, 10); i++) {
      const competitor = competitors[i];
      
      // Get detailed information
      const details = await sdk.getPlaceDetails({
        placeId: competitor.id,
        fieldPreset: 'complete',
      });

      const analysis: CompetitorAnalysis = {
        name: details.displayName?.text || 'Unknown',
        rating: details.rating || 0,
        reviewCount: details.userRatingCount || 0,
        distance: 0, // Would need to calculate from location
        strengths: [],
        weaknesses: [],
      };

      // Analyze strengths
      if (details.rating && details.rating >= 4.5) {
        analysis.strengths.push('High customer rating');
      }
      if (details.userRatingCount && details.userRatingCount > 1000) {
        analysis.strengths.push('Large customer base');
      }
      if (details.regularOpeningHours?.openNow) {
        analysis.strengths.push('Currently open');
      }
      if (details.photos && details.photos.length > 5) {
        analysis.strengths.push('Good visual presence');
      }

      // Analyze weaknesses
      if (details.rating && details.rating < 4.0) {
        analysis.weaknesses.push('Lower customer rating');
      }
      if (details.userRatingCount && details.userRatingCount < 50) {
        analysis.weaknesses.push('Limited review presence');
      }
      if (details.businessStatus === 'CLOSED_TEMPORARILY') {
        analysis.weaknesses.push('Temporarily closed');
      }

      analysisResults.push(analysis);

      // Display analysis
      console.log(`\n${i + 1}. ${analysis.name}`);
      console.log(`   Rating: ${'⭐'.repeat(Math.round(analysis.rating))} (${analysis.rating})`);
      console.log(`   Reviews: ${analysis.reviewCount}`);
      console.log(`   Price Level: ${details.priceLevel || 'N/A'}`);
      
      if (analysis.strengths.length > 0) {
        console.log(`   Strengths: ${analysis.strengths.join(', ')}`);
      }
      if (analysis.weaknesses.length > 0) {
        console.log(`   Weaknesses: ${analysis.weaknesses.join(', ')}`);
      }
    }

    // Step 3: Market Summary
    console.log('\n\n📈 Market Summary');
    console.log('-----------------');
    
    const avgRating = analysisResults.reduce((sum, c) => sum + c.rating, 0) / analysisResults.length;
    const totalReviews = analysisResults.reduce((sum, c) => sum + c.reviewCount, 0);
    const highRated = analysisResults.filter(c => c.rating >= 4.5).length;
    const lowRated = analysisResults.filter(c => c.rating < 4.0).length;

    console.log(`Average Rating: ${avgRating.toFixed(2)}`);
    console.log(`Total Reviews: ${totalReviews.toLocaleString()}`);
    console.log(`High-Rated Competitors (4.5+): ${highRated}`);
    console.log(`Low-Rated Competitors (<4.0): ${lowRated}`);

    // Step 4: Opportunities
    console.log('\n💡 Market Opportunities');
    console.log('-----------------------');
    
    const opportunities: string[] = [];
    
    if (avgRating < 4.2) {
      opportunities.push('Market has room for high-quality service provider');
    }
    if (lowRated > 2) {
      opportunities.push('Several competitors have poor ratings - differentiation opportunity');
    }
    if (highRated < 3) {
      opportunities.push('Few high-rated competitors - premium positioning possible');
    }

    opportunities.forEach((opp, i) => {
      console.log(`${i + 1}. ${opp}`);
    });

    return analysisResults;

  } catch (error) {
    console.error('❌ Analysis error:', error);
    return [];
  }
}

/**
 * Run competitive analysis demo
 */
async function runCompetitiveAnalysisDemo() {
  await sdk.connect();

  // Analyze coffee shops in downtown San Francisco
  await analyzeCompetitors('cafe', {
    latitude: 37.7749,
    longitude: -122.4194,
  }, 800);

  // Analyze restaurants in Manhattan
  await analyzeCompetitors('restaurant', {
    latitude: 40.7589,
    longitude: -73.9851,
  }, 1000);

  await sdk.disconnect();
}

// Run the demo
runCompetitiveAnalysisDemo().catch(console.error);
