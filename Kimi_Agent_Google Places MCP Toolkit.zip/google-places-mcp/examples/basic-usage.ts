/**
 * Basic Usage Examples
 * Demonstrates fundamental Google Places SDK operations
 */

import { GooglePlacesSDK } from '../sdk/typescript/src/index.js';

// Initialize SDK
const sdk = new GooglePlacesSDK({
  serverPath: './dist/index.js',
});

async function basicExamples() {
  try {
    await sdk.connect();
    console.log('✅ Connected to Google Places MCP Server\n');

    // Example 1: Text Search
    console.log('🔍 Example 1: Text Search');
    console.log('---------------------------');
    const searchResults = await sdk.textSearch({
      textQuery: 'pizza restaurants in Manhattan',
      maxResultCount: 3,
      fieldPreset: 'basic',
    });
    console.log(`Found ${searchResults.places?.length || 0} places:`);
    searchResults.places?.forEach((place, i) => {
      console.log(`  ${i + 1}. ${place.displayName?.text} - ${place.formattedAddress}`);
    });
    console.log();

    // Example 2: Get Place Details
    if (searchResults.places && searchResults.places.length > 0) {
      console.log('📍 Example 2: Place Details');
      console.log('---------------------------');
      const placeId = searchResults.places[0].id;
      const details = await sdk.getPlaceDetails({
        placeId,
        fieldPreset: 'complete',
      });
      console.log(`Name: ${details.displayName?.text}`);
      console.log(`Address: ${details.formattedAddress}`);
      console.log(`Rating: ${details.rating} (${details.userRatingCount} reviews)`);
      console.log(`Phone: ${details.nationalPhoneNumber}`);
      console.log(`Website: ${details.websiteUri}`);
      console.log();
    }

    // Example 3: Nearby Search
    console.log('📍 Example 3: Nearby Search');
    console.log('---------------------------');
    const nearbyResults = await sdk.nearbySearch({
      locationRestriction: {
        circle: {
          center: {
            latitude: 40.7589,
            longitude: -73.9851,
          },
          radius: 500,
        },
      },
      includedTypes: ['cafe'],
      maxResultCount: 3,
      fieldPreset: 'basic',
    });
    console.log(`Found ${nearbyResults.places?.length || 0} cafes near Times Square:`);
    nearbyResults.places?.forEach((place, i) => {
      console.log(`  ${i + 1}. ${place.displayName?.text}`);
    });
    console.log();

    // Example 4: Autocomplete
    console.log('💡 Example 4: Autocomplete');
    console.log('---------------------------');
    const autocompleteResults = await sdk.autocomplete({
      input: 'Empire State',
      locationBias: {
        circle: {
          center: {
            latitude: 40.7128,
            longitude: -74.0060,
          },
          radius: 10000,
        },
      },
    });
    console.log(`Suggestions for "Empire State":`);
    autocompleteResults.suggestions?.forEach((suggestion, i) => {
      if (suggestion.placePrediction) {
        console.log(`  ${i + 1}. ${suggestion.placePrediction.text.text}`);
      }
    });
    console.log();

    // Example 5: Business Intelligence
    console.log('🧠 Example 5: Business Intelligence');
    console.log('-----------------------------------');
    if (searchResults.places && searchResults.places.length > 0) {
      const analysis = await sdk.businessIntelligence({
        placeId: searchResults.places[0].id,
        includeCompetitors: true,
        competitorSearchRadius: 500,
        maxCompetitors: 3,
      });
      console.log(`Business: ${analysis.businessProfile.name}`);
      console.log(`Industry: ${analysis.businessProfile.industry}`);
      console.log(`AI Summary: ${analysis.businessProfile.aiSummary?.substring(0, 100)}...`);
      console.log(`Recommendations:`);
      analysis.recommendations.forEach((rec, i) => {
        console.log(`  ${i + 1}. ${rec}`);
      });
    }

  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await sdk.disconnect();
    console.log('\n✅ Disconnected from server');
  }
}

// Run examples
basicExamples();
