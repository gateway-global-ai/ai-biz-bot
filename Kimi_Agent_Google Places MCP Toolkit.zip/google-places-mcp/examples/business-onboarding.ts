/**
 * Business Onboarding Example
 * Demonstrates how to use Google Places for automated business onboarding
 */

import { GooglePlacesSDK } from '../sdk/typescript/src/index.js';

const sdk = new GooglePlacesSDK({
  serverPath: './dist/index.js',
});

/**
 * Onboard a business by name and location
 */
async function onboardBusiness(businessName: string, location: { latitude: number; longitude: number }) {
  console.log(`\n🚀 Onboarding: ${businessName}`);
  console.log('=' .repeat(50));

  try {
    // Step 1: Search for the business
    console.log('\n📍 Step 1: Finding business...');
    const searchResult = await sdk.textSearch({
      textQuery: businessName,
      locationBias: {
        circle: {
          center: location,
          radius: 5000,
        },
      },
      maxResultCount: 1,
      fieldPreset: 'minimal',
    });

    if (!searchResult.places || searchResult.places.length === 0) {
      console.log('❌ Business not found');
      return null;
    }

    const placeId = searchResult.places[0].id;
    console.log(`✅ Found business with Place ID: ${placeId}`);

    // Step 2: Get comprehensive business intelligence
    console.log('\n🧠 Step 2: Analyzing business...');
    const intelligence = await sdk.businessIntelligence({
      placeId,
      includeCompetitors: true,
      competitorSearchRadius: 1000,
      maxCompetitors: 5,
    });

    const profile = intelligence.businessProfile;

    // Step 3: Display onboarding summary
    console.log('\n📋 Step 3: Onboarding Summary');
    console.log('-------------------------------');
    console.log(`Business Name: ${profile.name}`);
    console.log(`Industry: ${profile.industry}${profile.industryProfile?.subcategory ? ` (${profile.industryProfile.subcategory})` : ''}`);
    console.log(`Address: ${profile.address}`);
    console.log(`Phone: ${profile.phone || 'N/A'}`);
    console.log(`Website: ${profile.website || 'N/A'}`);
    console.log(`Rating: ${profile.rating || 'N/A'} (${profile.reviewCount || 0} reviews)`);
    console.log(`Status: ${profile.businessStatus || 'Unknown'}`);

    // Industry Profile
    if (profile.industryProfile) {
      console.log('\n🏭 Industry Profile:');
      console.log(`  Category: ${profile.industryProfile.category}`);
      console.log(`  Common Pain Points:`);
      profile.industryProfile.commonPainPoints.slice(0, 3).forEach((point, i) => {
        console.log(`    ${i + 1}. ${point}`);
      });
      console.log(`  Typical Services: ${profile.industryProfile.typicalServices.join(', ')}`);
    }

    // AI Summary
    if (profile.aiSummary) {
      console.log('\n🤖 AI-Generated Summary:');
      console.log(`  ${profile.aiSummary}`);
    }

    // Review Summary
    if (profile.reviewSummary) {
      console.log('\n💬 Review Summary:');
      console.log(`  ${profile.reviewSummary}`);
    }

    // Recommendations
    console.log('\n💡 Recommendations:');
    intelligence.recommendations.forEach((rec, i) => {
      console.log(`  ${i + 1}. ${rec}`);
    });

    // Competitor Analysis
    if (intelligence.competitiveAnalysis) {
      console.log('\n🏆 Competitive Analysis:');
      console.log(`  Competitors Analyzed: ${intelligence.competitiveAnalysis.competitors.length}`);
      console.log(`  Market Average Rating: ${intelligence.competitiveAnalysis.marketInsights.averageRating.toFixed(2)}`);
      console.log(`  Total Market Reviews: ${intelligence.competitiveAnalysis.marketInsights.totalReviews}`);
    }

    // Return structured data for further processing
    return {
      placeId,
      profile,
      intelligence,
      onboardingComplete: true,
    };

  } catch (error) {
    console.error('❌ Onboarding error:', error);
    return null;
  }
}

/**
 * Main onboarding demo
 */
async function runOnboardingDemo() {
  await sdk.connect();

  // Example businesses to onboard
  const businesses = [
    {
      name: 'Joe\'s Pizza',
      location: { latitude: 40.7589, longitude: -73.9851 }, // Times Square area
    },
    {
      name: 'Blue Bottle Coffee',
      location: { latitude: 37.7749, longitude: -122.4194 }, // San Francisco
    },
  ];

  for (const business of businesses) {
    await onboardBusiness(business.name, business.location);
  }

  await sdk.disconnect();
}

// Run the demo
runOnboardingDemo().catch(console.error);
