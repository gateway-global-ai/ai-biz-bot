/**
 * Google Places SDK Client
 * High-level client for interacting with Google Places APIs
 */

import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import {
  Place,
  TextSearchResponse,
  NearbySearchResponse,
  AutocompleteResponse,
  PlacePhotoResponse,
  BusinessProfile,
  PlaceDetailsParams,
  TextSearchParams,
  NearbySearchParams,
  AutocompleteParams,
  PlacePhotoParams,
} from './types.js';

export interface SDKConfig {
  /** Path to the MCP server executable */
  serverPath?: string;
  /** Google Places API key (if not using MCP server) */
  apiKey?: string;
  /** Request timeout in milliseconds */
  timeout?: number;
}

/**
 * Google Places SDK Client
 * 
 * Provides a high-level interface for accessing Google Places APIs
 * through the MCP server or direct API calls.
 * 
 * @example
 * ```typescript
 * const client = new GooglePlacesSDK({
 *   serverPath: './node_modules/.bin/google-places-mcp'
 * });
 * 
 * await client.connect();
 * 
 * const results = await client.textSearch({
 *   textQuery: 'pizza restaurants in New York'
 * });
 * ```
 */
export class GooglePlacesSDK {
  private client: Client | null = null;
  private transport: StdioClientTransport | null = null;
  private config: SDKConfig;

  constructor(config: SDKConfig = {}) {
    this.config = {
      timeout: 30000,
      ...config,
    };
  }

  /**
   * Connect to the MCP server
   */
  async connect(): Promise<void> {
    if (!this.config.serverPath) {
      throw new Error('serverPath is required for MCP connection');
    }

    this.transport = new StdioClientTransport({
      command: this.config.serverPath,
      env: {
        ...process.env,
        GOOGLE_PLACES_API_KEY: process.env.GOOGLE_PLACES_API_KEY || '',
      },
    });

    this.client = new Client(
      {
        name: 'google-places-sdk',
        version: '1.0.0',
      },
      {
        capabilities: {},
      }
    );

    await this.client.connect(this.transport);
  }

  /**
   * Disconnect from the MCP server
   */
  async disconnect(): Promise<void> {
    if (this.transport) {
      await this.transport.close();
      this.transport = null;
      this.client = null;
    }
  }

  /**
   * Get place details by Place ID
   */
  async getPlaceDetails(params: PlaceDetailsParams & { includeBusinessProfile?: boolean }): Promise<Place | BusinessProfile> {
    this.ensureConnected();
    
    const result = await this.client!.callTool({
      name: 'google_places_get_details',
      arguments: params as any,
    });

    const text = result.content.find(c => c.type === 'text')?.text;
    if (!text) {
      throw new Error('No response from server');
    }

    return JSON.parse(text);
  }

  /**
   * Search for places using text query
   */
  async textSearch(params: TextSearchParams & { includeBusinessProfiles?: boolean }): Promise<TextSearchResponse> {
    this.ensureConnected();
    
    const result = await this.client!.callTool({
      name: 'google_places_text_search',
      arguments: params as any,
    });

    const text = result.content.find(c => c.type === 'text')?.text;
    if (!text) {
      throw new Error('No response from server');
    }

    return JSON.parse(text);
  }

  /**
   * Search for places near a location
   */
  async nearbySearch(params: NearbySearchParams & { includeBusinessProfiles?: boolean }): Promise<NearbySearchResponse> {
    this.ensureConnected();
    
    const result = await this.client!.callTool({
      name: 'google_places_nearby_search',
      arguments: params as any,
    });

    const text = result.content.find(c => c.type === 'text')?.text;
    if (!text) {
      throw new Error('No response from server');
    }

    return JSON.parse(text);
  }

  /**
   * Get autocomplete suggestions
   */
  async autocomplete(params: AutocompleteParams): Promise<AutocompleteResponse> {
    this.ensureConnected();
    
    const result = await this.client!.callTool({
      name: 'google_places_autocomplete',
      arguments: params as any,
    });

    const text = result.content.find(c => c.type === 'text')?.text;
    if (!text) {
      throw new Error('No response from server');
    }

    return JSON.parse(text);
  }

  /**
   * Get place photo URL
   */
  async getPlacePhoto(params: PlacePhotoParams): Promise<PlacePhotoResponse> {
    this.ensureConnected();
    
    const result = await this.client!.callTool({
      name: 'google_places_get_photo',
      arguments: params as any,
    });

    const text = result.content.find(c => c.type === 'text')?.text;
    if (!text) {
      throw new Error('No response from server');
    }

    return JSON.parse(text);
  }

  /**
   * Perform comprehensive business intelligence analysis
   */
  async businessIntelligence(params: {
    placeId: string;
    includeCompetitors?: boolean;
    competitorSearchRadius?: number;
    maxCompetitors?: number;
    languageCode?: string;
  }): Promise<{
    businessProfile: BusinessProfile;
    reviewAnalysis?: any;
    recommendations: string[];
    competitiveAnalysis?: any;
    metadata: any;
  }> {
    this.ensureConnected();
    
    const result = await this.client!.callTool({
      name: 'google_places_business_intelligence',
      arguments: params as any,
    });

    const text = result.content.find(c => c.type === 'text')?.text;
    if (!text) {
      throw new Error('No response from server');
    }

    return JSON.parse(text);
  }

  /**
   * Find business by name and location
   * Convenience method that combines text search and place details
   */
  async findBusiness(
    name: string,
    location?: { latitude: number; longitude: number },
    options?: { radius?: number; includeBusinessProfile?: boolean }
  ): Promise<Place | BusinessProfile | null> {
    const searchParams: TextSearchParams = {
      textQuery: name,
      maxResultCount: 1,
    };

    if (location) {
      searchParams.locationBias = {
        circle: {
          center: location,
          radius: options?.radius || 5000,
        },
      };
    }

    const searchResult = await this.textSearch(searchParams);
    
    if (!searchResult.places || searchResult.places.length === 0) {
      return null;
    }

    const place = searchResult.places[0];
    
    if (options?.includeBusinessProfile) {
      return this.getPlaceDetails({
        placeId: place.id,
        includeBusinessProfile: true,
      });
    }

    return place;
  }

  /**
   * Find competitors for a business
   */
  async findCompetitors(
    placeId: string,
    options?: { radius?: number; maxResults?: number }
  ): Promise<Place[]> {
    // First get the business location
    const business = await this.getPlaceDetails({
      placeId,
      fields: ['id', 'location', 'primaryType'],
    });

    if (!business.location) {
      throw new Error('Business location not available');
    }

    const searchResult = await this.nearbySearch({
      locationRestriction: {
        circle: {
          center: business.location,
          radius: options?.radius || 1000,
        },
      },
      includedPrimaryTypes: business.primaryType ? [business.primaryType] : undefined,
      maxResultCount: options?.maxResults || 10,
    });

    // Filter out the original business
    return (searchResult.places || []).filter(p => p.id !== placeId);
  }

  /**
   * Ensure client is connected
   */
  private ensureConnected(): void {
    if (!this.client || !this.transport) {
      throw new Error('SDK not connected. Call connect() first.');
    }
  }
}

export default GooglePlacesSDK;
