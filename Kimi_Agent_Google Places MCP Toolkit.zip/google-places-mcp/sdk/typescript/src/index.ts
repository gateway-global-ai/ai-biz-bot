/**
 * Google Places SDK
 * TypeScript SDK for Google Places MCP Server
 */

export { GooglePlacesSDK, type SDKConfig } from './client.js';
export * from './types.js';

// Convenience exports
export { GooglePlacesSDK as default } from './client.js';
