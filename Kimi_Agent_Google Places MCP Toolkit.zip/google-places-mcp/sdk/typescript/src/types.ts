/**
 * Google Places SDK Types
 * Re-export of types from the MCP server
 */

// Re-export all types from the main server
export * from '../../src/types/index.js';

// SDK-specific types
export interface SDKResponse<T> {
  data: T;
  meta: {
    requestId: string;
    timestamp: string;
    duration: number;
  };
}

export interface SDKError {
  code: string;
  message: string;
  details?: Record<string, any>;
}

export interface SearchOptions {
  /** Maximum number of results */
  limit?: number;
  /** Offset for pagination */
  offset?: number;
  /** Language code */
  language?: string;
  /** Region code */
  region?: string;
}

export interface BusinessSearchOptions extends SearchOptions {
  /** Filter by open status */
  openNow?: boolean;
  /** Minimum rating */
  minRating?: number;
  /** Price levels to include */
  priceLevels?: string[];
  /** Location bias */
  near?: {
    latitude: number;
    longitude: number;
    radius?: number;
  };
}
