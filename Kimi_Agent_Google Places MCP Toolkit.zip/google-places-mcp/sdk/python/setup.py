"""
Google Places Python SDK Setup
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="google-places-sdk",
    version="1.0.0",
    author="AI Biz Bot",
    author_email="support@aibizbot.com",
    description="Python SDK for Google Places MCP Server",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/aibizbot/google-places-mcp",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
    ],
    python_requires=">=3.8",
    install_requires=[
        # No external dependencies for core functionality
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
            "flake8>=6.0.0",
        ],
    },
    keywords="google places maps location business mcp ai",
    project_urls={
        "Bug Reports": "https://github.com/aibizbot/google-places-mcp/issues",
        "Source": "https://github.com/aibizbot/google-places-mcp",
        "Documentation": "https://github.com/aibizbot/google-places-mcp/blob/main/docs/SDK.md",
    },
)
