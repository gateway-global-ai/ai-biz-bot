"""
Google Places SDK Client
High-level client for interacting with Google Places APIs via MCP
"""

import json
import os
import subprocess
from typing import Optional, Dict, Any, List, Union
from .types import (
    Place,
    BusinessProfile,
    TextSearchResponse,
    NearbySearchResponse,
    AutocompleteResponse,
    PlacePhotoResponse,
    LocationBias,
    LocationRestriction,
)


class GooglePlacesSDK:
    """
    Google Places SDK Client
    
    Provides a high-level interface for accessing Google Places APIs
    through the MCP server.
    
    Example:
        >>> sdk = GooglePlacesSDK(server_path='./dist/index.js')
        >>> await sdk.connect()
        >>> results = await sdk.text_search('pizza in New York')
        >>> await sdk.disconnect()
    """
    
    def __init__(
        self,
        server_path: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: int = 30000
    ):
        """
        Initialize the SDK
        
        Args:
            server_path: Path to the MCP server executable
            api_key: Google Places API key (if not using MCP server)
            timeout: Request timeout in milliseconds
        """
        self.server_path = server_path
        self.api_key = api_key or os.getenv('GOOGLE_PLACES_API_KEY')
        self.timeout = timeout
        self._process: Optional[subprocess.Popen] = None
        
    async def connect(self) -> None:
        """Connect to the MCP server"""
        if not self.server_path:
            raise ValueError("server_path is required for MCP connection")
        
        env = os.environ.copy()
        if self.api_key:
            env['GOOGLE_PLACES_API_KEY'] = self.api_key
            
        self._process = subprocess.Popen(
            ['node', self.server_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            text=True
        )
        
    async def disconnect(self) -> None:
        """Disconnect from the MCP server"""
        if self._process:
            self._process.terminate()
            self._process.wait()
            self._process = None
            
    def _call_tool(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Call an MCP tool"""
        if not self._process:
            raise RuntimeError("SDK not connected. Call connect() first.")
        
        # This is a simplified implementation
        # In production, you'd use proper MCP protocol communication
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": name,
                "arguments": arguments
            },
            "id": 1
        }
        
        # Send request
        request_json = json.dumps(request) + '\n'
        self._process.stdin.write(request_json)
        self._process.stdin.flush()
        
        # Read response
        response_line = self._process.stdout.readline()
        response = json.loads(response_line)
        
        if 'error' in response:
            raise Exception(response['error']['message'])
        
        # Extract content
        result = response.get('result', {})
        content = result.get('content', [])
        
        if content and content[0].get('type') == 'text':
            return json.loads(content[0]['text'])
        
        return result
        
    async def get_place_details(
        self,
        place_id: str,
        fields: Optional[List[str]] = None,
        field_preset: Optional[str] = None,
        language_code: Optional[str] = None,
        region_code: Optional[str] = None,
        include_business_profile: bool = False
    ) -> Union[Place, BusinessProfile]:
        """
        Get place details by Place ID
        
        Args:
            place_id: The Google Place ID
            fields: Specific fields to return
            field_preset: Predefined field set
            language_code: Preferred language
            region_code: Region code for formatting
            include_business_profile: Transform to business profile
            
        Returns:
            Place details or BusinessProfile
        """
        arguments = {
            "placeId": place_id,
            "includeBusinessProfile": include_business_profile
        }
        
        if fields:
            arguments["fields"] = fields
        if field_preset:
            arguments["fieldPreset"] = field_preset
        if language_code:
            arguments["languageCode"] = language_code
        if region_code:
            arguments["regionCode"] = region_code
            
        return self._call_tool("google_places_get_details", arguments)
        
    async def text_search(
        self,
        text_query: str,
        fields: Optional[List[str]] = None,
        field_preset: Optional[str] = None,
        language_code: Optional[str] = None,
        region_code: Optional[str] = None,
        location_bias: Optional[LocationBias] = None,
        location_restriction: Optional[LocationRestriction] = None,
        included_type: Optional[str] = None,
        open_now: Optional[bool] = None,
        min_rating: Optional[float] = None,
        max_result_count: Optional[int] = None,
        price_levels: Optional[List[str]] = None,
        include_business_profiles: bool = False
    ) -> TextSearchResponse:
        """
        Search for places using text query
        
        Args:
            text_query: Search query text
            fields: Specific fields to return
            field_preset: Predefined field set
            language_code: Preferred language
            region_code: Region code
            location_bias: Bias results toward location
            location_restriction: Restrict results to area
            included_type: Filter by place type
            open_now: Only return open places
            min_rating: Minimum rating filter
            max_result_count: Maximum results (1-20)
            price_levels: Filter by price levels
            include_business_profiles: Transform to business profiles
            
        Returns:
            Text search response
        """
        arguments: Dict[str, Any] = {
            "textQuery": text_query,
            "includeBusinessProfiles": include_business_profiles
        }
        
        if fields:
            arguments["fields"] = fields
        if field_preset:
            arguments["fieldPreset"] = field_preset
        if language_code:
            arguments["languageCode"] = language_code
        if region_code:
            arguments["regionCode"] = region_code
        if location_bias:
            arguments["locationBias"] = location_bias
        if location_restriction:
            arguments["locationRestriction"] = location_restriction
        if included_type:
            arguments["includedType"] = included_type
        if open_now is not None:
            arguments["openNow"] = open_now
        if min_rating is not None:
            arguments["minRating"] = min_rating
        if max_result_count:
            arguments["maxResultCount"] = max_result_count
        if price_levels:
            arguments["priceLevels"] = price_levels
            
        return self._call_tool("google_places_text_search", arguments)
        
    async def nearby_search(
        self,
        location_restriction: LocationRestriction,
        fields: Optional[List[str]] = None,
        field_preset: Optional[str] = None,
        language_code: Optional[str] = None,
        region_code: Optional[str] = None,
        included_types: Optional[List[str]] = None,
        excluded_types: Optional[List[str]] = None,
        included_primary_types: Optional[List[str]] = None,
        excluded_primary_types: Optional[List[str]] = None,
        max_result_count: Optional[int] = None,
        rank_preference: Optional[str] = None,
        open_now: Optional[bool] = None,
        min_rating: Optional[float] = None,
        include_business_profiles: bool = False
    ) -> NearbySearchResponse:
        """
        Search for places near a location
        
        Args:
            location_restriction: Define search area
            fields: Specific fields to return
            field_preset: Predefined field set
            language_code: Preferred language
            region_code: Region code
            included_types: Include only these types
            excluded_types: Exclude these types
            included_primary_types: Include only these primary types
            excluded_primary_types: Exclude these primary types
            max_result_count: Maximum results (1-20)
            rank_preference: Rank by POPULARITY or DISTANCE
            open_now: Only return open places
            min_rating: Minimum rating filter
            include_business_profiles: Transform to business profiles
            
        Returns:
            Nearby search response
        """
        arguments: Dict[str, Any] = {
            "locationRestriction": location_restriction,
            "includeBusinessProfiles": include_business_profiles
        }
        
        if fields:
            arguments["fields"] = fields
        if field_preset:
            arguments["fieldPreset"] = field_preset
        if language_code:
            arguments["languageCode"] = language_code
        if region_code:
            arguments["regionCode"] = region_code
        if included_types:
            arguments["includedTypes"] = included_types
        if excluded_types:
            arguments["excludedTypes"] = excluded_types
        if included_primary_types:
            arguments["includedPrimaryTypes"] = included_primary_types
        if excluded_primary_types:
            arguments["excludedPrimaryTypes"] = excluded_primary_types
        if max_result_count:
            arguments["maxResultCount"] = max_result_count
        if rank_preference:
            arguments["rankPreference"] = rank_preference
        if open_now is not None:
            arguments["openNow"] = open_now
        if min_rating is not None:
            arguments["minRating"] = min_rating
            
        return self._call_tool("google_places_nearby_search", arguments)
        
    async def autocomplete(
        self,
        input_text: str,
        session_token: Optional[str] = None,
        fields: Optional[List[str]] = None,
        included_primary_types: Optional[List[str]] = None,
        include_pure_service_area_businesses: bool = False,
        include_query_predictions: bool = False,
        included_region_codes: Optional[List[str]] = None,
        input_offset: Optional[int] = None,
        language_code: Optional[str] = None,
        location_bias: Optional[LocationBias] = None,
        location_restriction: Optional[LocationRestriction] = None,
        origin: Optional[Dict[str, float]] = None,
        region_code: Optional[str] = None
    ) -> AutocompleteResponse:
        """
        Get autocomplete suggestions
        
        Args:
            input_text: Partial input text
            session_token: Session token for billing
            fields: Specific fields to return
            included_primary_types: Restrict to types
            include_pure_service_area_businesses: Include service area businesses
            include_query_predictions: Include query predictions
            included_region_codes: Restrict to countries
            input_offset: Cursor position
            language_code: Preferred language
            location_bias: Bias results toward location
            location_restriction: Restrict results to area
            origin: Origin for distance calculation
            region_code: Region code
            
        Returns:
            Autocomplete response
        """
        arguments: Dict[str, Any] = {
            "input": input_text,
            "includePureServiceAreaBusinesses": include_pure_service_area_businesses,
            "includeQueryPredictions": include_query_predictions
        }
        
        if session_token:
            arguments["sessionToken"] = session_token
        if fields:
            arguments["fields"] = fields
        if included_primary_types:
            arguments["includedPrimaryTypes"] = included_primary_types
        if included_region_codes:
            arguments["includedRegionCodes"] = included_region_codes
        if input_offset is not None:
            arguments["inputOffset"] = input_offset
        if language_code:
            arguments["languageCode"] = language_code
        if location_bias:
            arguments["locationBias"] = location_bias
        if location_restriction:
            arguments["locationRestriction"] = location_restriction
        if origin:
            arguments["origin"] = origin
        if region_code:
            arguments["regionCode"] = region_code
            
        return self._call_tool("google_places_autocomplete", arguments)
        
    async def get_place_photo(
        self,
        photo_name: str,
        max_width_px: Optional[int] = None,
        max_height_px: Optional[int] = None,
        skip_http_redirect: bool = False
    ) -> PlacePhotoResponse:
        """
        Get place photo
        
        Args:
            photo_name: Photo resource name
            max_width_px: Maximum width
            max_height_px: Maximum height
            skip_http_redirect: Return data directly
            
        Returns:
            Photo response with URL
        """
        arguments: Dict[str, Any] = {
            "photoName": photo_name,
            "skipHttpRedirect": skip_http_redirect
        }
        
        if max_width_px:
            arguments["maxWidthPx"] = max_width_px
        if max_height_px:
            arguments["maxHeightPx"] = max_height_px
            
        return self._call_tool("google_places_get_photo", arguments)
        
    async def business_intelligence(
        self,
        place_id: str,
        include_competitors: bool = False,
        competitor_search_radius: int = 1000,
        max_competitors: int = 5,
        language_code: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Perform comprehensive business intelligence analysis
        
        Args:
            place_id: Place ID to analyze
            include_competitors: Include competitor analysis
            competitor_search_radius: Radius for competitor search
            max_competitors: Maximum competitors to analyze
            language_code: Preferred language
            
        Returns:
            Business intelligence report
        """
        arguments: Dict[str, Any] = {
            "placeId": place_id,
            "includeCompetitors": include_competitors,
            "competitorSearchRadius": competitor_search_radius,
            "maxCompetitors": max_competitors
        }
        
        if language_code:
            arguments["languageCode"] = language_code
            
        return self._call_tool("google_places_business_intelligence", arguments)
