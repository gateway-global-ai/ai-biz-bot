"""
Google Places SDK Types
Type definitions for the Python SDK
"""

from typing import TypedDict, Optional, List, Dict, Any
from dataclasses import dataclass


class LatLng(TypedDict):
    """Latitude and longitude coordinates"""
    latitude: float
    longitude: float


class Circle(TypedDict):
    """Circle definition for location bias/restriction"""
    center: LatLng
    radius: float


class Rectangle(TypedDict):
    """Rectangle definition for location bias/restriction"""
    low: LatLng
    high: LatLng


class LocationBias(TypedDict, total=False):
    """Location bias for search"""
    circle: Circle
    rectangle: Rectangle


class LocationRestriction(TypedDict, total=False):
    """Location restriction for search"""
    circle: Circle
    rectangle: Rectangle


class LocalizedText(TypedDict):
    """Localized text with language code"""
    text: str
    languageCode: Optional[str]


class Photo(TypedDict):
    """Place photo"""
    name: str
    widthPx: int
    heightPx: int
    authorAttributions: List[Dict[str, Any]]


class OpeningHours(TypedDict):
    """Business opening hours"""
    openNow: Optional[bool]
    periods: List[Dict[str, Any]]
    weekdayDescriptions: List[str]


class Review(TypedDict):
    """Customer review"""
    name: Optional[str]
    relativePublishTimeDescription: str
    text: Optional[LocalizedText]
    rating: int
    authorAttribution: Dict[str, Any]
    publishTime: str


class GenerativeSummary(TypedDict):
    """AI-generated summary"""
    overview: Optional[LocalizedText]
    description: Optional[LocalizedText]


class ReviewSummary(TypedDict):
    """AI-generated review summary"""
    text: Optional[LocalizedText]


class IndustryProfile(TypedDict):
    """Industry profile information"""
    category: str
    subcategory: Optional[str]
    commonPainPoints: List[str]
    typicalServices: List[str]
    peakHours: Optional[List[str]]
    seasonality: Optional[str]


class BusinessProfile(TypedDict):
    """Structured business profile"""
    placeId: str
    name: str
    address: str
    phone: Optional[str]
    website: Optional[str]
    rating: Optional[float]
    reviewCount: Optional[int]
    businessStatus: Optional[str]
    primaryType: Optional[str]
    types: List[str]
    hours: Optional[OpeningHours]
    photos: Optional[List[Photo]]
    reviews: Optional[List[Review]]
    aiSummary: Optional[str]
    reviewSummary: Optional[str]
    industry: str
    industryProfile: Optional[IndustryProfile]


class Place(TypedDict, total=False):
    """Google Place object"""
    id: str
    name: str
    displayName: Optional[LocalizedText]
    formattedAddress: Optional[str]
    shortFormattedAddress: Optional[str]
    addressComponents: Optional[List[Dict[str, Any]]]
    location: Optional[LatLng]
    viewport: Optional[Dict[str, Any]]
    types: Optional[List[str]]
    primaryType: Optional[str]
    primaryTypeDisplayName: Optional[LocalizedText]
    nationalPhoneNumber: Optional[str]
    internationalPhoneNumber: Optional[str]
    websiteUri: Optional[str]
    googleMapsUri: Optional[str]
    businessStatus: Optional[str]
    iconMaskBaseUri: Optional[str]
    iconBackgroundColor: Optional[str]
    rating: Optional[float]
    userRatingCount: Optional[int]
    priceLevel: Optional[str]
    priceRange: Optional[Dict[str, Any]]
    regularOpeningHours: Optional[OpeningHours]
    currentOpeningHours: Optional[OpeningHours]
    photos: Optional[List[Photo]]
    reviews: Optional[List[Review]]
    generativeSummary: Optional[GenerativeSummary]
    reviewSummary: Optional[ReviewSummary]
    editorialSummary: Optional[Dict[str, Any]]
    accessibilityOptions: Optional[Dict[str, bool]]
    parkingOptions: Optional[Dict[str, bool]]
    paymentOptions: Optional[Dict[str, bool]]
    allowsDogs: Optional[bool]
    curbsidePickup: Optional[bool]
    delivery: Optional[bool]
    dineIn: Optional[bool]
    goodForChildren: Optional[bool]
    goodForGroups: Optional[bool]
    goodForWatchingSports: Optional[bool]
    liveMusic: Optional[bool]
    menuForChildren: Optional[bool]
    outdoorSeating: Optional[bool]
    reservable: Optional[bool]
    restroom: Optional[bool]
    servesBeer: Optional[bool]
    servesBreakfast: Optional[bool]
    servesBrunch: Optional[bool]
    servesCocktails: Optional[bool]
    servesCoffee: Optional[bool]
    servesDessert: Optional[bool]
    servesDinner: Optional[bool]
    servesLunch: Optional[bool]
    servesVegetarianFood: Optional[bool]
    servesWine: Optional[bool]
    takeout: Optional[bool]
    utcOffsetMinutes: Optional[int]


class TextSearchResponse(TypedDict):
    """Text search response"""
    places: List[Place]
    nextPageToken: Optional[str]


class NearbySearchResponse(TypedDict):
    """Nearby search response"""
    places: List[Place]
    nextPageToken: Optional[str]


class PlacePrediction(TypedDict):
    """Place prediction for autocomplete"""
    place: str
    placeId: str
    text: LocalizedText
    structuredFormat: Optional[Dict[str, LocalizedText]]
    types: Optional[List[str]]
    distanceMeters: Optional[int]


class QueryPrediction(TypedDict):
    """Query prediction for autocomplete"""
    text: LocalizedText
    structuredFormat: Optional[Dict[str, LocalizedText]]


class Suggestion(TypedDict):
    """Autocomplete suggestion"""
    placePrediction: Optional[PlacePrediction]
    queryPrediction: Optional[QueryPrediction]


class AutocompleteResponse(TypedDict):
    """Autocomplete response"""
    suggestions: List[Suggestion]


class PlacePhotoResponse(TypedDict):
    """Place photo response"""
    photoUri: str
