"""
Google Places SDK Utilities
Utility functions for the Python SDK
"""

import uuid
import time


def generate_session_token() -> str:
    """
    Generate a session token for autocomplete sessions
    
    Session tokens are used to group related autocomplete requests
    into a single billable session, significantly reducing costs.
    
    Returns:
        A unique session token string
        
    Example:
        >>> token = generate_session_token()
        >>> print(token)
        'session_1703001600_a1b2c3d4e5f6'
    """
    timestamp = int(time.time())
    unique_id = uuid.uuid4().hex[:12]
    return f"session_{timestamp}_{unique_id}"


def build_photo_url(
    photo_name: str,
    api_key: str,
    max_width_px: int = None,
    max_height_px: int = None
) -> str:
    """
    Build a direct photo URL from a photo name
    
    Args:
        photo_name: The photo resource name
        api_key: Google Places API key
        max_width_px: Maximum width in pixels
        max_height_px: Maximum height in pixels
        
    Returns:
        Direct URL to the photo
        
    Example:
        >>> url = build_photo_url(
        ...     'places/ChIJ.../photos/AXCi...',
        ...     'your_api_key',
        ...     max_width_px=800
        ... )
    """
    base_url = f"https://places.googleapis.com/v1/{photo_name}/media"
    params = [f"key={api_key}"]
    
    if max_width_px:
        params.append(f"maxWidthPx={max_width_px}")
    if max_height_px:
        params.append(f"maxHeightPx={max_height_px}")
    
    return f"{base_url}?{'&'.join(params)}"


def calculate_distance(
    lat1: float,
    lon1: float,
    lat2: float,
    lon2: float
) -> float:
    """
    Calculate the great circle distance between two points
    on the earth using the Haversine formula
    
    Args:
        lat1: Latitude of point 1
        lon1: Longitude of point 1
        lat2: Latitude of point 2
        lon2: Longitude of point 2
        
    Returns:
        Distance in meters
        
    Example:
        >>> distance = calculate_distance(
        ...     40.7589, -73.9851,  # Times Square
        ...     40.7489, -73.9680   # Midtown
        ... )
        >>> print(f"{distance:.0f} meters")
    """
    import math
    
    # Convert to radians
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)
    
    # Haversine formula
    a = (math.sin(delta_lat / 2) ** 2 +
         math.cos(lat1_rad) * math.cos(lat2_rad) *
         math.sin(delta_lon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    # Earth's radius in meters
    earth_radius = 6371000
    
    return earth_radius * c


def format_rating_stars(rating: float, max_stars: int = 5) -> str:
    """
    Format a rating as star characters
    
    Args:
        rating: Rating value (0-5)
        max_stars: Maximum number of stars
        
    Returns:
        Star string representation
        
    Example:
        >>> format_rating_stars(4.5)
        '⭐⭐⭐⭐½'
        >>> format_rating_stars(3.0)
        '⭐⭐⭐'
    """
    full_stars = int(rating)
    half_star = rating - full_stars >= 0.5
    empty_stars = max_stars - full_stars - (1 if half_star else 0)
    
    stars = '⭐' * full_stars
    if half_star:
        stars += '½'
    stars += '☆' * empty_stars
    
    return stars


def parse_place_id_from_name(place_name: str) -> str:
    """
    Extract the Place ID from a place resource name
    
    Args:
        place_name: Full place resource name (e.g., "places/ChIJ...")
        
    Returns:
        Place ID
        
    Example:
        >>> parse_place_id_from_name("places/ChIJj61dQgK6j4AR4GeTYWZsKWw")
        'ChIJj61dQgK6j4AR4GeTYWZsKWw'
    """
    if place_name.startswith("places/"):
        return place_name[7:]
    return place_name


def is_place_open(hours: dict) -> Optional[bool]:
    """
    Check if a place is currently open
    
    Args:
        hours: Opening hours object from Place Details
        
    Returns:
        True if open, False if closed, None if unknown
    """
    if hours and 'openNow' in hours:
        return hours['openNow']
    return None


def get_primary_type_display_name(place: dict) -> Optional[str]:
    """
    Get the human-readable primary type name
    
    Args:
        place: Place object
        
    Returns:
        Display name of primary type, or None
    """
    if 'primaryTypeDisplayName' in place:
        return place['primaryTypeDisplayName'].get('text')
    if 'primaryType' in place:
        # Convert snake_case to Title Case
        return place['primaryType'].replace('_', ' ').title()
    return None
