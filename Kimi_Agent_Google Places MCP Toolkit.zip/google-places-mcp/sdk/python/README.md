# Google Places Python SDK

A Python SDK for interacting with the Google Places MCP Server.

## Installation

```bash
pip install google-places-sdk
```

## Quick Start

```python
import asyncio
from google_places_sdk import GooglePlacesSDK

async def main():
    # Initialize SDK
    sdk = GooglePlacesSDK(server_path='./dist/index.js')
    
    # Connect to server
    await sdk.connect()
    
    # Search for places
    results = await sdk.text_search('pizza restaurants in New York')
    
    for place in results['places']:
        print(f"{place['displayName']['text']} - {place['formattedAddress']}")
    
    # Disconnect
    await sdk.disconnect()

asyncio.run(main())
```

## Configuration

```python
from google_places_sdk import GooglePlacesSDK

sdk = GooglePlacesSDK(
    server_path='./dist/index.js',
    api_key='your_api_key',  # Or set GOOGLE_PLACES_API_KEY env var
    timeout=30000
)
```

## Available Methods

### Place Details

```python
details = await sdk.get_place_details(
    place_id='ChIJj61dQgK6j4AR4GeTYWZsKWw',
    field_preset='complete',
    include_business_profile=True
)
```

### Text Search

```python
results = await sdk.text_search(
    text_query='coffee shops near Central Park',
    location_bias={
        'circle': {
            'center': {'latitude': 40.785091, 'longitude': -73.968285},
            'radius': 1000
        }
    },
    open_now=True,
    min_rating=4.0
)
```

### Nearby Search

```python
results = await sdk.nearby_search(
    location_restriction={
        'circle': {
            'center': {'latitude': 37.7749, 'longitude': -122.4194},
            'radius': 500
        }
    },
    included_types=['restaurant', 'cafe'],
    max_result_count=20
)
```

### Autocomplete

```python
from google_places_sdk import generate_session_token

token = generate_session_token()

suggestions = await sdk.autocomplete(
    input_text='Starbucks',
    session_token=token,
    location_bias={
        'circle': {
            'center': {'latitude': 40.7128, 'longitude': -74.0060},
            'radius': 10000
        }
    }
)
```

### Business Intelligence

```python
analysis = await sdk.business_intelligence(
    place_id='ChIJj61dQgK6j4AR4GeTYWZsKWw',
    include_competitors=True,
    competitor_search_radius=1000,
    max_competitors=5
)

print(analysis['businessProfile']['name'])
print(analysis['recommendations'])
```

## Field Presets

| Preset | Description |
|--------|-------------|
| `minimal` | id, displayName only |
| `basic` | + address, location |
| `contact` | + phone, website |
| `ratings` | + rating, reviews |
| `hours` | + opening hours |
| `photos` | + photos |
| `ai_summary` | + Gemini summaries |
| `complete` | All available fields |

## Utilities

```python
from google_places_sdk.utils import (
    generate_session_token,
    calculate_distance,
    format_rating_stars,
    build_photo_url
)

# Generate session token
token = generate_session_token()

# Calculate distance between two points
distance = calculate_distance(
    40.7589, -73.9851,  # Point 1
    37.7749, -122.4194  # Point 2
)
print(f"Distance: {distance:.0f} meters")

# Format rating as stars
stars = format_rating_stars(4.5)
print(stars)  # ⭐⭐⭐⭐½

# Build photo URL
url = build_photo_url(
    'places/ChIJ.../photos/AXCi...',
    'your_api_key',
    max_width_px=800
)
```

## Error Handling

```python
try:
    results = await sdk.text_search('restaurants in New York')
except Exception as e:
    print(f"Error: {e}")
```

## License

MIT License - see LICENSE file for details.
