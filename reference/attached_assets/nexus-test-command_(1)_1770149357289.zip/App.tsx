import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { ServerPanel } from './components/ServerPanel';
import { GlobalConfiguration } from './components/EnvManager';
import { TestOrchestrator } from './components/TestOrchestrator';
import { ResultsAnalyzer } from './components/ResultsAnalyzer';
import { DiscVisualizer } from './components/DiscVisualizer';
import { SecurityDashboard } from './components/SecurityDashboard';
import { TwilioHub } from './components/TwilioHub';

export default function App() {
  const [activeTab, setActiveTab] = useState('servers');

  const renderContent = () => {
    switch (activeTab) {
      case 'servers': return <ServerPanel />;
      case 'global_config': return <GlobalConfiguration />;
      case 'tests': return <TestOrchestrator />;
      case 'results': return <ResultsAnalyzer />;
      case 'disc': return <DiscVisualizer />;
      case 'security': return <SecurityDashboard />;
      case 'twilio': return <TwilioHub />;
      default: return <ServerPanel />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
}