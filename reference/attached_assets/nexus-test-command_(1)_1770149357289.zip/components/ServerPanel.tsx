import React, { useState } from 'react';
import { Server } from '../types';
import { Server as ServerIcon, Power, RefreshCw, Plus, Trash2, Activity } from 'lucide-react';

const MOCK_SERVERS: Server[] = [
  { id: 'srv-01', name: 'Alpha-Test-Node', region: 'us-east-1', status: 'online', cpuUsage: 45, memoryUsage: 62, ip: '10.0.1.12' },
  { id: 'srv-02', name: 'Beta-Staging', region: 'eu-west-2', status: 'busy', cpuUsage: 88, memoryUsage: 91, ip: '10.0.2.45' },
  { id: 'srv-03', name: 'Gamma-Legacy', region: 'us-west-1', status: 'offline', cpuUsage: 0, memoryUsage: 0, ip: '10.0.3.99' },
];

export const ServerPanel: React.FC = () => {
  const [servers, setServers] = useState<Server[]>(MOCK_SERVERS);

  const toggleStatus = (id: string) => {
    setServers(prev => prev.map(s => {
      if (s.id === id) {
        return { ...s, status: s.status === 'offline' ? 'online' : 'offline', cpuUsage: s.status === 'offline' ? 20 : 0 };
      }
      return s;
    }));
  };

  const removeServer = (id: string) => {
    setServers(prev => prev.filter(s => s.id !== id));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <ServerIcon className="w-6 h-6 text-blue-400" />
            Server Control Panel
          </h2>
          <p className="text-slate-400">Real-time monitoring and infrastructure management.</p>
        </div>
        <button className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
          <Plus className="w-4 h-4" /> Add Server
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {servers.map(server => (
          <div key={server.id} className="bg-slate-800 border border-slate-700 rounded-xl p-5 shadow-lg relative overflow-hidden group">
            <div className={`absolute top-0 left-0 w-1 h-full ${
              server.status === 'online' ? 'bg-green-500' :
              server.status === 'busy' ? 'bg-yellow-500' :
              'bg-red-500'
            }`} />
            
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-semibold text-lg text-white">{server.name}</h3>
                <span className="text-xs text-slate-400 font-mono">{server.ip} • {server.region}</span>
              </div>
              <div className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider ${
                server.status === 'online' ? 'bg-green-900/30 text-green-400' :
                server.status === 'busy' ? 'bg-yellow-900/30 text-yellow-400' :
                'bg-red-900/30 text-red-400'
              }`}>
                {server.status}
              </div>
            </div>

            <div className="space-y-3 mb-6">
              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>CPU Usage</span>
                  <span>{server.cpuUsage}%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-700 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${server.cpuUsage > 80 ? 'bg-red-500' : 'bg-blue-500'}`} 
                    style={{ width: `${server.cpuUsage}%` }} 
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Memory</span>
                  <span>{server.memoryUsage}%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-purple-500 rounded-full transition-all duration-500" 
                    style={{ width: `${server.memoryUsage}%` }} 
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-4 border-t border-slate-700/50">
              <button 
                onClick={() => toggleStatus(server.id)}
                className="flex-1 bg-slate-700 hover:bg-slate-600 text-slate-200 py-2 rounded text-sm flex items-center justify-center gap-2 transition-colors"
              >
                <Power className="w-3 h-3" />
                {server.status === 'offline' ? 'Boot' : 'Shutdown'}
              </button>
              <button className="flex-1 bg-slate-700 hover:bg-slate-600 text-slate-200 py-2 rounded text-sm flex items-center justify-center gap-2 transition-colors">
                <RefreshCw className="w-3 h-3" />
                Reboot
              </button>
              <button 
                onClick={() => removeServer(server.id)}
                className="p-2 bg-red-900/20 hover:bg-red-900/40 text-red-400 rounded transition-colors"
                title="Remove Server"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};