import React from 'react';
import { SecurityAlert } from '../types';
import { ShieldAlert, ShieldCheck, AlertTriangle } from 'lucide-react';

const ALERTS: SecurityAlert[] = [
  { id: '1', severity: 'critical', component: 'OpenSSL', description: 'Buffer overflow vulnerability detected in v1.1.1', detectedAt: '2023-10-27 10:00' },
  { id: '2', severity: 'medium', component: 'Nginx Config', description: 'Weak SSL cipher suites enabled', detectedAt: '2023-10-26 15:30' },
  { id: '3', severity: 'low', component: 'Dependencies', description: 'lodash v4.17.15 has prototype pollution warning', detectedAt: '2023-10-25 09:12' },
];

export const SecurityDashboard: React.FC = () => {
  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <ShieldAlert className="w-6 h-6 text-red-500" />
          Security Audit Dashboard
        </h2>
        <p className="text-slate-400">Vulnerability monitoring and threat detection.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex items-center gap-4">
            <div className="p-3 bg-red-900/20 rounded-full text-red-500"><AlertTriangle className="w-8 h-8" /></div>
            <div>
                <div className="text-2xl font-bold text-white">1</div>
                <div className="text-sm text-slate-400">Critical Vulnerabilities</div>
            </div>
        </div>
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex items-center gap-4">
            <div className="p-3 bg-yellow-900/20 rounded-full text-yellow-500"><ShieldAlert className="w-8 h-8" /></div>
            <div>
                <div className="text-2xl font-bold text-white">4</div>
                <div className="text-sm text-slate-400">Warnings</div>
            </div>
        </div>
        <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex items-center gap-4">
            <div className="p-3 bg-green-900/20 rounded-full text-green-500"><ShieldCheck className="w-8 h-8" /></div>
            <div>
                <div className="text-2xl font-bold text-white">98%</div>
                <div className="text-sm text-slate-400">Compliance Score</div>
            </div>
        </div>
      </div>

      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
        <div className="p-4 border-b border-slate-700">
            <h3 className="font-semibold text-white">Active Alerts</h3>
        </div>
        <div className="divide-y divide-slate-700">
            {ALERTS.map(alert => (
                <div key={alert.id} className="p-4 flex items-start gap-4 hover:bg-slate-700/30 transition-colors">
                    <div className={`mt-1 w-2 h-2 rounded-full ${
                        alert.severity === 'critical' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]' :
                        alert.severity === 'medium' ? 'bg-yellow-500' :
                        'bg-blue-500'
                    }`} />
                    <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                            <h4 className="font-medium text-slate-200">{alert.component}</h4>
                            <span className="text-xs text-slate-500">{alert.detectedAt}</span>
                        </div>
                        <p className="text-sm text-slate-400">{alert.description}</p>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-bold uppercase ${
                        alert.severity === 'critical' ? 'bg-red-900/40 text-red-400 border border-red-900' :
                        alert.severity === 'medium' ? 'bg-yellow-900/40 text-yellow-400 border border-yellow-900' :
                        'bg-blue-900/40 text-blue-400 border border-blue-900'
                    }`}>
                        {alert.severity}
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};