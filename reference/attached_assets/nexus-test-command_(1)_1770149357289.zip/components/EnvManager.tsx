import React, { useState } from 'react';
import { EnvVariable, AgentConfig } from '../types';
import { TelephonyPanel } from './TelephonyPanel';
import { 
  Lock, Eye, EyeOff, Save, Key, Globe, 
  Bot, Phone, MessageSquare, Server, 
  Cpu, Share2, Github, ExternalLink, ArrowLeft,
  Zap, Rocket, Shield, Activity, Terminal, AlertTriangle, Cloud
} from 'lucide-react';

// --- Types ---
type ConfigModule = 
  | 'dashboard' 
  | 'llms' 
  | 'server_config' 
  | 'quick_actions' 
  | 'messaging' 
  | 'telephony' 
  | 'tools' 
  | 'requirements' 
  | 'deployment' 
  | 'security_auth' 
  | 'testing_monitoring';

// --- Mock Data ---
const MOCK_VARS: EnvVariable[] = [
  { id: '1', key: 'DATABASE_URL', value: 'postgres://user:pass@localhost:5432/db', serverId: 'global', lastUpdated: '2023-10-25' },
  { id: '2', key: 'API_SECRET_KEY', value: 'sk_live_51Mz...', serverId: 'srv-01', lastUpdated: '2023-10-27' },
  { id: '3', key: 'TWILIO_AUTH_TOKEN', value: 'a1b2c3d4e5...', serverId: 'global', lastUpdated: '2023-10-20' },
];

const MOCK_AGENT_CONFIG: AgentConfig = {
    id: 'agent-001',
    name: 'Nexus Base Agent',
    telephony: {
        phoneNumber: '+1 (555) 123-4567',
        allowedNumbers: ['+1 (555) 987-6543'],
        callHistory: [],
        firewallEnabled: true,
        maxCallDuration: 60,
        timeout: 30,
        twilio: {
            friendlyName: 'Nexus-Main-Trunk',
            phoneSid: 'PN1234567890abcdef',
            voiceUrl: 'https://api.nexus.test/v1/voice',
            errorUrl: 'https://api.nexus.test/v1/error'
        }
    }
};

export const GlobalConfiguration: React.FC = () => {
  const [activeModule, setActiveModule] = useState<ConfigModule>('dashboard');
  const [vars, setVars] = useState<EnvVariable[]>(MOCK_VARS);
  const [visibleIds, setVisibleIds] = useState<Set<string>>(new Set());
  const [agentConfig, setAgentConfig] = useState<AgentConfig>(MOCK_AGENT_CONFIG);

  // --- Helpers ---
  const toggleVisibility = (id: string) => {
    const newSet = new Set(visibleIds);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setVisibleIds(newSet);
  };

  const handleAgentUpdate = (updates: Partial<AgentConfig>) => {
    setAgentConfig(prev => ({ ...prev, ...updates }));
  };

  // --- Sub-View Components ---
  
  const ServerConfigView = () => (
    <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
      <div className="p-4 border-b border-slate-700 bg-slate-800/50 flex justify-between items-center">
          <div>
            <h3 className="text-white font-medium">Server Environment Variables</h3>
            <p className="text-xs text-slate-400">Manage sensitive keys for your servers.</p>
          </div>
          <button className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-md text-sm flex items-center gap-2">
              <Save className="w-4 h-4" /> Save Changes
          </button>
      </div>
      <table className="w-full text-left text-sm text-slate-300">
        <thead className="bg-slate-900/50 text-slate-400 font-medium">
          <tr>
            <th className="px-6 py-4">Scope</th>
            <th className="px-6 py-4">Key Name</th>
            <th className="px-6 py-4">Value</th>
            <th className="px-6 py-4 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-700">
          {vars.map((v) => (
            <tr key={v.id} className="hover:bg-slate-700/30 transition-colors">
              <td className="px-6 py-4">
                {v.serverId === 'global' ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-900/30 text-purple-300 border border-purple-800">
                    <Globe className="w-3 h-3" /> Global
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-900/30 text-blue-300 border border-blue-800">
                      Server: {v.serverId}
                  </span>
                )}
              </td>
              <td className="px-6 py-4 font-mono text-white">{v.key}</td>
              <td className="px-6 py-4 font-mono text-slate-400">
                <div className="flex items-center gap-2">
                  {visibleIds.has(v.id) ? v.value : '•••••••••••••••••••••'}
                </div>
              </td>
              <td className="px-6 py-4 text-right">
                <button 
                  onClick={() => toggleVisibility(v.id)}
                  className="text-slate-400 hover:text-white transition-colors"
                >
                  {visibleIds.has(v.id) ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="p-4 bg-slate-900/30 border-t border-slate-700 flex justify-center">
          <button className="text-emerald-400 hover:text-emerald-300 text-sm font-medium flex items-center gap-2">
              <Key className="w-4 h-4" /> Add New Variable
          </button>
      </div>
    </div>
  );

  const GenericPlaceholderView = ({ title, icon: Icon, description }: any) => (
    <div className="bg-slate-800 rounded-xl border border-slate-700 p-8 flex flex-col items-center text-center space-y-6">
      <div className="p-4 bg-slate-900/50 rounded-full">
        <Icon className="w-12 h-12 text-slate-400" />
      </div>
      <div>
        <h3 className="text-xl font-bold text-white mb-2">{title} Configuration</h3>
        <p className="text-slate-400 max-w-md mx-auto">{description}</p>
      </div>
      <div className="w-full max-w-md space-y-4 text-left">
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1">Configuration Name</label>
          <input type="text" className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-indigo-500" placeholder={`My ${title} Config`} />
        </div>
        <div>
           <label className="block text-xs font-medium text-slate-500 mb-1">API Endpoint / Key</label>
           <input type="password" className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-indigo-500" placeholder="••••••••••••••••" />
        </div>
        <button className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-lg font-medium transition-colors">
          Save Configuration
        </button>
      </div>
    </div>
  );

  const QuickActionsView = () => (
    <div className="bg-slate-800 rounded-xl border border-slate-700 p-8">
       <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <Zap className="w-6 h-6 text-yellow-400" /> Quick Actions
       </h3>
       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button className="p-4 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-white font-medium flex items-center gap-3 transition-colors">
            <Rocket className="w-5 h-5" /> Deploy Latest Clone
          </button>
          <button className="p-4 bg-slate-700 hover:bg-slate-600 rounded-lg text-white font-medium flex items-center gap-3 transition-colors">
            <Terminal className="w-5 h-5" /> View Deployment Logs
          </button>
          <button className="p-4 bg-red-900/30 hover:bg-red-900/50 border border-red-900/50 rounded-lg text-red-300 font-medium flex items-center gap-3 transition-colors">
            <AlertTriangle className="w-5 h-5" /> Emergency Halt
          </button>
          <button className="p-4 bg-slate-700 hover:bg-slate-600 rounded-lg text-white font-medium flex items-center gap-3 transition-colors">
            <Cloud className="w-5 h-5" /> Sync Repositories
          </button>
       </div>
    </div>
  );

  const RepoCard = ({ name, desc, url }: { name: string, desc: string, url: string }) => (
    <a href={url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-700 hover:border-indigo-500 transition-colors group">
      <div className="flex items-center gap-3">
        <Github className="w-5 h-5 text-slate-400 group-hover:text-white" />
        <div>
          <div className="text-sm font-medium text-slate-200 group-hover:text-indigo-400">{name}</div>
          <div className="text-xs text-slate-500">{desc}</div>
        </div>
      </div>
      <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-slate-400" />
    </a>
  );

  const renderModuleContent = (
    module: ConfigModule, 
    ServerConfigView: React.FC, 
    GenericPlaceholderView: React.FC<any>,
    QuickActionsView: React.FC
  ) => {
    switch(module) {
      case 'server_config': return <ServerConfigView />;
      case 'quick_actions': return <QuickActionsView />;
      case 'llms': return <GenericPlaceholderView title="LLM Providers" icon={Bot} description="Configure endpoints for OpenAI, Anthropic, or local Moonshot models." />;
      case 'messaging': return <GenericPlaceholderView title="Messaging Channels" icon={MessageSquare} description="Set up bots for Discord, Telegram, and Slack." />;
      case 'telephony': return <TelephonyPanel agent={agentConfig} onUpdate={handleAgentUpdate} onBack={() => setActiveModule('dashboard')} />;
      case 'tools': return <GenericPlaceholderView title="External Tools" icon={Share2} description="Connect to external logging, analytics, and monitoring services." />;
      case 'requirements': return (
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-8 space-y-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-orange-900/30 rounded-lg text-orange-400"><Cpu className="w-6 h-6" /></div>
              <h3 className="text-xl font-bold text-white">Hardware Requirements</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <label className="text-sm font-medium text-slate-300">Minimum RAM Allocation</label>
                <div className="flex gap-2">
                  {['4GB', '8GB', '16GB', '32GB'].map(ram => (
                    <button key={ram} className="flex-1 py-2 border border-slate-600 rounded bg-slate-700 hover:bg-indigo-600 hover:border-indigo-500 transition-colors text-sm">{ram}</button>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <label className="text-sm font-medium text-slate-300">vCPU Cores</label>
                <div className="flex gap-2">
                  {['2 Cores', '4 Cores', '8 Cores'].map(cpu => (
                    <button key={cpu} className="flex-1 py-2 border border-slate-600 rounded bg-slate-700 hover:bg-indigo-600 hover:border-indigo-500 transition-colors text-sm">{cpu}</button>
                  ))}
                </div>
              </div>
            </div>
            <div className="pt-4 border-t border-slate-700">
              <button className="bg-orange-600 hover:bg-orange-500 text-white px-6 py-2 rounded-lg text-sm font-medium">Update Spec Profile</button>
            </div>
        </div>
      );
      case 'deployment': return <GenericPlaceholderView title="Deployment Config" icon={Rocket} description="Manage Docker images, Kubernetes namespaces, and scaling policies." />;
      case 'security_auth': return <GenericPlaceholderView title="Security & Authentication" icon={Shield} description="Configure SSO, IAM roles, and secret rotation policies." />;
      case 'testing_monitoring': return <GenericPlaceholderView title="Testing & Monitoring" icon={Activity} description="Set up health check endpoints and log aggregation rules." />;
      default: return <div>Unknown Module</div>;
    }
  };

  const ConfigCard = ({ id, title, desc, icon: Icon, color, onClick }: any) => (
    <div 
      onClick={onClick} 
      className="cursor-pointer bg-slate-800 border border-slate-700 p-5 rounded-xl hover:border-indigo-500 hover:shadow-lg hover:shadow-indigo-500/10 transition-all group flex flex-col h-full"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`p-3 bg-slate-900/50 rounded-lg group-hover:scale-110 transition-transform duration-300`}>
          <Icon className={`w-6 h-6 ${color}`} />
        </div>
        <div className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-500">
          <ArrowLeft className="w-4 h-4 rotate-180" />
        </div>
      </div>
      <h4 className="text-lg font-semibold text-white mb-1">{title}</h4>
      <p className="text-sm text-slate-400 leading-relaxed">{desc}</p>
    </div>
  );

  // --- Main Dashboard Render ---
  return (
    <div className="p-6 space-y-6">
      
      {/* 1. Header & Navigation */}
      {/* Hide header if using Telephony Panel as it has its own comprehensive header */}
      {activeModule !== 'telephony' && (
        <div className="flex items-center gap-4">
          {activeModule !== 'dashboard' && (
            <button 
              onClick={() => setActiveModule('dashboard')}
              className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
          )}
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Globe className="w-6 h-6 text-indigo-400" />
              Global Configuration
            </h2>
            <p className="text-slate-400">
              {activeModule === 'dashboard' 
                ? "Base model generation for deployment and cloning." 
                : `Configure ${activeModule.replace('_', ' ')} settings.`}
            </p>
          </div>
        </div>
      )}

      {activeModule === 'dashboard' ? (
        <>
          {/* 2. Moonshot Priority Banner */}
          <div className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-700/50 rounded-xl p-4 flex items-center justify-between relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
            <div className="flex items-center gap-4 z-10">
              <div className="bg-indigo-500/20 p-2 rounded-lg">
                <Rocket className="w-6 h-6 text-indigo-300" />
              </div>
              <div>
                <h3 className="font-bold text-indigo-100">Moonshot Test Priority Active</h3>
                <p className="text-sm text-indigo-200/70">Kimi-K2.5 Foundation Model selected for next clone deployment.</p>
              </div>
            </div>
            <div className="flex items-center gap-3 z-10">
               <span className="text-xs font-mono bg-black/30 px-2 py-1 rounded text-indigo-300 border border-indigo-500/30">v2.5.0-alpha</span>
            </div>
          </div>

          {/* 3. Global Summary Panel */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-800 border border-slate-700 p-4 rounded-xl flex flex-col justify-between h-32">
              <div className="text-slate-400 text-sm font-medium">Active Configurations</div>
              <div className="text-3xl font-bold text-white">12</div>
              <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                <div className="bg-emerald-500 w-3/4 h-full rounded-full"></div>
              </div>
            </div>
            <div className="bg-slate-800 border border-slate-700 p-4 rounded-xl flex flex-col justify-between h-32">
              <div className="text-slate-400 text-sm font-medium">API Keys Status</div>
              <div className="text-3xl font-bold text-white flex items-center gap-2">
                Secure <Lock className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="text-xs text-emerald-400">All keys encrypted at rest</div>
            </div>
            <div className="bg-slate-800 border border-slate-700 p-4 rounded-xl col-span-2">
               <div className="text-slate-400 text-sm font-medium mb-3">Linked Repositories</div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <RepoCard name="MoonshotAI / Kimi-K2.5" desc="Foundation Model" url="https://github.com/MoonshotAI/Kimi-K2.5" />
                  <RepoCard name="openclaw / openclaw" desc="Automation Tools" url="https://github.com/openclaw/openclaw" />
               </div>
            </div>
          </div>

          {/* 4. Configuration Cards Grid */}
          <div className="space-y-6">
            
            {/* Top Row: Critical */}
            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Critical Configuration</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <ConfigCard 
                  id="llms"
                  title="LLM Providers" 
                  desc="Model endpoints & API keys"
                  icon={Bot}
                  color="text-purple-400"
                  onClick={() => setActiveModule('llms')}
                />
                <ConfigCard 
                  id="server_config"
                  title="Server Config" 
                  desc="Env vars & regional settings"
                  icon={Server}
                  color="text-blue-400"
                  onClick={() => setActiveModule('server_config')}
                />
                <ConfigCard 
                  id="quick_actions"
                  title="Quick Actions" 
                  desc="Deploy, Halt, Sync"
                  icon={Zap}
                  color="text-yellow-400"
                  onClick={() => setActiveModule('quick_actions')}
                />
              </div>
            </div>

            {/* Middle Row: Configuration */}
            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Communication & Tools</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 <ConfigCard 
                  id="messaging"
                  title="Messaging Channels" 
                  desc="Discord, Telegram bots"
                  icon={MessageSquare}
                  color="text-pink-400"
                  onClick={() => setActiveModule('messaging')}
                />
                <ConfigCard 
                  id="telephony"
                  title="Telephony (Twilio)" 
                  desc="Voice gateways & SMS"
                  icon={Phone}
                  color="text-green-400"
                  onClick={() => setActiveModule('telephony')}
                />
                <ConfigCard 
                  id="tools"
                  title="External Tools & APIs" 
                  desc="Third-party integrations"
                  icon={Share2}
                  color="text-teal-400"
                  onClick={() => setActiveModule('tools')}
                />
              </div>
            </div>

            {/* Bottom Row: Infrastructure */}
            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Infrastructure & Security</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <ConfigCard 
                  id="requirements"
                  title="Server Requirements" 
                  desc="Hardware specs (CPU/RAM)"
                  icon={Cpu}
                  color="text-orange-400"
                  onClick={() => setActiveModule('requirements')}
                />
                <ConfigCard 
                  id="deployment"
                  title="Deployment Config" 
                  desc="Docker & K8s manifests"
                  icon={Rocket}
                  color="text-indigo-400"
                  onClick={() => setActiveModule('deployment')}
                />
                <ConfigCard 
                  id="security_auth"
                  title="Security & Auth" 
                  desc="Encryption & Access Control"
                  icon={Shield}
                  color="text-red-400"
                  onClick={() => setActiveModule('security_auth')}
                />
                <ConfigCard 
                  id="testing_monitoring"
                  title="Testing & Monitoring" 
                  desc="Health checks & Logging"
                  icon={Activity}
                  color="text-cyan-400"
                  onClick={() => setActiveModule('testing_monitoring')}
                />
              </div>
            </div>

          </div>
        </>
      ) : (
        // --- Detailed Module Views Container ---
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
           {renderModuleContent(activeModule, ServerConfigView, GenericPlaceholderView, QuickActionsView)}
        </div>
      )}
    </div>
  );
};