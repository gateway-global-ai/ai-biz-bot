import React, { useState, useEffect } from 'react';
import { TestSuite } from '../types';
import { 
  Play, Clock, CheckCircle2, XCircle, AlertCircle, Loader2, 
  MapPin, Search, GitBranch, Box, Server, Puzzle, Code, Terminal,
  ArrowRight, ShieldCheck, Database
} from 'lucide-react';
import { searchBusinessInfo } from '../services/geminiService';

// --- Types specific to ClawBot Architecture ---
interface ClawExtension {
  id: string;
  name: string;
  type: 'provider' | 'channel' | 'tool';
  version: string;
  status: 'active' | 'inactive';
}

interface ClawNode {
  id: string;
  name: string;
  ip: string;
  provider: string;
  extensions: ClawExtension[];
  status: 'online' | 'deploying' | 'offline';
  lastHealthCheck: string;
}

const MOCK_NODES: ClawNode[] = [
  { 
    id: 'node-moonshot', 
    name: 'Moonshot Alpha', 
    ip: '10.0.1.101',
    provider: 'Kimi-K2.5', 
    status: 'online',
    lastHealthCheck: '1m ago',
    extensions: [
      { id: 'ext-kimi', name: 'kimi-moonshot', type: 'provider', version: '1.0.2', status: 'active' },
      { id: 'ext-tg', name: 'telegram', type: 'channel', version: '2.1.0', status: 'active' },
      { id: 'ext-grn', name: 'grn-hotels', type: 'tool', version: '1.4.5', status: 'active' }
    ]
  },
  { 
    id: 'node-anthropic', 
    name: 'Claude Beta', 
    ip: '10.0.1.102',
    provider: 'Anthropic Claude 3.5', 
    status: 'online',
    lastHealthCheck: '5m ago',
    extensions: [
      { id: 'ext-anth', name: 'anthropic-provider', type: 'provider', version: '1.1.0', status: 'active' },
      { id: 'ext-disc', name: 'discord', type: 'channel', version: '3.0.1', status: 'active' },
      { id: 'ext-grn', name: 'grn-hotels', type: 'tool', version: '1.4.5', status: 'active' }
    ]
  },
    { 
    id: 'node-openai', 
    name: 'GPT-4 Legacy', 
    ip: '10.0.1.103',
    provider: 'OpenAI GPT-4', 
    status: 'online',
    lastHealthCheck: '2m ago',
    extensions: [
      { id: 'ext-oai', name: 'openai-provider', type: 'provider', version: '2.0.0', status: 'active' },
      { id: 'ext-slack', name: 'slack', type: 'channel', version: '1.8.2', status: 'inactive' },
      { id: 'ext-voice', name: 'twilio-voice', type: 'channel', version: '0.9.5', status: 'active' }
    ]
  }
];

const MOCK_SUITES: Record<string, TestSuite[]> = {
  'node-moonshot': [
    { id: 'ts-m1', name: 'Kimi-K2.5 Latency', description: 'Check token generation speed', status: 'passed', lastRun: '10m ago', duration: '1.2s' },
    { id: 'ts-m2', name: 'Telegram Webhook', description: 'Verify message receipt', status: 'idle', lastRun: '1h ago', duration: '-' },
    { id: 'ts-m3', name: 'Hotel Search (GRN)', description: 'Test searchBusiness tool', status: 'idle', lastRun: 'Yesterday', duration: '-' },
  ],
  'node-anthropic': [
     { id: 'ts-a1', name: 'Discord Gateway', description: 'Heartbeat connectivity', status: 'passed', lastRun: '2m ago', duration: '45ms' },
     { id: 'ts-a2', name: 'Claude Reasoning', description: 'Complex prompt chain', status: 'failed', lastRun: '30m ago', duration: '12s' },
  ],
  'node-openai': [
     { id: 'ts-o1', name: 'Twilio Voice Stream', description: 'Bi-directional audio check', status: 'running', lastRun: 'Now', duration: '...' },
  ]
};

export const TestOrchestrator: React.FC = () => {
  const [nodes, setNodes] = useState<ClawNode[]>(MOCK_NODES);
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-moonshot');
  const [pipelineState, setPipelineState] = useState<'idle' | 'linting' | 'building' | 'deploying'>('idle');
  const [suites, setSuites] = useState<Record<string, TestSuite[]>>(MOCK_SUITES);
  
  // Grounding State
  const [groundingQuery, setGroundingQuery] = useState('');
  const [groundingResult, setGroundingResult] = useState<{text: string, places: any[] | null} | null>(null);
  const [searching, setSearching] = useState(false);

  const activeNode = nodes.find(n => n.id === selectedNodeId) || nodes[0];
  const activeSuites = suites[selectedNodeId] || [];

  // Simulate Pipeline Action
  const runPipeline = () => {
    setPipelineState('linting');
    setTimeout(() => setPipelineState('building'), 1500);
    setTimeout(() => setPipelineState('deploying'), 3500);
    setTimeout(() => setPipelineState('idle'), 5500);
  };

  const runSuite = (suiteId: string) => {
    setSuites(prev => ({
      ...prev,
      [selectedNodeId]: prev[selectedNodeId].map(s => 
        s.id === suiteId ? { ...s, status: 'running', duration: '...' } : s
      )
    }));

    setTimeout(() => {
        setSuites(prev => ({
            ...prev,
            [selectedNodeId]: prev[selectedNodeId].map(s => 
              s.id === suiteId ? { ...s, status: 'passed', duration: `${Math.floor(Math.random() * 500)}ms` } : s
            )
          }));
    }, 2000);
  };

  const handleGroundingSearch = async () => {
    if(!groundingQuery) return;
    setSearching(true);
    const result = await searchBusinessInfo(groundingQuery);
    setGroundingResult(result);
    setSearching(false);
  }

  return (
    <div className="p-6 h-full flex flex-col">
      {/* Header */}
      <div className="mb-6 flex justify-between items-end">
        <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Play className="w-6 h-6 text-indigo-400" />
            ClawBot Orchestrator
            </h2>
            <p className="text-slate-400">Manage extensions, skills, and deployment quality.</p>
        </div>
        <div className="text-right">
             <div className="flex items-center gap-2 text-xs font-mono text-slate-500 bg-slate-900 px-3 py-1 rounded border border-slate-800">
                <Server className="w-3 h-3" />
                MANAGER SERVER: 62.72.26.87 (Idle)
             </div>
        </div>
      </div>

      {/* Deployment Pipeline Status */}
      <div className="mb-8 bg-slate-800/50 rounded-xl border border-slate-700 p-4">
         <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-emerald-400" /> Deployment Pipeline
            </h3>
            {pipelineState === 'idle' ? (
                <button onClick={runPipeline} className="text-xs bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1 rounded transition-colors flex items-center gap-1">
                    <Play className="w-3 h-3" /> Trigger Release
                </button>
            ) : (
                <span className="text-xs text-indigo-400 animate-pulse font-mono uppercase">{pipelineState}...</span>
            )}
         </div>
         <div className="flex items-center gap-2">
             <Step 
                label="Git Hooks" 
                icon={ShieldCheck} 
                active={pipelineState === 'linting'} 
                completed={['building', 'deploying', 'idle'].includes(pipelineState) && pipelineState !== 'linting'} 
                desc="Lint/Type Check"
            />
             <div className="h-0.5 w-8 bg-slate-700"></div>
             <Step 
                label="Build Skills" 
                icon={Code} 
                active={pipelineState === 'building'} 
                completed={['deploying', 'idle'].includes(pipelineState) && pipelineState !== 'building' && pipelineState !== 'linting'} 
                desc="Pack Shared Libs"
            />
             <div className="h-0.5 w-8 bg-slate-700"></div>
             <Step 
                label="Deploy Image" 
                icon={Box} 
                active={pipelineState === 'deploying'} 
                completed={pipelineState === 'idle'} // Simplification for demo
                desc="Update Containers"
            />
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1">
        
        {/* LEFT COL: Nodes List */}
        <div className="lg:col-span-3 space-y-3">
             <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Test Servers</h3>
             {nodes.map(node => (
                 <div 
                    key={node.id}
                    onClick={() => setSelectedNodeId(node.id)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                        selectedNodeId === node.id 
                        ? 'bg-slate-800 border-indigo-500 shadow-lg shadow-indigo-900/20' 
                        : 'bg-slate-900/50 border-slate-800 hover:bg-slate-800 hover:border-slate-700'
                    }`}
                 >
                    <div className="flex justify-between items-start mb-2">
                        <div className="font-bold text-white">{node.name}</div>
                        <div className={`w-2 h-2 rounded-full ${node.status === 'online' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                    </div>
                    <div className="text-xs text-slate-400 font-mono mb-3">{node.ip}</div>
                    <div className="flex gap-1 flex-wrap">
                        <span className="px-2 py-0.5 bg-slate-700 rounded text-[10px] text-slate-300">{node.provider}</span>
                        <span className="px-2 py-0.5 bg-slate-700 rounded text-[10px] text-slate-300">+{node.extensions.length - 1} Exts</span>
                    </div>
                 </div>
             ))}
        </div>

        {/* MIDDLE COL: Node Details & Tests */}
        <div className="lg:col-span-6 space-y-6">
            
            {/* Active Extensions */}
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
                <div className="flex items-center gap-2 mb-4">
                    <Puzzle className="w-5 h-5 text-indigo-400" />
                    <h3 className="font-bold text-white">Installed Extensions</h3>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    {activeNode.extensions.map(ext => (
                        <div key={ext.id} className="bg-slate-900/50 border border-slate-800 p-3 rounded-lg flex justify-between items-center group hover:border-slate-600 transition-colors">
                            <div>
                                <div className="text-sm font-medium text-slate-200">{ext.name}</div>
                                <div className="text-[10px] text-slate-500 uppercase">{ext.type} • v{ext.version}</div>
                            </div>
                            <div className={`w-1.5 h-1.5 rounded-full ${ext.status === 'active' ? 'bg-emerald-500' : 'bg-slate-600'}`} />
                        </div>
                    ))}
                    <div className="bg-slate-900/30 border border-dashed border-slate-800 p-3 rounded-lg flex items-center justify-center text-slate-500 text-xs">
                        + Add Extension via Manager
                    </div>
                </div>
            </div>

            {/* Test Suites */}
            <div className="space-y-3">
                <div className="flex justify-between items-center">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Validation Suites</h3>
                    <button className="text-xs text-indigo-400 hover:text-indigo-300">Run All Active</button>
                </div>
                {activeSuites.map(suite => (
                    <div key={suite.id} className="bg-slate-800 border border-slate-700 rounded-lg p-4 flex items-center justify-between hover:border-slate-600 transition-colors">
                        <div className="flex items-start gap-4">
                        <div className={`mt-1 p-2 rounded-full ${
                            suite.status === 'passed' ? 'bg-green-900/30 text-green-400' :
                            suite.status === 'failed' ? 'bg-red-900/30 text-red-400' :
                            suite.status === 'running' ? 'bg-blue-900/30 text-blue-400 animate-pulse' :
                            'bg-slate-700 text-slate-400'
                        }`}>
                            {suite.status === 'passed' ? <CheckCircle2 className="w-4 h-4" /> :
                            suite.status === 'failed' ? <XCircle className="w-4 h-4" /> :
                            suite.status === 'running' ? <Loader2 className="w-4 h-4 animate-spin" /> :
                            <Clock className="w-4 h-4" />}
                        </div>
                        <div>
                            <h3 className="font-semibold text-white text-sm">{suite.name}</h3>
                            <p className="text-xs text-slate-400">{suite.description}</p>
                        </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <span className="text-xs text-slate-500 font-mono">{suite.duration}</span>
                            <button 
                                onClick={() => runSuite(suite.id)}
                                disabled={suite.status === 'running'}
                                className={`p-2 rounded-lg transition-colors ${
                                    suite.status === 'running' 
                                    ? 'text-slate-600 cursor-not-allowed' 
                                    : 'bg-indigo-600/10 text-indigo-400 hover:bg-indigo-600/20'
                                }`}
                            >
                                <Play className="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                ))}
            </div>

        </div>

        {/* RIGHT COL: Tools & Grounding */}
        <div className="lg:col-span-3 space-y-6">
            
            {/* Skills Status */}
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
                <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                    <Database className="w-4 h-4 text-orange-400" /> Skills Library
                </h3>
                <div className="space-y-2">
                    <div className="flex justify-between text-xs text-slate-400">
                        <span>Core Utilities</span>
                        <span className="text-emerald-400">Synced</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-400">
                        <span>Provider Interfaces</span>
                        <span className="text-emerald-400">Synced</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-400">
                        <span>Common Prompts</span>
                        <span className="text-amber-400">Update Avail</span>
                    </div>
                </div>
            </div>

            {/* Business Grounding Test Tool */}
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-5">
                <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-pink-400" />
                    Data Validation Oracle
                </h3>
                <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                    Verify real-world data availability for your bot's <code>searchBusiness</code> skill using Google Maps Grounding.
                </p>
                
                <div className="flex gap-2 mb-4">
                    <input 
                        type="text" 
                        placeholder="E.g., Pizza in Chicago"
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                        value={groundingQuery}
                        onChange={(e) => setGroundingQuery(e.target.value)}
                    />
                    <button 
                        onClick={handleGroundingSearch}
                        disabled={searching || !groundingQuery}
                        className="bg-pink-600 hover:bg-pink-500 disabled:opacity-50 text-white p-2 rounded-md"
                    >
                        {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                    </button>
                </div>

                {groundingResult && (
                    <div className="bg-slate-900/50 rounded p-3 text-xs border border-slate-800 max-h-48 overflow-y-auto">
                        <p className="text-slate-300 mb-2 leading-relaxed">{groundingResult.text}</p>
                        {groundingResult.places && groundingResult.places.length > 0 && (
                            <ul className="list-disc pl-3 text-indigo-300 space-y-1">
                                {groundingResult.places.map((place, idx) => (
                                    <li key={idx}>
                                        <a href={place.uri} target="_blank" rel="noreferrer" className="hover:underline">{place.title}</a>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                )}
            </div>
        </div>

      </div>
    </div>
  );
};

// --- Helper Component for Pipeline Steps ---
const Step = ({ label, icon: Icon, active, completed, desc }: any) => (
    <div className={`flex items-center gap-2 ${active ? 'opacity-100' : 'opacity-50'}`}>
        <div className={`p-2 rounded-full border ${
            completed ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 
            active ? 'bg-indigo-500/20 border-indigo-500 text-indigo-400 animate-pulse' : 
            'bg-slate-800 border-slate-700 text-slate-500'
        }`}>
            {completed ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
        </div>
        <div>
            <div className={`text-xs font-bold ${completed ? 'text-emerald-400' : active ? 'text-indigo-400' : 'text-slate-500'}`}>{label}</div>
            <div className="text-[10px] text-slate-500">{desc}</div>
        </div>
    </div>
);