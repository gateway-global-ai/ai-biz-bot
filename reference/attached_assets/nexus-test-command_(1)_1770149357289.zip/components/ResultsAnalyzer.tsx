import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Bot, FileText, Activity } from 'lucide-react';
import { analyzeTestFailure } from '../services/geminiService';

const DATA = [
  { name: 'Mon', passed: 40, failed: 2 },
  { name: 'Tue', passed: 35, failed: 5 },
  { name: 'Wed', passed: 50, failed: 1 },
  { name: 'Thu', passed: 48, failed: 0 },
  { name: 'Fri', passed: 38, failed: 8 },
];

const COLORS = ['#10b981', '#ef4444'];

const SAMPLE_LOG = `
[ERROR] 2023-10-27 14:22:15 - PaymentGateway::Charge
Stack Trace:
  at StripeService.charge (src/services/stripe.ts:45)
  at PaymentController.process (src/controllers/payment.ts:22)
Exception: ConnectionTimeout: Failed to connect to api.stripe.com:443 after 5000ms.
Context:
  User ID: usr_9921
  Amount: $45.00
  Retry Count: 3
`;

export const ResultsAnalyzer: React.FC = () => {
  const [analysis, setAnalysis] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    setLoading(true);
    const result = await analyzeTestFailure(SAMPLE_LOG, 'Payment Integration');
    setAnalysis(result);
    setLoading(false);
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Activity className="w-6 h-6 text-purple-400" />
          Results Analyzer
        </h2>
        <p className="text-slate-400">AI-powered insights from test results and performance metrics.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Pass/Fail Trend */}
        <div className="bg-slate-800 p-5 rounded-xl border border-slate-700">
          <h3 className="text-lg font-semibold text-white mb-4">Weekly Execution Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                    itemStyle={{ color: '#e2e8f0' }}
                />
                <Legend />
                <Bar dataKey="passed" fill="#10b981" name="Passed" />
                <Bar dataKey="failed" fill="#ef4444" name="Failed" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* AI Analysis Section */}
        <div className="bg-slate-800 p-5 rounded-xl border border-slate-700 flex flex-col">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Bot className="w-5 h-5 text-purple-400" />
            AI Failure Analysis
          </h3>
          <div className="bg-slate-900 p-3 rounded-lg font-mono text-xs text-slate-400 mb-4 overflow-auto max-h-40 border border-slate-700">
            {SAMPLE_LOG}
          </div>
          
          <div className="flex-1">
            {!analysis && !loading && (
                <div className="h-full flex flex-col items-center justify-center text-slate-500">
                    <p className="mb-4 text-sm">Select a failed log to generate insights.</p>
                    <button 
                        onClick={handleAnalyze}
                        className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
                    >
                        <Bot className="w-4 h-4" /> Analyze with Gemini
                    </button>
                </div>
            )}

            {loading && (
                <div className="h-full flex items-center justify-center text-purple-400">
                    <span className="animate-pulse">Analyzing failure patterns...</span>
                </div>
            )}

            {analysis && (
                <div className="bg-purple-900/20 border border-purple-800 p-4 rounded-lg text-sm text-slate-200 h-full overflow-auto">
                    <h4 className="font-bold text-purple-300 mb-2">Analysis Result:</h4>
                    <p className="whitespace-pre-line leading-relaxed">{analysis}</p>
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};