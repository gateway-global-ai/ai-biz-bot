import React from 'react';
import { MessageSquare, Phone, Smartphone, Check, Clock } from 'lucide-react';

export const TwilioHub: React.FC = () => {
  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <MessageSquare className="w-6 h-6 text-teal-400" />
          Twilio Integration Hub
        </h2>
        <p className="text-slate-400">Communication management for SMS alerts and Voice notifications.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
            <h3 className="text-slate-300 font-semibold mb-4 flex items-center gap-2">
                <Smartphone className="w-5 h-5" /> Recent SMS Logs
            </h3>
            <div className="space-y-3">
                {[1, 2, 3].map(i => (
                    <div key={i} className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                        <div className="flex flex-col">
                            <span className="text-sm text-white font-mono">+1 (555) 012-34{i}{i}</span>
                            <span className="text-xs text-slate-500">Alert: Server Down (SRV-0{i})</span>
                        </div>
                        <span className="flex items-center gap-1 text-xs text-green-400">
                            <Check className="w-3 h-3" /> Sent
                        </span>
                    </div>
                ))}
            </div>
        </div>

        <div className="bg-slate-800 rounded-xl border border-slate-700 p-5">
            <h3 className="text-slate-300 font-semibold mb-4 flex items-center gap-2">
                <Phone className="w-5 h-5" /> Voice Call Gateway
            </h3>
            <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                    <div className="flex flex-col">
                        <span className="text-sm text-white font-mono">+1 (555) 987-6543</span>
                        <span className="text-xs text-slate-500">Duration: 45s • Critical Alert</span>
                    </div>
                    <span className="flex items-center gap-1 text-xs text-green-400">
                        <Check className="w-3 h-3" /> Completed
                    </span>
                </div>
                 <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                    <div className="flex flex-col">
                        <span className="text-sm text-white font-mono">+1 (555) 111-2222</span>
                        <span className="text-xs text-slate-500">Duration: 0s • Warn Alert</span>
                    </div>
                    <span className="flex items-center gap-1 text-xs text-yellow-400">
                        <Clock className="w-3 h-3" /> Queued
                    </span>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};