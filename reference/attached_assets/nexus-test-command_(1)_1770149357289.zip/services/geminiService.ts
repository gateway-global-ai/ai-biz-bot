import { GoogleGenAI } from "@google/genai";
import { PlaceResult } from "../types";

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Analyzes test logs using Gemini to determine root cause and solutions.
 */
export const analyzeTestFailure = async (logs: string, suiteName: string): Promise<string> => {
  try {
    const model = 'gemini-3-flash-preview';
    const prompt = `
      You are a Senior QA Engineer AI.
      Analyze the following test failure logs for the suite "${suiteName}".
      1. Identify the root cause.
      2. Suggest 3 specific fixes.
      3. Rate the severity (Low/Medium/High).

      Logs:
      ${logs}
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 0 } // Speed over deep thought for logs
      }
    });

    return response.text || "No analysis could be generated.";
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Error generating analysis. Please check your API key and try again.";
  }
};

/**
 * Uses Google Places Grounding to find business information.
 * This simulates a "Data Validation" test step where we verify business existence.
 */
export const searchBusinessInfo = async (query: string, location?: { lat: number; lng: number }): Promise<{ text: string; places: PlaceResult[] }> => {
  try {
    const model = 'gemini-2.5-flash'; // 2.5 supports Maps grounding

    const config: any = {
      tools: [{ googleMaps: {} }],
    };

    if (location) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: {
            latitude: location.lat,
            longitude: location.lng,
          },
        },
      };
    }

    const response = await ai.models.generateContent({
      model,
      contents: `Find details about: ${query}. Provide a summary and list the places found.`,
      config: config,
    });

    const text = response.text || "No details found.";

    // Extract grounding chunks for specific URLs
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const places: PlaceResult[] = chunks
      .filter((chunk: any) => chunk.web?.uri || chunk.web?.title) // Fallback to web if maps specific isn't structured exactly as expected in all SDK versions, but usually maps data is in specific fields.
      .map((chunk: any) => ({
        title: chunk.web?.title || "Unknown Place",
        uri: chunk.web?.uri || "#",
      }));

    // Basic extraction if the SDK structures maps differently
    // Note: detailed extraction depends on the exact shape of groundingChunks for maps which can vary.
    // For this demo, we assume the text contains the bulk and we try to extract links.

    return { text, places };

  } catch (error) {
    console.error("Gemini Maps Error:", error);
    return { text: "Failed to search business information.", places: [] };
  }
};
