export interface Server {
  id: string;
  name: string;
  region: string;
  status: 'online' | 'offline' | 'maintenance' | 'busy';
  cpuUsage: number;
  memoryUsage: number;
  ip: string;
}

export interface EnvVariable {
  id: string;
  key: string;
  value: string; // Encrypted/masked in UI
  serverId: string | 'global';
  lastUpdated: string;
}

export interface TestSuite {
  id: string;
  name: string;
  description: string;
  status: 'idle' | 'running' | 'passed' | 'failed';
  lastRun: string;
  duration: string;
}

export interface TestResultLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error';
  message: string;
  stackTrace?: string;
}

export interface DiscProfile {
  name: string;
  role: string;
  scores: {
    dominance: number;
    influence: number;
    steadiness: number;
    conscientiousness: number;
  };
}

export interface ArchProfile {
  acknowledge: number;
  reflect: number;
  context: number;
  handoff: number;
}

// --- System Identity & Prompts ---
export interface SystemPromptSections {
  ownerIdentity: string;
  loyaltyStatement: string;
  ownerPriorities: string;
  dataProtectionMantra: string;
  securityStatement: string;
  discReinforcement: string;
}

export interface SystemPrompt {
  id: string;
  name: string;
  description: string;
  lastModified: string;
  sections: SystemPromptSections;
}

export interface SecurityAlert {
  id: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  component: string;
  description: string;
  detectedAt: string;
}

export interface CommunicationLog {
  id: string;
  type: 'sms' | 'voice';
  direction: 'inbound' | 'outbound';
  from: string;
  to: string;
  status: 'sent' | 'received' | 'failed';
  timestamp: string;
  sid: string;
}

// For Grounding/Map feature
export interface PlaceResult {
  title: string;
  uri: string;
  address?: string;
}

// Telephony & Agent Config
export interface CallLog {
  id: string;
  direction: 'inbound' | 'outbound';
  number: string;
  duration: number;
  timestamp: number;
  status: 'completed' | 'blocked' | 'missed' | 'failed';
  recordingUrl?: string;
}

export interface TwilioConfig {
  friendlyName?: string;
  phoneSid?: string;
  messagingServiceSid?: string;
  voiceUrl?: string;
  voiceFallbackUrl?: string;
  statusCallbackUrl?: string;
  smsUrl?: string;
  smsFallbackUrl?: string;
  errorUrl?: string;
}

export interface TelephonyConfig {
  phoneNumber: string | null;
  allowedNumbers: string[];
  callHistory: CallLog[];
  firewallEnabled: boolean;
  maxCallDuration: number;
  timeout: number;
  ownerPhone?: string;
  ownerEmail?: string;
  twilio?: TwilioConfig;
}

export interface AgentConfig {
    id: string;
    name: string;
    telephony: TelephonyConfig;
}