
export enum SystemMode {
  LIVE_VIEW = 'LIVE_VIEW',
  LOGISTICS = 'LOGISTICS',
  MONITORING = 'MONITORING',
  GOOGLE_PLACES = 'GOOGLE_PLACES'
}

export enum NodeType {
  ORIGIN = 'ORIGIN',
  DESTINATION = 'DESTINATION',
  WAYPOINT = 'WAYPOINT'
}

export type ParamType = 'default' | 'user' | 'special';

export interface RouteParameter {
  label: string;
  value: string;
  category: ParamType;
}

export interface NodeData {
  id: string;
  type: NodeType;
  label: string;
  address: string;
  googleId: string;
  coordinates: { x: number; y: number };
  
  // Schedule
  schedule: {
    arrival: string;
    departure: string;
    nextArrival?: string;
  };

  // Route Incoming/Outgoing
  routeInfo?: {
    name: string;
    method: string;
    duration: string;
    monitoring: string[];
  };

  // Agent/Request Data
  request?: {
    description: string;
    groundingLocation: string;
    groundingTime: string;
    minRating?: number;
    categoryPrefs?: string;
  };

  parameters: RouteParameter[];
}
