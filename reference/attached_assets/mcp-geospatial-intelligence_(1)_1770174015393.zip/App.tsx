
import React, { useState } from 'react';
import { SystemDiagram } from './components/SystemDiagram';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { MetricsPanel } from './components/MetricsPanel';
import { AgentControlPanel } from './components/AgentControlPanel';
import { SystemMode } from './types';

const App: React.FC = () => {
  const [activeNodeId, setActiveNodeId] = useState<string | null>(null);
  const [systemMode, setSystemMode] = useState<SystemMode>(SystemMode.LIVE_VIEW);
  const [isLive, setIsLive] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-200">
      {/* Dynamic Background */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(circle_at_50%_50%,#1e293b_0%,#020617_100%)]" />
      
      {/* Sidebar for Navigation/Status */}
      <Sidebar 
        currentMode={systemMode} 
        onModeChange={(mode) => {
          setSystemMode(mode);
          setIsSidebarOpen(false); // Close sidebar on selection (mobile)
        }}
        isLive={isLive}
        onToggleLive={() => setIsLive(!isLive)}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative z-10 min-w-0 transition-all duration-300">
        <Header 
          activeNodeId={activeNodeId} 
          onMenuToggle={() => setIsSidebarOpen(!isSidebarOpen)}
        />
        
        <div className="flex-1 relative flex items-center justify-center bg-[#020617]">
          <SystemDiagram 
            mode={systemMode} 
            activeNodeId={activeNodeId} 
            onNodeClick={setActiveNodeId}
          />
        </div>
        
        <MetricsPanel />
      </main>
      
      {/* Right Interaction Panel */}
      <AgentControlPanel 
        activeNodeId={activeNodeId} 
        onClose={() => setActiveNodeId(null)}
      />
    </div>
  );
};

export default App;
