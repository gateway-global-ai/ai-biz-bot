
import React from 'react';
import { 
  Activity, 
  ShieldCheck, 
  Clock, 
  BarChart3 
} from 'lucide-react';

export const MetricsPanel: React.FC = () => {
  const stats = [
    { label: 'Active Agents', value: '1,242', trend: '+12%', icon: Activity, color: 'text-blue-400' },
    { label: 'Verification Rate', value: '99.98%', trend: 'Stable', icon: ShieldCheck, color: 'text-green-400' },
    { label: 'Avg Task Latency', value: '42ms', trend: '-5ms', icon: Clock, color: 'text-purple-400' },
    { label: 'System Pressure', value: 'Medium', trend: 'Optimal', icon: BarChart3, color: 'text-yellow-400' },
  ];

  return (
    <div className="h-24 border-t border-slate-800 grid grid-cols-4 bg-slate-950/80">
      {stats.map((stat, i) => (
        <div key={i} className={`flex items-center gap-4 px-8 border-r border-slate-900 last:border-0`}>
          <div className={`p-2 rounded-lg bg-slate-900/50 ${stat.color}`}>
            <stat.icon className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{stat.label}</p>
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-bold text-slate-200">{stat.value}</span>
              <span className={`text-[10px] ${stat.trend.startsWith('+') ? 'text-green-500' : stat.trend.startsWith('-') ? 'text-blue-500' : 'text-slate-500'}`}>
                {stat.trend}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
