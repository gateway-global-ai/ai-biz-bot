
import React from 'react';
import { X, Navigation, Clock, MapPin, AlertTriangle, Cloud, Thermometer } from 'lucide-react';
import { NodeData, NodeType } from '../types';

// Helper to access nodes from diagram data (in a real app this would be in a store)
// We'll duplicate the static data structure here for the view logic
const NODES_DATA: NodeData[] = [
    { 
      id: 'node-1', 
      type: NodeType.ORIGIN, 
      label: 'Home Base', 
      address: '3810 Spitze Drive, Las Vegas, NV 89103',
      googleId: 'LOC-89103-SPITZE',
      coordinates: { x: 600, y: 450 },
      schedule: { arrival: '8:00 AM', departure: '10:00 AM' },
      routeInfo: {
        name: 'EXTERNAL ROUTE-1A (GOOGLE MAPS)',
        method: 'PERSONAL CAR',
        duration: '22 MIN',
        monitoring: ['WEATHER CONDITIONS', 'TRAFFIC DENSITY']
      },
      parameters: [
        { label: 'Security Level', value: 'High', category: 'default' },
        { label: 'Vehicle Type', value: 'Electric SUV', category: 'user' }
      ]
    },
    { 
      id: 'node-2', 
      type: NodeType.DESTINATION, 
      label: 'Red Rock Casino', 
      address: '11011 W Charleston Blvd, Las Vegas, NV 89135',
      googleId: 'LOC-REDROCK-RESORT',
      coordinates: { x: 200, y: 200 },
      schedule: { arrival: '10:30 AM', departure: '1:00 PM', nextArrival: '12:00 PM' },
      request: {
        description: 'Business Luncheon Meeting',
        groundingLocation: 'Main Lobby',
        groundingTime: '10:35 AM',
        minRating: 4.5,
        categoryPrefs: 'Quiet Ambience'
      },
      routeInfo: {
        name: 'EXTERNAL ROUTE-2A (GOOGLE MAPS)',
        method: 'PERSONAL CAR',
        duration: '5 MIN',
        monitoring: ['PARKING AVAILABILITY', 'CROWD DENSITY']
      },
      parameters: [
        { label: 'Check-in Method', value: 'VIP Kiosk', category: 'special' },
        { label: 'Table Reservation', value: 'Confirmed', category: 'default' }
      ]
    },
    { 
      id: 'node-3', 
      type: NodeType.WAYPOINT, 
      label: 'BJ\'s Restaurant', 
      address: '10840 W Charleston Blvd, Las Vegas, NV 89135',
      googleId: 'LOC-BJS-SUMMERLIN',
      coordinates: { x: 280, y: 240 },
      schedule: { arrival: '1:15 PM', departure: '3:00 PM' },
      request: {
        description: 'Post-conference Social',
        groundingLocation: 'Patio Seating',
        groundingTime: '1:20 PM',
        minRating: 4.0,
        categoryPrefs: 'Microbrewery'
      },
      parameters: [
        { label: 'Dietary Restrictions', value: 'None', category: 'user' },
        { label: 'Group Size', value: '6 Pax', category: 'special' }
      ]
    }
];

interface AgentControlPanelProps {
  activeNodeId: string | null;
  onClose: () => void;
}

export const AgentControlPanel: React.FC<AgentControlPanelProps> = ({ activeNodeId, onClose }) => {
  const node = NODES_DATA.find(n => n.id === activeNodeId);

  if (!node) return null;

  return (
    <div className="w-[400px] glass-panel border-l h-full flex flex-col animate-in slide-in-from-right duration-300 shadow-2xl z-20">
      {/* Header */}
      <div className="p-5 border-b border-slate-800 flex justify-between items-start bg-slate-900/60">
        <div>
          <h2 className="font-bold text-xl text-white tracking-tight">{node.label}</h2>
          <div className="flex items-center gap-1.5 mt-1">
            <MapPin className="w-3 h-3 text-blue-400" />
            <p className="text-[10px] text-slate-400 font-mono truncate w-64">{node.address}</p>
          </div>
        </div>
        <button onClick={onClose} className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Node Status Section */}
        <div className="p-5 space-y-6">
          
          {/* Identity & Times */}
          <section className="space-y-3">
            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Node Identity</div>
            <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800/50">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs text-slate-400">Google Business ID</span>
                <span className="text-xs font-mono text-blue-300 bg-blue-500/10 px-2 py-0.5 rounded">{node.googleId}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-3">
                <div className="flex flex-col">
                   <span className="text-[10px] text-slate-500 uppercase mb-1">Arrival</span>
                   <span className="text-sm font-bold text-white">{node.schedule.arrival}</span>
                </div>
                <div className="flex flex-col">
                   <span className="text-[10px] text-slate-500 uppercase mb-1">Departure</span>
                   <span className="text-sm font-bold text-white">{node.schedule.departure}</span>
                </div>
              </div>
            </div>
          </section>

          {/* External Route Info */}
          {node.routeInfo && (
            <section>
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Logistics & Routing</div>
              <div className="bg-slate-900/80 rounded-xl p-4 border border-slate-700/50 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500"></div>
                
                <div className="flex items-center gap-2 mb-3">
                  <Navigation className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold text-indigo-100">{node.routeInfo.name}</span>
                </div>

                <div className="space-y-3 pl-2">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-xs text-slate-400">Transport Method</span>
                    <span className="text-xs font-bold text-white">{node.routeInfo.method}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                     <span className="text-xs text-slate-400">Est. Route Time</span>
                     <span className="text-xs font-bold text-green-400">{node.routeInfo.duration}</span>
                  </div>
                  
                  <div className="pt-1">
                    <span className="text-[10px] text-slate-500 uppercase block mb-2">Active Monitoring</span>
                    <div className="flex flex-wrap gap-2">
                      {node.routeInfo.monitoring.map((m, i) => (
                        <span key={i} className="flex items-center gap-1.5 px-2 py-1 bg-slate-800 rounded text-[10px] text-slate-300 border border-slate-700">
                          {m.includes('WEATHER') ? <Cloud className="w-3 h-3 text-blue-400"/> : <AlertTriangle className="w-3 h-3 text-yellow-400"/>}
                          {m}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* Request / Future Node Info */}
          {node.request && (
             <section>
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Request Context</div>
              <div className="space-y-3">
                 <div className="p-3 bg-slate-900/40 border border-slate-800 rounded-lg">
                    <div className="text-xs text-slate-400 mb-1">Description</div>
                    <div className="text-sm text-slate-200">{node.request.description}</div>
                 </div>
                 
                 <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-slate-900/40 border border-slate-800 rounded-lg">
                      <div className="text-[10px] text-slate-500 uppercase">Grounding Loc</div>
                      <div className="text-xs font-bold text-white mt-1">{node.request.groundingLocation}</div>
                    </div>
                    <div className="p-3 bg-slate-900/40 border border-slate-800 rounded-lg">
                      <div className="text-[10px] text-slate-500 uppercase">Grounding Time</div>
                      <div className="text-xs font-bold text-white mt-1">{node.request.groundingTime}</div>
                    </div>
                 </div>

                 {/* Ratings / Categories */}
                 <div className="flex items-center justify-between p-3 bg-blue-500/5 border border-blue-500/10 rounded-lg">
                    <div>
                      <div className="text-[10px] text-blue-300/70 uppercase">Category Prefs</div>
                      <div className="text-xs font-medium text-blue-200">{node.request.categoryPrefs}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-blue-300/70 uppercase">Min Rating</div>
                      <div className="text-sm font-bold text-blue-200">{node.request.minRating} ★</div>
                    </div>
                 </div>
              </div>
             </section>
          )}

          {/* Parameters List */}
          <section>
             <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Parameters</div>
             <div className="space-y-2">
               {node.parameters.map((param, idx) => (
                 <div key={idx} className="flex justify-between items-center p-2 rounded hover:bg-slate-900 transition-colors group">
                    <div className="flex items-center gap-2">
                       <div className={`w-1.5 h-1.5 rounded-full ${
                         param.category === 'default' ? 'bg-slate-600' :
                         param.category === 'user' ? 'bg-blue-500' : 'bg-purple-500'
                       }`} />
                       <span className="text-xs text-slate-400">{param.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                       <span className="text-xs font-mono text-slate-200">{param.value}</span>
                       <span className={`text-[8px] uppercase px-1.5 py-0.5 rounded ${
                         param.category === 'default' ? 'bg-slate-800 text-slate-500' :
                         param.category === 'user' ? 'bg-blue-500/10 text-blue-400' : 'bg-purple-500/10 text-purple-400'
                       }`}>
                         {param.category}
                       </span>
                    </div>
                 </div>
               ))}
             </div>
          </section>

        </div>
      </div>
      
      {/* Footer Action */}
      <div className="p-4 bg-slate-900/80 border-t border-slate-800">
        <button className="w-full flex items-center justify-center gap-2 py-3 bg-white text-slate-950 hover:bg-slate-200 rounded-lg text-xs font-bold transition-all">
          <Navigation className="w-4 h-4" />
          CALCULATE ALTERNATIVE ROUTE
        </button>
      </div>
    </div>
  );
};
