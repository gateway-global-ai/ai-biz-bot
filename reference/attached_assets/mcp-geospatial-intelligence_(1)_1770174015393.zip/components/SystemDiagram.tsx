
import React, { useRef, useEffect, useMemo, useState } from 'react';
import * as d3 from 'd3';
import { SystemMode, NodeType, NodeData } from '../types';
import { Plus, Search, MessageSquare, SlidersHorizontal, MapPin, X, Star, Info, List, Map as MapIcon, Send, Minimize2 } from 'lucide-react';

interface SystemDiagramProps {
  mode: SystemMode;
  activeNodeId: string | null;
  onNodeClick: (id: string | null) => void;
}

type ViewMode = 'MAP' | 'LIST' | 'CHAT';

export const SystemDiagram: React.FC<SystemDiagramProps> = ({ mode, activeNodeId, onNodeClick }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('MAP');
  const [showAddNodeModal, setShowAddNodeModal] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  // Define nodes with specific coordinates for the Las Vegas schematic
  const nodes: NodeData[] = useMemo(() => [
    { 
      id: 'node-1', 
      type: NodeType.ORIGIN, 
      label: 'Home Base', 
      address: '3810 Spitze Drive, Las Vegas, NV 89103',
      googleId: 'LOC-89103-SPITZE',
      coordinates: { x: 600, y: 450 },
      schedule: { arrival: '8:00 AM', departure: '10:00 AM' },
      routeInfo: {
        name: 'EXTERNAL ROUTE-1A',
        method: 'PERSONAL CAR',
        duration: '22 MIN',
        monitoring: ['WEATHER CONDITIONS', 'TRAFFIC DENSITY']
      },
      parameters: [
        { label: 'Security Level', value: 'High', category: 'default' },
        { label: 'Vehicle Type', value: 'Electric SUV', category: 'user' }
      ]
    },
    { 
      id: 'node-2', 
      type: NodeType.DESTINATION, 
      label: 'Red Rock Casino', 
      address: '11011 W Charleston Blvd, Las Vegas, NV 89135',
      googleId: 'LOC-REDROCK-RESORT',
      coordinates: { x: 200, y: 200 },
      schedule: { arrival: '10:30 AM', departure: '1:00 PM', nextArrival: '12:00 PM' },
      request: {
        description: 'Business Luncheon Meeting',
        groundingLocation: 'Main Lobby',
        groundingTime: '10:35 AM',
        minRating: 4.5,
        categoryPrefs: 'Quiet Ambience'
      },
      routeInfo: {
        name: 'EXTERNAL ROUTE-2A',
        method: 'PERSONAL CAR',
        duration: '5 MIN',
        monitoring: ['PARKING AVAILABILITY', 'CROWD DENSITY']
      },
      parameters: [
        { label: 'Check-in Method', value: 'VIP Kiosk', category: 'special' },
        { label: 'Table Reservation', value: 'Confirmed', category: 'default' }
      ]
    },
    { 
      id: 'node-3', 
      type: NodeType.WAYPOINT, 
      label: 'BJ\'s Restaurant', 
      address: '10840 W Charleston Blvd, Las Vegas, NV 89135',
      googleId: 'LOC-BJS-SUMMERLIN',
      coordinates: { x: 280, y: 240 },
      schedule: { arrival: '1:15 PM', departure: '3:00 PM' },
      request: {
        description: 'Post-conference Social',
        groundingLocation: 'Patio Seating',
        groundingTime: '1:20 PM',
        minRating: 4.0,
        categoryPrefs: 'Microbrewery'
      },
      parameters: [
        { label: 'Dietary Restrictions', value: 'None', category: 'user' },
        { label: 'Group Size', value: '6 Pax', category: 'special' }
      ]
    }
  ], []);

  // Define paths between nodes
  const paths = useMemo(() => [
    { source: 'node-1', target: 'node-2', label: 'W Charleston Blvd' },
    { source: 'node-2', target: 'node-3', label: 'Pavilion Center Dr' }
  ], []);

  // D3 Logic for Map View
  useEffect(() => {
    if (!svgRef.current || viewMode !== 'MAP') return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove(); // Clear previous render

    const g = svg.append('g');

    // Draw "Map" Background Elements (Stylized Roads)
    // Grid Lines
    const defs = svg.append('defs');
    const pattern = defs.append('pattern')
      .attr('id', 'grid')
      .attr('width', 40)
      .attr('height', 40)
      .attr('patternUnits', 'userSpaceOnUse');
    pattern.append('path')
      .attr('d', 'M 40 0 L 0 0 0 40')
      .attr('fill', 'none')
      .attr('stroke', '#1e293b')
      .attr('stroke-width', 1);
    
    g.append('rect')
      .attr('width', '100%')
      .attr('height', '100%')
      .attr('fill', 'url(#grid)');

    // Stylized Geographic Features (Abstract shapes for mountains/zones)
    g.append('path') // Red Rock Canyon Area
      .attr('d', 'M -50 0 L 300 0 L 150 600 L -50 600 Z')
      .attr('fill', '#0f172a')
      .attr('opacity', 0.5);

    // Draw Routes
    paths.forEach(path => {
      const source = nodes.find(n => n.id === path.source)!;
      const target = nodes.find(n => n.id === path.target)!;
      
      const midX = (source.coordinates.x + target.coordinates.x) / 2;
      const midY = (source.coordinates.y + target.coordinates.y) / 2;
      const dx = target.coordinates.x - source.coordinates.x;
      const dy = target.coordinates.y - source.coordinates.y;
      
      const pathData = `M ${source.coordinates.x} ${source.coordinates.y} Q ${midX - dy/4} ${midY + dx/4} ${target.coordinates.x} ${target.coordinates.y}`;

      g.append('path')
        .attr('d', pathData)
        .attr('fill', 'none')
        .attr('stroke', '#1e293b')
        .attr('stroke-width', 8)
        .attr('stroke-linecap', 'round');

      g.append('path')
        .attr('d', pathData)
        .attr('fill', 'none')
        .attr('stroke', '#3b82f6')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '8,4')
        .attr('class', 'animate-flow');
        
      g.append('text')
        .attr('x', midX)
        .attr('y', midY)
        .attr('text-anchor', 'middle')
        .attr('fill', '#64748b')
        .attr('font-size', '10px')
        .attr('class', 'font-mono')
        .attr('dy', -10)
        .text(path.label);
    });

    // Draw Nodes
    const nodeGroups = g.selectAll('g.node')
      .data(nodes)
      .enter().append('g')
      .attr('class', 'node')
      .attr('transform', d => `translate(${d.coordinates.x},${d.coordinates.y})`)
      .attr('cursor', 'pointer')
      .on('click', (e, d) => {
        e.stopPropagation();
        onNodeClick(d.id);
      });

    nodeGroups.each(function(d) {
      const el = d3.select(this);
      const isActive = d.id === activeNodeId;
      const color = d.type === NodeType.ORIGIN ? '#10b981' : d.type === NodeType.DESTINATION ? '#ef4444' : '#3b82f6';

      if (isActive) {
        el.append('circle')
          .attr('r', 40)
          .attr('fill', color)
          .attr('opacity', 0.2)
          .append('animate')
          .attr('attributeName', 'r')
          .attr('from', 20)
          .attr('to', 50)
          .attr('dur', '1.5s')
          .attr('repeatCount', 'indefinite');
        
        el.append('circle')
          .attr('r', 40)
          .attr('fill', color)
          .attr('opacity', 0.1)
          .append('animate')
          .attr('attributeName', 'opacity')
          .attr('values', '0.1;0;0.1')
          .attr('dur', '1.5s')
          .attr('repeatCount', 'indefinite');
      }

      el.append('path')
        .attr('d', 'M0,0 L-10,-25 A 12 12 0 1 1 10 -25 L0,0 Z')
        .attr('fill', '#020617')
        .attr('stroke', color)
        .attr('stroke-width', 2)
        .attr('transform', 'translate(0, -5)');

      el.append('circle')
        .attr('cx', 0)
        .attr('cy', -25)
        .attr('r', 4)
        .attr('fill', color);

      const labelGroup = el.append('g').attr('transform', 'translate(15, -35)');
      
      labelGroup.append('rect')
        .attr('rx', 4)
        .attr('ry', 4)
        .attr('width', 140)
        .attr('height', 40)
        .attr('fill', 'rgba(15, 23, 42, 0.9)')
        .attr('stroke', isActive ? color : '#334155')
        .attr('stroke-width', 1);

      labelGroup.append('text')
        .attr('x', 10)
        .attr('y', 15)
        .attr('fill', '#f1f5f9')
        .attr('font-size', '11px')
        .attr('font-weight', 'bold')
        .text(d.label);

      labelGroup.append('text')
        .attr('x', 10)
        .attr('y', 28)
        .attr('fill', '#94a3b8')
        .attr('font-size', '9px')
        .attr('class', 'font-mono')
        .text(d.schedule.arrival);
    });

    svg.on('click', () => onNodeClick(null));

  }, [nodes, activeNodeId, onNodeClick, viewMode]);

  return (
    <div className="w-full h-full relative overflow-hidden bg-slate-950">
      
      {/* MAP VIEW LAYER */}
      <div className={`w-full h-full absolute inset-0 transition-opacity duration-300 ${viewMode === 'MAP' ? 'opacity-100 z-0' : 'opacity-0 -z-10'}`}>
         <svg 
          ref={svgRef} 
          viewBox="0 0 800 600" 
          preserveAspectRatio="xMidYMid slice"
          className="w-full h-full"
        >
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
        </svg>

        {/* Region Info - Top Right (Map Only) */}
        <div className="absolute top-6 right-6 flex flex-col gap-2 pointer-events-none">
          <div className="glass-panel p-3 rounded-xl border border-slate-800">
              <div className="text-[10px] text-slate-500 font-mono mb-1">MAP REGION</div>
              <div className="font-bold text-sm text-slate-200">LAS VEGAS, NV</div>
              <div className="text-xs text-blue-400">Summmerlin / Spring Valley</div>
          </div>
        </div>

        {/* Footer Status (Map Only) */}
        <div className="absolute bottom-4 left-4">
            <div className="glass-panel px-3 py-1 rounded-full text-[10px] text-slate-400 font-mono flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
              LIVE TRAFFIC DATA FEED
            </div>
        </div>
      </div>

      {/* LIST VIEW LAYER */}
      {viewMode === 'LIST' && (
        <div className="absolute inset-0 z-20 p-8 overflow-y-auto animate-in fade-in duration-300 bg-slate-950/95 backdrop-blur-sm">
           <div className="max-w-4xl mx-auto space-y-4 pt-4 pb-32">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <List className="w-6 h-6 text-indigo-400"/> Node Inventory
              </h2>
              {nodes.map((node) => (
                <div 
                  key={node.id} 
                  onClick={() => onNodeClick(node.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                    activeNodeId === node.id 
                    ? 'bg-indigo-900/20 border-indigo-500/50' 
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-4">
                     <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                       node.type === NodeType.ORIGIN ? 'bg-green-500/10 text-green-400' :
                       node.type === NodeType.DESTINATION ? 'bg-red-500/10 text-red-400' :
                       'bg-blue-500/10 text-blue-400'
                     }`}>
                        <MapPin className="w-5 h-5"/>
                     </div>
                     <div>
                        <h3 className="font-bold text-slate-200">{node.label}</h3>
                        <p className="text-xs text-slate-500 font-mono">{node.address}</p>
                     </div>
                  </div>
                  <div className="text-right">
                     <div className="text-xs font-bold text-slate-300">{node.schedule.arrival} - {node.schedule.departure}</div>
                     <div className="text-[10px] text-slate-500 uppercase">{node.googleId}</div>
                  </div>
                </div>
              ))}
           </div>
        </div>
      )}

      {/* CHAT VIEW LAYER */}
      {viewMode === 'CHAT' && (
        <div className="absolute inset-0 z-20 flex flex-col animate-in slide-in-from-bottom duration-300 bg-slate-950">
           
           {/* Header */}
           <div className="p-4 border-b border-slate-800 bg-slate-900 flex justify-between items-center shadow-lg z-10">
                 <div className="flex items-center gap-3">
                    <div className="relative">
                        <div className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></div>
                        <div className="w-2.5 h-2.5 rounded-full bg-green-500 absolute top-0 left-0 animate-ping opacity-20"></div>
                    </div>
                    <div>
                        <span className="font-bold text-sm block text-slate-100 tracking-tight">System Intelligence</span>
                        <span className="text-[10px] text-blue-400 font-mono font-medium">LIVE AGENT SESSION ACTIVE</span>
                    </div>
                 </div>
                 <div className="flex items-center gap-3">
                     <span className="text-[10px] text-slate-500 font-mono bg-slate-900/50 px-2 py-1 rounded border border-slate-800">ID: AGENT-001</span>
                     <button 
                        onClick={() => setViewMode('MAP')}
                        className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition-colors border border-slate-700"
                        title="Minimize to Map"
                     >
                        <Minimize2 className="w-4 h-4" />
                     </button>
                 </div>
           </div>

           {/* Body */}
           <div className="flex-1 p-6 overflow-y-auto space-y-6 bg-gradient-to-b from-slate-950 to-slate-900/50">
                 {/* AI Message */}
                 <div className="flex gap-4 max-w-3xl">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-[10px] font-bold text-white shadow-lg shadow-indigo-500/20 mt-1 shrink-0">AI</div>
                    <div className="space-y-1">
                        <div className="flex items-center gap-2">
                           <span className="text-xs font-bold text-indigo-400">System</span>
                           <span className="text-[10px] text-slate-600">10:42 AM</span>
                        </div>
                        <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none p-4 text-sm text-slate-300 shadow-sm leading-relaxed">
                           Hello. I am monitoring the Las Vegas logistic nodes. Route optimization is running at 98% efficiency. How can I assist with the routing or node management today?
                        </div>
                    </div>
                 </div>

                 {/* User Message */}
                 <div className="flex gap-4 flex-row-reverse max-w-3xl ml-auto">
                    <div className="w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-300 mt-1 shrink-0">ME</div>
                     <div className="space-y-1 text-right">
                        <div className="flex items-center gap-2 justify-end">
                           <span className="text-[10px] text-slate-600">10:44 AM</span>
                           <span className="text-xs font-bold text-slate-400">Operator</span>
                        </div>
                        <div className="bg-blue-600/10 border border-blue-500/20 rounded-2xl rounded-tr-none p-4 text-sm text-blue-100 shadow-sm leading-relaxed text-left">
                           What is the traffic status on Route 1A towards Red Rock? I need to confirm arrival time for the VIP transfer.
                        </div>
                     </div>
                 </div>

                 {/* AI Message */}
                 <div className="flex gap-4 max-w-3xl">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-[10px] font-bold text-white shadow-lg shadow-indigo-500/20 mt-1 shrink-0">AI</div>
                     <div className="space-y-1">
                        <div className="flex items-center gap-2">
                           <span className="text-xs font-bold text-indigo-400">System</span>
                           <span className="text-[10px] text-slate-600">10:45 AM</span>
                        </div>
                        <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none p-4 text-sm text-slate-300 shadow-sm leading-relaxed">
                           <p className="mb-2">Scanning real-time telemetry...</p>
                           <p>Current traffic density on <span className="text-white font-bold">Route 1A</span> is <span className="text-yellow-500 font-bold">Moderate</span>. Expected delay is approximately <span className="text-white font-bold">4 minutes</span> due to construction on Charleston Blvd.</p>
                           <div className="mt-3 flex gap-2">
                              <span className="px-2 py-1 rounded bg-slate-800 text-[10px] border border-slate-700 text-slate-400">ETA Updated: 10:34 AM</span>
                              <span className="px-2 py-1 rounded bg-slate-800 text-[10px] border border-slate-700 text-slate-400">Confidence: 94%</span>
                           </div>
                        </div>
                    </div>
                 </div>
           </div>

           {/* Input Area */}
           <div className="p-4 bg-slate-950 border-t border-slate-800 flex gap-3 shrink-0 pb-32">
                 <div className="flex-1 relative">
                    <input type="text" placeholder="Type a message or command..." className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3.5 pl-4 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/50 transition-all text-slate-200 placeholder:text-slate-600" />
                 </div>
                 <button className="p-3.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-white shadow-lg shadow-indigo-900/20 transition-all active:scale-95">
                    <Send className="w-5 h-5" />
                 </button>
           </div>
        </div>
      )}
      
      {/* PERSISTENT CONTROLS */}

      {/* Add Node Button - Top Left */}
      <div className="absolute top-6 left-6 z-30">
        <button 
          onClick={() => setShowAddNodeModal(true)}
          className="flex items-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-lg shadow-blue-900/40 transition-all font-bold text-sm"
        >
          <Plus className="w-5 h-5" />
          <span>Add Node</span>
        </button>
      </div>

      {/* Main View Toggle - Bottom Center */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-30 flex items-center gap-4">
        
        {/* View Toggle */}
        <div className="glass-panel p-1 rounded-full flex items-center gap-1 border border-slate-700 shadow-2xl shadow-black/50 backdrop-blur-xl">
           <button 
             onClick={() => setViewMode('LIST')}
             className={`px-6 py-2.5 rounded-full flex items-center gap-2 font-bold text-xs transition-all ${viewMode === 'LIST' ? 'bg-slate-200 text-slate-900 shadow-lg' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
           >
             <List className="w-4 h-4" />
             LIST
           </button>
           <button 
             onClick={() => setViewMode('MAP')}
             className={`px-6 py-2.5 rounded-full flex items-center gap-2 font-bold text-xs transition-all ${viewMode === 'MAP' ? 'bg-slate-200 text-slate-900 shadow-lg' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
           >
             <MapIcon className="w-4 h-4" />
             MAP
           </button>
           <button 
             onClick={() => setViewMode('CHAT')}
             className={`px-6 py-2.5 rounded-full flex items-center gap-2 font-bold text-xs transition-all ${viewMode === 'CHAT' ? 'bg-slate-200 text-slate-900 shadow-lg' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
           >
             <MessageSquare className="w-4 h-4" />
             CHAT
           </button>
        </div>

        {/* Filters Toggle (Visible in List/Map) */}
        {(viewMode === 'MAP' || viewMode === 'LIST') && (
           <button 
              onClick={() => setShowFilters(!showFilters)}
              className={`w-10 h-10 rounded-full flex items-center justify-center border transition-all shadow-lg ${showFilters ? 'bg-indigo-600 text-white border-indigo-500' : 'glass-panel text-slate-400 border-slate-700 hover:bg-slate-800 hover:text-white'}`}
           >
              <SlidersHorizontal className="w-4 h-4" />
           </button>
        )}
      </div>


      {/* FILTERS PANEL */}
      {showFilters && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 w-96 glass-panel border border-slate-700 rounded-2xl p-5 animate-in slide-in-from-bottom-5 duration-200 z-30 shadow-2xl">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-indigo-400" />
              Place Filters
            </h3>
            <button onClick={() => setShowFilters(false)} className="text-slate-400 hover:text-white"><X className="w-4 h-4"/></button>
          </div>
          
          <div className="space-y-3">
            {/* Row 1: Place Name */}
            <div className="relative">
              <Search className="w-3 h-3 text-slate-500 absolute left-3 top-2.5" />
              <input 
                type="text" 
                placeholder="Search Google Places..." 
                className="w-full bg-slate-950/50 border border-slate-700 rounded-lg py-2 pl-8 pr-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>

            {/* Row 2: Category */}
            <div>
               <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Category</label>
               <select className="w-full bg-slate-950/50 border border-slate-700 rounded-lg py-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500">
                  <option>Restaurant</option>
                  <option>Hotel</option>
                  <option>Casino</option>
                  <option>Entertainment</option>
               </select>
            </div>

            {/* Row 3: Rating */}
            <div>
              <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Min Rating</label>
              <div className="flex items-center gap-2 bg-slate-950/50 border border-slate-700 rounded-lg p-2">
                <span className="text-xs font-bold text-slate-200">4.5</span>
                <input type="range" min="1" max="5" step="0.5" defaultValue="4.5" className="flex-1 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500" />
                <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
              </div>
            </div>

            {/* Row 4: Grounding */}
            <div>
               <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Grounding / Proximity</label>
               <div className="flex gap-2">
                  <select className="flex-1 bg-slate-950/50 border border-slate-700 rounded-lg py-2 px-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500">
                    <option>Near Red Rock Casino</option>
                    <option>Near Home Base</option>
                    <option>Custom Location...</option>
                  </select>
               </div>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-slate-700/50 flex justify-end">
            <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg transition-colors">
              APPLY FILTERS
            </button>
          </div>
        </div>
      )}

      {/* ADD NODE MODAL */}
      {showAddNodeModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md glass-panel border border-slate-700 rounded-2xl shadow-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h2 className="font-bold text-lg text-white">Add New Node</h2>
              <button onClick={() => setShowAddNodeModal(false)} className="p-1 hover:bg-slate-800 rounded text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              {/* Google Places Autocomplete Simulation */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-400 uppercase">Location Lookup</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input 
                    type="text" 
                    placeholder="Search Google Places..." 
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500 transition-colors"
                  />
                  <div className="absolute right-3 top-2.5 px-1.5 py-0.5 bg-slate-800 rounded text-[10px] text-slate-500 font-mono border border-slate-700">
                    PLACES API
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-400 uppercase">Arrival Time</label>
                  <input 
                    type="time" 
                    defaultValue="09:00"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2.5 px-3 text-sm text-slate-200 focus:outline-none focus:border-blue-500 transition-colors"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-400 uppercase">Departure Time</label>
                  <input 
                    type="time" 
                    defaultValue="10:30"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2.5 px-3 text-sm text-slate-200 focus:outline-none focus:border-blue-500 transition-colors"
                  />
                </div>
              </div>

              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs flex gap-2">
                <Info className="w-4 h-4 shrink-0" />
                <p>New nodes will automatically sync with route optimization engine and traffic monitoring services.</p>
              </div>
            </div>

            <div className="p-5 bg-slate-900/50 border-t border-slate-800 flex justify-end gap-3">
              <button 
                onClick={() => setShowAddNodeModal(false)}
                className="px-4 py-2 text-slate-400 hover:text-white text-xs font-bold transition-colors"
              >
                CANCEL
              </button>
              <button 
                onClick={() => setShowAddNodeModal(false)}
                className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg shadow-lg shadow-blue-900/20 transition-colors"
              >
                CONFIRM & ADD TO MAP
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
