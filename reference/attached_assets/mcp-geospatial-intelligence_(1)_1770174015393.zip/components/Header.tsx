
import React from 'react';
import { ChevronRight, Search, Bell, Menu } from 'lucide-react';

interface HeaderProps {
  activeNodeId: string | null;
  onMenuToggle: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeNodeId, onMenuToggle }) => {
  return (
    <header className="h-16 border-b border-slate-800 px-4 md:px-8 flex items-center justify-between bg-slate-950/50 backdrop-blur-md">
      <div className="flex items-center gap-3">
        {/* Mobile Menu Toggle */}
        <button 
          onClick={onMenuToggle}
          className="md:hidden p-2 -ml-2 hover:bg-slate-800 rounded-lg text-slate-400 transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-sm whitespace-nowrap">
          <span className="text-slate-500 hidden sm:inline">System</span>
          <ChevronRight className="w-3 h-3 text-slate-700 hidden sm:inline" />
          <span className="text-slate-500 hidden sm:inline">Architecture</span>
          <ChevronRight className="w-3 h-3 text-slate-700 hidden sm:inline" />
          <span className="text-blue-400 font-mono font-medium truncate max-w-[150px] sm:max-w-none">
            {activeNodeId ? activeNodeId.toUpperCase() : 'ROOT_VIEW'}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-6">
        <div className="relative hidden md:block">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Search..." 
            className="bg-slate-900 border border-slate-800 rounded-full py-1.5 pl-10 pr-4 text-xs w-48 lg:w-64 focus:outline-none focus:border-blue-500/50 transition-colors"
          />
        </div>
        <div className="relative">
          <Bell className="w-5 h-5 text-slate-400 cursor-pointer hover:text-slate-200 transition-colors" />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full border-2 border-slate-950"></span>
        </div>
        <div className="flex items-center gap-3 pl-4 border-l border-slate-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 shrink-0"></div>
          <div className="flex flex-col hidden md:flex">
            <span className="text-xs font-bold leading-none">System Admin</span>
            <span className="text-[10px] text-slate-500">Owner Credentials</span>
          </div>
        </div>
      </div>
    </header>
  );
};
