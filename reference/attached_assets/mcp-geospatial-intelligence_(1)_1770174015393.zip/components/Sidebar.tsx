
import React from 'react';
import { SystemMode } from '../types';
import { 
  Map, 
  Navigation, 
  Satellite, 
  MapPin, 
  Zap,
  Info,
  X
} from 'lucide-react';

interface SidebarProps {
  currentMode: SystemMode;
  onModeChange: (mode: SystemMode) => void;
  isLive: boolean;
  onToggleLive: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentMode, onModeChange, isLive, onToggleLive, isOpen, onClose }) => {
  const modes = [
    { id: SystemMode.LIVE_VIEW, label: 'Live View', icon: Map },
    { id: SystemMode.GOOGLE_PLACES, label: 'Google Places', icon: MapPin },
    { id: SystemMode.LOGISTICS, label: 'Logistics', icon: Navigation },
    { id: SystemMode.MONITORING, label: 'Monitoring', icon: Satellite },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      <div 
        className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />

      <aside className={`
        fixed md:relative z-50 h-full
        w-64 glass-panel border-r flex flex-col p-6 gap-8
        transition-transform duration-300 ease-in-out shadow-2xl md:shadow-none
        ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
              <Zap className="text-white w-5 h-5" />
            </div>
            <h1 className="font-bold text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-blue-400">
              MCP GEO
            </h1>
          </div>
          <button onClick={onClose} className="md:hidden text-slate-400 hover:text-white p-1 hover:bg-slate-800 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex flex-col gap-2">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-2 mb-2">Routing Modes</p>
          {modes.map((m) => (
            <button
              key={m.id}
              onClick={() => onModeChange(m.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                currentMode === m.id 
                  ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20' 
                  : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
              }`}
            >
              <m.icon className="w-4 h-4" />
              <span className="text-sm font-medium">{m.label}</span>
            </button>
          ))}
        </nav>

        <div className="mt-auto flex flex-col gap-4">
          <div className="glass-panel rounded-2xl p-4 border border-slate-800">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase">Route Sync</span>
              <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-green-500 animate-pulse' : 'bg-slate-600'}`} />
            </div>
            <button 
              onClick={onToggleLive}
              className={`w-full py-2 rounded-lg text-xs font-bold transition-all ${
                isLive ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-slate-800 text-slate-300'
              }`}
            >
              {isLive ? 'SYNC ACTIVE' : 'START NAVIGATION'}
            </button>
          </div>
          
          <div className="flex items-center gap-2 text-slate-500 px-2">
            <Info className="w-3 h-3" />
            <span className="text-[10px]">Las Vegas Region v2.1</span>
          </div>
        </div>
      </aside>
    </>
  );
};
